package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.SubgroupsSetCancelPaymentRequestBody;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformations;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceWPRDbUtil;

@RunWith(MockitoJUnitRunner.class)
public class InsertPamentHistoryLogProcessorTest  extends CamelTestSupport  {
	
	@Mock
	private ManagePaymentInfoServiceWPRDbUtil managePaymentInfoServiceWPRDbUtil;
	
	@InjectMocks
	private InsertPamentHistoryLogProcessor insertPamentHistoryLogProcessor = new InsertPamentHistoryLogProcessor();

	private Exchange exchange;

	private Message message;

	@Override
	public void setUp() throws Exception {
		
		super.setUp();
	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:in").process(insertPamentHistoryLogProcessor).to("mock:out");
			}
		};
	}
	
	@Test
	public void processScenario() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			SubgroupsSetCancelPaymentRequestBody requestBody = new  SubgroupsSetCancelPaymentRequestBody();
			requestBody.setUserIdentifier("userIdentifier");
			
			PaymentInformations paymentInformations = new PaymentInformations();
			
			List<PaymentInformation> list = new ArrayList<PaymentInformation>();
			
			PaymentInformation information = new PaymentInformation();
			information.setAccountHolderName("accountHolderName");
			information.setSubgroupIdentifier("subgroupIdentifier");
			information.setAccountNickName("accountNickName");
			
			list.add(information);
			paymentInformations.setPaymentInformation(list);
			requestBody.setPaymentInformations(paymentInformations);
			
			request.setRequestBody(requestBody);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);

			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME, "scheduleAutopayment");
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.insertIntoEmpGroupAdminUserHist("", "", "", "", "")).thenReturn(123);
			
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	@Test
	public void processScenarioOne() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			SubgroupsSetCancelPaymentRequestBody requestBody = new  SubgroupsSetCancelPaymentRequestBody();
			
			PaymentInformations paymentInformations = new PaymentInformations();
			
			List<PaymentInformation> list = new ArrayList<PaymentInformation>();
			
			paymentInformations.setPaymentInformation(list);
			requestBody.setPaymentInformations(paymentInformations);
			
			requestBody.setUserIdentifier("userIdentifier");
			request.setRequestBody(requestBody);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);

			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME, "scheduleAutopment");
			
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	@Test
	public void processScenarioCatch() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			SubgroupsSetCancelPaymentRequestBody requestBody = new  SubgroupsSetCancelPaymentRequestBody();
			requestBody.setUserIdentifier("userIdentifier");
			request.setRequestBody(requestBody);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);

			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME, 1234);
			
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}

}
