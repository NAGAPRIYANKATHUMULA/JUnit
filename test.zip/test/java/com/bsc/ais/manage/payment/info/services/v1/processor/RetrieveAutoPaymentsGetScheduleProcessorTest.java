package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bsc.aip.core.model.common.composite.Remarks;
import com.bsc.aip.core.model.common.composite.ResponseHeader;
import com.bsc.aip.core.model.common.composite.TransactionNotification;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceDbUtil;

@RunWith(MockitoJUnitRunner.class)
public class RetrieveAutoPaymentsGetScheduleProcessorTest extends CamelTestSupport{
	
	@Mock
	private ManagePaymentInfoServiceDbUtil managePaymentInfoServiceDbUtil;

	@InjectMocks
	private RetrieveAutoPaymentsGetScheduleProcessor retrieveAutoPaymentsGetScheduleProcessor = new RetrieveAutoPaymentsGetScheduleProcessor();

	private Exchange exchange;

	private Message message;

	@Override
	public void setUp() throws Exception {
		
		super.setUp();
	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:in").process(retrieveAutoPaymentsGetScheduleProcessor).to("mock:out");
			}
		};
	}

	@Test
	public void processScenario() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			RetrieveAutoPaymentsResponse response = new RetrieveAutoPaymentsResponse(); 
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE,response);
			
			Map<String,String> userInfoMap = new HashMap<String, String>();
			userInfoMap.put("Y", "Y");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USERINFO_MAP, userInfoMap);
						
			
			Map<String, List<String>> groupInfoMap = new HashMap<String, List<String>>();
			List<String> list = new ArrayList<>();
			groupInfoMap.put("1", list);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_MAP, groupInfoMap);
			
			Mockito.when(managePaymentInfoServiceDbUtil.validateSubGroupIdentifierCount(groupInfoMap)).thenReturn(1);
			

			List<Map<String, Object>> rows = new ArrayList<>();
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("ACC_NUMBER", "Yaw");
			map.put("PAYMENT_FLAG", "Y");
			map.put("ACC_NICK_NAME", "firstName");
			map.put("SUB_GROUP_IDEN", "Y");
			map.put("SUB_GROUP_NAME", "emailAddress");
			
			rows.add(map);
			
			Mockito.when(managePaymentInfoServiceDbUtil.paymentInfoForGetSchedule(groupInfoMap)).thenReturn(rows);
			
			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioZero() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			RetrieveAutoPaymentsResponse response = new RetrieveAutoPaymentsResponse(); 
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE,response);
			
			Map<String,String> userInfoMap = null;
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USERINFO_MAP, userInfoMap);
			
			Map<String, List<String>> groupInfoMap = null;
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_MAP, groupInfoMap);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccCancelService");
			
			List<String> subGroupList = new ArrayList<String>();
			subGroupList.add("a");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupList);

			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioOne() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			RetrieveAutoPaymentsResponse response = new RetrieveAutoPaymentsResponse(); 
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE,response);
			
			Map<String,String> userInfoMap = new HashMap<String, String>();
			userInfoMap.put("Y", "N");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USERINFO_MAP, userInfoMap);
						
			
			Map<String, List<String>> groupInfoMap = new HashMap<String, List<String>>();
			List<String> list = new ArrayList<>();
			groupInfoMap.put("1", list);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_MAP, groupInfoMap);
			
			Mockito.when(managePaymentInfoServiceDbUtil.validateSubGroupIdentifierCount(groupInfoMap)).thenReturn(0);
			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioTwo() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			RetrieveAutoPaymentsResponse response = new RetrieveAutoPaymentsResponse(); 
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE,response);
			
			Map<String,String> userInfoMap = new HashMap<String, String>();
			userInfoMap.put("1", "a");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USERINFO_MAP, userInfoMap);
						
			
			Map<String, List<String>> groupInfoMap = new HashMap<String, List<String>>();
			List<String> list = new ArrayList<>();
			groupInfoMap.put("1", list);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_MAP, groupInfoMap);
			
			Mockito.when(managePaymentInfoServiceDbUtil.validateSubGroupIdentifierCount(groupInfoMap)).thenReturn(1);
			

			List<Map<String, Object>> rows = new ArrayList<>();
			
			Mockito.when(managePaymentInfoServiceDbUtil.paymentInfoForGetSchedule(groupInfoMap)).thenReturn(rows);
			
			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioThree() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			RetrieveAutoPaymentsResponse response = new RetrieveAutoPaymentsResponse(); 
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE,response);
			
			Map<String,String> userInfoMap = new HashMap<String, String>();
			userInfoMap.put("Y", "N");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USERINFO_MAP, userInfoMap);
						
			
			Map<String, List<String>> groupInfoMap = new HashMap<String, List<String>>();
			List<String> list = new ArrayList<>();
			groupInfoMap.put("1", list);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_MAP, groupInfoMap);
			
			Mockito.when(managePaymentInfoServiceDbUtil.validateSubGroupIdentifierCount(groupInfoMap)).thenReturn(1);
			

			List<Map<String, Object>> rows = new ArrayList<>();
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("ACC_NUMBER", "Yaw");
			map.put("PAYMENT_FLAG", "Y");
			map.put("ACC_NICK_NAME", "firstName");
			map.put("SUB_GROUP_IDEN", "Y");
			map.put("SUB_GROUP_NAME", "emailAddress");
			
			rows.add(map);
			
			Mockito.when(managePaymentInfoServiceDbUtil.paymentInfoForGetSchedule(groupInfoMap)).thenReturn(rows);
			
			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioFour() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			RetrieveAutoPaymentsResponse response = new RetrieveAutoPaymentsResponse(); 
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE,response);
			
			Map<String,String> userInfoMap = null;
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USERINFO_MAP, userInfoMap);
			
			Map<String, List<String>> groupInfoMap = null;
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_MAP, groupInfoMap);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetServic");
			
			List<String> subGroupList = new ArrayList<String>();
			subGroupList.add("a");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupList);

			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioCatch() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			RetrieveAutoPaymentsResponse response = new RetrieveAutoPaymentsResponse(); 
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE,response);
			
			Map<String,String> userInfoMap = new HashMap<String, String>();
			userInfoMap.put("Y", "Y");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USERINFO_MAP, userInfoMap);
						
			
			Map<String, List<String>> groupInfoMap = new HashMap<String, List<String>>();
			List<String> list = new ArrayList<>();
			groupInfoMap.put("1", list);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_MAP, groupInfoMap);
			
			Mockito.when(managePaymentInfoServiceDbUtil.validateSubGroupIdentifierCount(groupInfoMap)).thenReturn(1);
			

			List<Map<String, Object>> rows = new ArrayList<>();
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("ACC_NICK_NAME", 1234);
			rows.add(map);
			
			Mockito.when(managePaymentInfoServiceDbUtil.paymentInfoForGetSchedule(groupInfoMap)).thenReturn(rows);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetServic");
			
			List<String> subGroupList = new ArrayList<String>();
			subGroupList.add("a");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupList);

			
			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private ResponseHeader fetchResponseHeader() {
		ResponseHeader responseHeader = new ResponseHeader();
		TransactionNotification transactionNotification = new TransactionNotification();
		
		Remarks remarks = new Remarks();
		List<com.bsc.aip.core.model.common.atomic.Message> messages = new ArrayList<>();
		com.bsc.aip.core.model.common.atomic.Message  message= new com.bsc.aip.core.model.common.atomic.Message();
		message.setCode("6abc");
		messages.add(message);
		remarks.setMessages(messages);
		transactionNotification.setStatusCode("0");
		transactionNotification.setRemarks(remarks);
		responseHeader.setTransactionNotification(transactionNotification);
		return responseHeader;
	}
}
