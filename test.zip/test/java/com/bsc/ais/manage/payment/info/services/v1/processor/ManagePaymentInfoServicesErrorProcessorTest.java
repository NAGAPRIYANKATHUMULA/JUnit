package com.bsc.ais.manage.payment.info.services.v1.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.client.RestTemplate;

import com.bsc.aip.core.model.common.atomic.Consumer;
import com.bsc.aip.core.model.common.atomic.Credentials;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsHistoryRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoRequest;

@RunWith(MockitoJUnitRunner.class)
public class ManagePaymentInfoServicesErrorProcessorTest extends CamelTestSupport{
	
	@Mock
	private  RestTemplate restTemplate;

	@InjectMocks
	private ManagePaymentInfoServicesErrorProcessor managePaymentInfoServicesErrorProcessor = new ManagePaymentInfoServicesErrorProcessor();

	private Exchange exchange;

	private Message message;

	@Override
	public void setUp() throws Exception {
		
		super.setUp();
	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:in").process(managePaymentInfoServicesErrorProcessor).to("mock:out");
			}
		};
	}

	@Test
	public void processScenario() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			RetrievePaymentInfoRequest request = new RetrievePaymentInfoRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			requestHeader.setConsumer(null);
			request.setRequestHeader(requestHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "getScheduleService");
			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioZero() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			RetrievePaymentInfoRequest request = null;
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "getScheduleService");
			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioOne() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			RetrieveAutoPaymentsHistoryRequest request = new RetrieveAutoPaymentsHistoryRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			requestHeader.setConsumer(null);
			request.setRequestHeader(requestHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "RetrieveAutoPaymentsHistoryService");
			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioTwo() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			RetrieveAutoPaymentsRequest request = new RetrieveAutoPaymentsRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			requestHeader.setConsumer(null);
			request.setRequestHeader(requestHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "retrieveAutoPaymentsForGroupsService");
			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioThree() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			RetrievePaymentInfoRequest request = new RetrievePaymentInfoRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			
			request.setRequestHeader(requestHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "getScheduleService");
			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private RequestHeader fetchRequesteHeaderWithCredentialsAndConsumer() {
		RequestHeader header = new RequestHeader();
		Consumer consumer = new Consumer();
		consumer.setBusinessTransactionType("test");
		consumer.setBusinessUnit("test");
		consumer.setClientVersion("test");
		consumer.setContextId("test");
		consumer.setHostName("test");
		consumer.setId("test");
		consumer.setName("IV");
		consumer.setRequestDateTime("test");
		consumer.setType("test");
		Credentials credentials = new Credentials();
		credentials.setUserName("test");
		credentials.setPassword("test");
		credentials.setToken("test");
		credentials.setType("test");

		header.setTransactionId("TR1234567890");
		header.setConsumer(consumer);
		header.setCredentials(credentials);
		return header;
	}

}
