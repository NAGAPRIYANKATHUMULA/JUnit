package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceDBConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceDbUtil;

@RunWith(MockitoJUnitRunner.class)
public class GetScheduleDataProcessorTest  extends CamelTestSupport {
	
	@Mock
	private ManagePaymentInfoServiceDbUtil managePaymentInfoServiceDbUtil;
	
	@InjectMocks
	private GetScheduleDataProcessor getScheduleDataProcessor = new GetScheduleDataProcessor();

	private Exchange exchange;

	private Message message;

	@Override
	public void setUp() throws Exception {
		
		super.setUp();
	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:in").process(getScheduleDataProcessor).to("mock:out");
			}
		};
	}
	
	@Test
	public void processScenario() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			RetrievePaymentInfoResponse response = new RetrievePaymentInfoResponse(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>();
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			
			Map<String, List<String>> groupInfoMap = new HashMap<String, List<String>>(); 
			List<String> list = new ArrayList<String>();
			list.add("1");
			list.add("2");
			list.add("3");
			groupInfoMap.put("a", list);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_MAP, groupInfoMap);
			
			
			List<String> subGroupIdentifierList = new ArrayList<String>();
			subGroupIdentifierList.add("sub");
			subGroupIdentifierList.add("sub1");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupIdentifierList);
			
			Mockito.when(managePaymentInfoServiceDbUtil.validateSubGroupIdentifierCount(groupInfoMap)).thenReturn(12);
			
			List<Map<String, Object>> paymentRows = new ArrayList<>();
			Map<String, Object> map = new HashMap<>();
			
			map.put(ManagePaymentInfoServiceDBConstants.ACC_NICK_NAME,"9");
			map.put(ManagePaymentInfoServiceDBConstants.ACC_HOLDER_NAME,"8");
			map.put(ManagePaymentInfoServiceDBConstants.ACC_NUMBER,"1");
			map.put(ManagePaymentInfoServiceDBConstants.ROUTING_NUMBER,"2");
			map.put(ManagePaymentInfoServiceDBConstants.ACC_TYPE,"3");
			map.put(ManagePaymentInfoServiceDBConstants.PAYMENT_FLAG,"8");
			map.put(ManagePaymentInfoServiceDBConstants.SUB_GROUP_IDEN,"sub1");
			map.put(ManagePaymentInfoServiceDBConstants.SUB_GROUP_NAME,"7");
			
			
			paymentRows.add(map);
			
			Mockito.when(managePaymentInfoServiceDbUtil.paymentInfoForGetSchedule(groupInfoMap)).thenReturn(paymentRows);
			
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	@Test
	public void processScenarioOne() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			RetrievePaymentInfoResponse response = new RetrievePaymentInfoResponse(); 
					exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>();
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			
			Map<String, List<String>> groupInfoMap = new HashMap<String, List<String>>(); 
			List<String> list = new ArrayList<String>();
			list.add("1");
			list.add("2");
			list.add("3");
			groupInfoMap.put("a", list);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_MAP, groupInfoMap);
			
			
			List<String> subGroupIdentifierList = new ArrayList<String>();
			subGroupIdentifierList.add("sub");
			subGroupIdentifierList.add("sub1");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupIdentifierList);
			
			Mockito.when(managePaymentInfoServiceDbUtil.validateSubGroupIdentifierCount(groupInfoMap)).thenReturn(-1);
			
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	@Test
	public void processScenarioTwo() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			RetrievePaymentInfoResponse response = new RetrievePaymentInfoResponse(); 
					exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>();
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			
			Map<String, List<String>> groupInfoMap = new HashMap<String, List<String>>(); 
			List<String> list = new ArrayList<String>();
			list.add("1");
			list.add("2");
			list.add("3");
			groupInfoMap.put("a", list);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_MAP, groupInfoMap);
			
			
			List<String> subGroupIdentifierList = new ArrayList<String>();
			subGroupIdentifierList.add("sub");
			subGroupIdentifierList.add("sub1");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupIdentifierList);
			
			Mockito.when(managePaymentInfoServiceDbUtil.validateSubGroupIdentifierCount(groupInfoMap)).thenReturn(12);
			
			List<Map<String, Object>> paymentRows = new ArrayList<>();
			
			Mockito.when(managePaymentInfoServiceDbUtil.paymentInfoForGetSchedule(groupInfoMap)).thenReturn(paymentRows);
			
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}

}
