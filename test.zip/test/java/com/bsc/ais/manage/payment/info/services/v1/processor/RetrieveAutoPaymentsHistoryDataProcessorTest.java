package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceDBConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.response.AutoPaymentHistoryInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsHistoryResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceWPRDbUtil;

@RunWith(MockitoJUnitRunner.class)
public class RetrieveAutoPaymentsHistoryDataProcessorTest extends CamelTestSupport {
	
	@Mock
	private ManagePaymentInfoServiceWPRDbUtil managePaymentInfoServiceWPRDbUtil;
	
	@InjectMocks
	private RetrieveAutoPaymentsHistoryDataProcessor retrieveAutoPaymentsHistoryDataProcessor = new RetrieveAutoPaymentsHistoryDataProcessor();

	private Exchange exchange;

	private Message message;

	@Override
	public void setUp() throws Exception {
		
		super.setUp();
	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:in").process(retrieveAutoPaymentsHistoryDataProcessor).to("mock:out");
			}
		};
	}

	@Test
	public void processScenario() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			RetrieveAutoPaymentsHistoryResponse response = new RetrieveAutoPaymentsHistoryResponse();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);

			List<String> subGroupIdentifierList = new ArrayList<String>();
			subGroupIdentifierList.add("1");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUBGROUP_IDENTIFIER_LIST,
					subGroupIdentifierList);

			List<AutoPaymentHistoryInformation> autoPaymentHistoryInformationList = new ArrayList<AutoPaymentHistoryInformation>();
			
			AutoPaymentHistoryInformation information  = new AutoPaymentHistoryInformation();
			information.setAccountNickName("accountNickName");
			autoPaymentHistoryInformationList.add(information);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER, "groupIdentifier");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_NAME, "userName");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_FROM_DATE, "1/1/2020");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_TO_DATE, "2/1/2020");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_ACTION, "action");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_START_INDEX, "3");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_END_INDEX, "0");
			
			String groupIdentifier = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER);
			String userName = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_NAME);
			String fromDate = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_FROM_DATE);
			String toDate = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_TO_DATE);
			String action = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_ACTION);
			String startIndex = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_START_INDEX);
			String endIndex = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_END_INDEX);
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.retrieveTotalHistoryCountByUserNameAndAction(groupIdentifier,userName,fromDate,toDate,action)).thenReturn(1);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetServic");
			
			List<Map<String, Object>> autoPaymentHistoryInfoRows = new ArrayList<>();
			
			Map<String, Object> map = new HashMap<String, Object>();
			 
			map.put("ACT_NM", "Y");
			map.put("PMT_ACT_DT", new Timestamp(System.currentTimeMillis()));
			map.put(ManagePaymentInfoServiceDBConstants.ALS_LST_NM, "firstName");
			map.put(ManagePaymentInfoServiceDBConstants.ALS_FRST_NM, "lastName");
			map.put(ManagePaymentInfoServiceDBConstants.EMAIL_ADDR_TXT, "emailAddress");
			
			
			map.put("b", "3");
			
			autoPaymentHistoryInfoRows.add(map);
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.retrieveAutoPaymentHistoryInfo(groupIdentifier,userName,fromDate,toDate,action,startIndex,endIndex)).thenReturn(autoPaymentHistoryInfoRows);
			
			List<String> subGroupList = new ArrayList<String>();
			subGroupList.add("a");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupList);

			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioZero() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			RetrieveAutoPaymentsHistoryResponse response = new RetrieveAutoPaymentsHistoryResponse();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);

			List<String> subGroupIdentifierList = new ArrayList<String>();
			subGroupIdentifierList.add("1");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUBGROUP_IDENTIFIER_LIST,
					subGroupIdentifierList);

			List<AutoPaymentHistoryInformation> autoPaymentHistoryInformationList = new ArrayList<AutoPaymentHistoryInformation>();
			
			AutoPaymentHistoryInformation information  = new AutoPaymentHistoryInformation();
			information.setAccountNickName("accountNickName");
			autoPaymentHistoryInformationList.add(information);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER, "groupIdentifier");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_NAME, "userName");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_FROM_DATE, "fromDate");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_TO_DATE, "toDate");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_ACTION, "action");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_START_INDEX, "0");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_END_INDEX, "0");
			
			String groupIdentifier = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER);
			String userName = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_NAME);
			String fromDate = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_FROM_DATE);
			String toDate = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_TO_DATE);
			String action = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_ACTION);
			String startIndex = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_START_INDEX);
			String endIndex = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_END_INDEX);
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.retrieveTotalHistoryCountByUserNameAndAction(groupIdentifier,userName,fromDate,toDate,action)).thenReturn(0);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetServic");
		
			List<String> subGroupList = new ArrayList<String>();
			subGroupList.add("a");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupList);

			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioOne() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			RetrieveAutoPaymentsHistoryResponse response = new RetrieveAutoPaymentsHistoryResponse();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);

			List<String> subGroupIdentifierList = new ArrayList<String>();
			subGroupIdentifierList.add("1");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUBGROUP_IDENTIFIER_LIST,
					subGroupIdentifierList);

			List<AutoPaymentHistoryInformation> autoPaymentHistoryInformationList = new ArrayList<AutoPaymentHistoryInformation>();
			
			AutoPaymentHistoryInformation information  = new AutoPaymentHistoryInformation();
			information.setAccountNickName("accountNickName");
			autoPaymentHistoryInformationList.add(information);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER, "groupIdentifier");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_NAME, "userName");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_FROM_DATE, "fromDate");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_TO_DATE, "toDate");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_ACTION, "action");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_START_INDEX, "");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_END_INDEX, "1");
			
			String groupIdentifier = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER);
			String userName = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_NAME);
			String fromDate = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_FROM_DATE);
			String toDate = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_TO_DATE);
			String action = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_ACTION);
			String startIndex = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_START_INDEX);
			String endIndex = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_END_INDEX);
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.retrieveTotalHistoryCountByUserNameAndAction(groupIdentifier,userName,fromDate,toDate,action)).thenReturn(1);
			
			
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetServic");
			
			List<String> subGroupList = new ArrayList<String>();
			subGroupList.add("a");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupList);

			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioTwo() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			RetrieveAutoPaymentsHistoryResponse response = new RetrieveAutoPaymentsHistoryResponse();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);

			List<String> subGroupIdentifierList = new ArrayList<String>();
			subGroupIdentifierList.add("1");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUBGROUP_IDENTIFIER_LIST,
					subGroupIdentifierList);

			List<AutoPaymentHistoryInformation> autoPaymentHistoryInformationList = new ArrayList<AutoPaymentHistoryInformation>();
			
			AutoPaymentHistoryInformation information  = new AutoPaymentHistoryInformation();
			information.setAccountNickName("accountNickName");
			autoPaymentHistoryInformationList.add(information);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER, "groupIdentifier");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_NAME, "userName");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_FROM_DATE, "fromDate");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_TO_DATE, "toDate");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_ACTION, "action");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_START_INDEX, "0");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_END_INDEX, "");
			
			String groupIdentifier = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER);
			String userName = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_NAME);
			String fromDate = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_FROM_DATE);
			String toDate = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_TO_DATE);
			String action = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_ACTION);
			String startIndex = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_START_INDEX);
			String endIndex = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_END_INDEX);
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.retrieveTotalHistoryCountByUserNameAndAction(groupIdentifier,userName,fromDate,toDate,action)).thenReturn(1);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetServic");
			
			List<String> subGroupList = new ArrayList<String>();
			subGroupList.add("a");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupList);

			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioThree() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			RetrieveAutoPaymentsHistoryResponse response = new RetrieveAutoPaymentsHistoryResponse();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);

			List<String> subGroupIdentifierList = new ArrayList<String>();
			subGroupIdentifierList.add("1");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUBGROUP_IDENTIFIER_LIST,
					subGroupIdentifierList);

			List<AutoPaymentHistoryInformation> autoPaymentHistoryInformationList = new ArrayList<AutoPaymentHistoryInformation>();
			
			AutoPaymentHistoryInformation information  = new AutoPaymentHistoryInformation();
			information.setAccountNickName("accountNickName");
			autoPaymentHistoryInformationList.add(information);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER, "groupIdentifier");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_NAME, null);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_FROM_DATE, null);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_TO_DATE, null);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_ACTION, null);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_START_INDEX, "0");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_END_INDEX, "0");
			
			String groupIdentifier = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER);
			
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.retrieveTotalHistoryCountByGroupIdentifier(groupIdentifier)).thenReturn(1);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetServic");
		
			List<String> subGroupList = new ArrayList<String>();
			subGroupList.add("a");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupList);

			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioFour() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			RetrieveAutoPaymentsHistoryResponse response = new RetrieveAutoPaymentsHistoryResponse();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);

			List<String> subGroupIdentifierList = new ArrayList<String>();
			subGroupIdentifierList.add("1");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUBGROUP_IDENTIFIER_LIST,
					subGroupIdentifierList);

			List<AutoPaymentHistoryInformation> autoPaymentHistoryInformationList = new ArrayList<AutoPaymentHistoryInformation>();
			
			AutoPaymentHistoryInformation information  = new AutoPaymentHistoryInformation();
			information.setAccountNickName("accountNickName");
			autoPaymentHistoryInformationList.add(information);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER, "groupIdentifier");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_NAME, null);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_FROM_DATE, null);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_TO_DATE, null);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_ACTION, null);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_START_INDEX, "0");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_END_INDEX, "0");
			
			String groupIdentifier = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER);
			
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.retrieveTotalHistoryCountByGroupIdentifier(groupIdentifier)).thenReturn(-1);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetServic");
		
			List<String> subGroupList = new ArrayList<String>();
			subGroupList.add("a");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupList);

			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioCatch() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			RetrieveAutoPaymentsHistoryResponse response = new RetrieveAutoPaymentsHistoryResponse();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);

			List<String> subGroupIdentifierList = new ArrayList<String>();
			subGroupIdentifierList.add("1");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUBGROUP_IDENTIFIER_LIST,
					subGroupIdentifierList);

			List<AutoPaymentHistoryInformation> autoPaymentHistoryInformationList = new ArrayList<AutoPaymentHistoryInformation>();
			
			AutoPaymentHistoryInformation information  = new AutoPaymentHistoryInformation();
			information.setAccountNickName("accountNickName");
			autoPaymentHistoryInformationList.add(information);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER, 1234);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetServic");
		
			List<String> subGroupList = new ArrayList<String>();
			subGroupList.add("a");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupList);

			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
