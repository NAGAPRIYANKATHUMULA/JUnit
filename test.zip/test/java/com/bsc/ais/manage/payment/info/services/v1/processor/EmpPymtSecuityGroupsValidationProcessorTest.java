package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.bsc.aip.core.model.common.composite.ResponseHeader;
import com.bsc.aip.core.model.common.composite.TransactionNotification;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsHistoryResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;

@RunWith(MockitoJUnitRunner.class)
public class EmpPymtSecuityGroupsValidationProcessorTest extends CamelTestSupport {
	
	
	private EmpPymtSecuityGroupsValidationProcessor empPymtSecuityGroupsValidationProcessor = new EmpPymtSecuityGroupsValidationProcessor();
	
	private Exchange exchange;
	
	private Message message;
	
	@Override
	public void setUp() throws Exception {
		super.setUp();
	}
	
	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {		
		return new RouteBuilder(){
			@Override
			public void configure() throws Exception {
				from("direct:in")
					.process(empPymtSecuityGroupsValidationProcessor)
					.to("mock:out");
			}			
		};
	}
	
	@Test
	public void processScenario() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			LinkedHashMap<String, List<String>> map = new LinkedHashMap<>();
			List<String> groups = new ArrayList<>();
			groups.add("a");
			groups.add("b");
			groups.add("c");
			
			List<String> subGroups = new ArrayList<>();
			subGroups.add("d");
			subGroups.add("e");
			subGroups.add("f");
			
			map.put(ManagePaymentInfoServiceConstants.GROUPS, groups);
			map.put(ManagePaymentInfoServiceConstants.SUB_GROUPS, groups);
			
			Set<String> set = new HashSet<>();
			set.add("1");
			set.add("2");
			exchange.setProperty(ManagePaymentInfoServiceConstants.GROUP_IDENTIFIER_SET, set);
			
			Set<String> set1 = new HashSet<>();
			set1.add("1");
			set1.add("2");
			exchange.setProperty(ManagePaymentInfoServiceConstants.SUB_GROUP_IDENTIFIER_SET, set1);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.OPENID_CONNECT_GROUP_RESPONSE, map);
			
			RetrievePaymentInfoResponse response = new RetrievePaymentInfoResponse(); 
			
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESP_HEADER, responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME, "autoservice");
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,"getScheduleService");
			
			exchange.setIn(message);
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	@Test
	public void processScenarioOne() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.OPENID_CONNECT_GROUP_RESPONSE, null);
			
			ResponseHeader responseHeader = fetchResponseHeader();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESP_HEADER, responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,"service");
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME, "autoservice");
			
			
			exchange.setIn(message);
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	@Test
	public void processScenarioTwo() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			LinkedHashMap<String, List<String>> map = new LinkedHashMap<>();
			List<String> groups = new ArrayList<>();
			groups.add("a");
			groups.add("b");
			groups.add("c");
			
			List<String> subGroups = new ArrayList<>();
			subGroups.add("d");
			subGroups.add("e");
			subGroups.add("f");
			
			map.put(ManagePaymentInfoServiceConstants.GROUPS, groups);
			map.put(ManagePaymentInfoServiceConstants.SUB_GROUPS, groups);
			
			Set<String> set = new HashSet<>();
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.GROUP_IDENTIFIER_SET, set);
			
			Set<String> set1 = new HashSet<>();
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SUB_GROUP_IDENTIFIER_SET, set1);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.OPENID_CONNECT_GROUP_RESPONSE, map);
			
			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESP_HEADER, responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,"subgroupsPymentSetService");
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME, "sche");
			template.send("direct:in", exchange);
			
			exchange.setIn(message);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	/**
	 * catch scenari
	 */
	@Test
	public void processScenarioThree() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			
			List<String> groups = new ArrayList<>();
			groups.add("a");
			groups.add("b");
			groups.add("c");
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.OPENID_CONNECT_GROUP_RESPONSE, groups);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,"service");
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME, "autoservice");
			
			
			exchange.setIn(message);
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	@Test
	public void processScenarioFour() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			LinkedHashMap<String, List<String>> map = new LinkedHashMap<>();
			List<String> groups = new ArrayList<>();
			groups.add("a");
			groups.add("b");
			groups.add("c");
			
			List<String> subGroups = new ArrayList<>();
			subGroups.add("d");
			subGroups.add("e");
			subGroups.add("f");
			
			map.put(ManagePaymentInfoServiceConstants.GROUPS, groups);
			map.put(ManagePaymentInfoServiceConstants.SUB_GROUPS, groups);
			
			Set<String> set = new HashSet<>();
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.GROUP_IDENTIFIER_SET, set);
			
			Set<String> set1 = new HashSet<>();
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SUB_GROUP_IDENTIFIER_SET, set1);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.OPENID_CONNECT_GROUP_RESPONSE, map);
			
			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESP_HEADER, responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,"scge");
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME, "scheduleAutopayment");
			template.send("direct:in", exchange);
			
			exchange.setIn(message);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	@Test
	public void processScenarioFive() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			LinkedHashMap<String, List<String>> map = new LinkedHashMap<>();
			List<String> groups = new ArrayList<>();
			groups.add("a");
			groups.add("b");
			groups.add("c");
			
			List<String> subGroups = new ArrayList<>();
			subGroups.add("d");
			subGroups.add("e");
			subGroups.add("f");
			
			map.put(ManagePaymentInfoServiceConstants.GROUPS, groups);
			map.put(ManagePaymentInfoServiceConstants.SUB_GROUPS, groups);
			
			Set<String> set = new HashSet<>();
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.GROUP_IDENTIFIER_SET, set);
			
			Set<String> set1 = new HashSet<>();
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SUB_GROUP_IDENTIFIER_SET, set1);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.OPENID_CONNECT_GROUP_RESPONSE, map);
			
			RetrieveAutoPaymentsResponse response = new RetrieveAutoPaymentsResponse();
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESP_HEADER, responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,"retrieveAutoPaymentsForGroupsService");
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME, "scheduleAutopt");
			template.send("direct:in", exchange);
			
			exchange.setIn(message);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	@Test
	public void processScenarioSix() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			LinkedHashMap<String, List<String>> map = new LinkedHashMap<>();
			List<String> groups = new ArrayList<>();
			groups.add("a");
			groups.add("b");
			groups.add("c");
			
			List<String> subGroups = new ArrayList<>();
			subGroups.add("d");
			subGroups.add("e");
			subGroups.add("f");
			
			map.put(ManagePaymentInfoServiceConstants.GROUPS, groups);
			map.put(ManagePaymentInfoServiceConstants.SUB_GROUPS, groups);
			
			Set<String> set = new HashSet<>();
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.GROUP_IDENTIFIER_SET, set);
			
			Set<String> set1 = new HashSet<>();
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SUB_GROUP_IDENTIFIER_SET, set1);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.OPENID_CONNECT_GROUP_RESPONSE, map);
			
			RetrieveAutoPaymentsHistoryResponse response = new RetrieveAutoPaymentsHistoryResponse();
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESP_HEADER, responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,"RetrieveAutoPaymentsHistoryService");
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME, "scheduleAutopt");
			template.send("direct:in", exchange);
			
			exchange.setIn(message);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	private ResponseHeader fetchResponseHeader() {
		ResponseHeader responseHeader = new ResponseHeader();
		TransactionNotification transactionNotification = new TransactionNotification();
		transactionNotification.setStatusCode("0");
		responseHeader.setTransactionNotification(transactionNotification);
		return responseHeader;
	}
}
