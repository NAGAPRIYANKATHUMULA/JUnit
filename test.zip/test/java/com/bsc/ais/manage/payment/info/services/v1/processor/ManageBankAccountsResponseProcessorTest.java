package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bsc.aip.core.camel.template.BscCamelTemplate;
import com.bsc.aip.core.model.common.atomic.Consumer;
import com.bsc.aip.core.model.common.atomic.Credentials;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.aip.core.model.common.composite.ResponseHeader;
import com.bsc.aip.core.model.common.composite.TransactionNotification;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;

@RunWith(MockitoJUnitRunner.class)
public class ManageBankAccountsResponseProcessorTest extends CamelTestSupport {
	
	@Mock
	private BscCamelTemplate bscCamelTemplate;

	@InjectMocks
	private ManageBankAccountsResponseProcessor manageBankAccountsResponseProcessor = new ManageBankAccountsResponseProcessor();

	private Exchange exchange;

	private Message message;

	@Override
	public void setUp() throws Exception {

		super.setUp();
	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:in").process(manageBankAccountsResponseProcessor).to("mock:out");
			}
		};
	}

	@Test
	public void processScenario() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST , request);

			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccCancelServic");
				
			List<String> subGroupList = new ArrayList<String>();
			subGroupList.add("a");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupList);


			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioZero() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST , request);

			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_SET_SERVICE);
				
			List<String> subGroupList = new ArrayList<String>();
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupList);


			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioOne() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST , request);

			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			ResponseHeader responseHeader = fetchResponseHeader();
			responseHeader.getTransactionNotification().setStatusCode("1");
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			AuditEvent event = new AuditEvent();
			auditEventList.add(event);
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);


			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	private ResponseHeader fetchResponseHeader() {
		ResponseHeader responseHeader = new ResponseHeader();
		TransactionNotification transactionNotification = new TransactionNotification();
		transactionNotification.setStatusCode("0");
		responseHeader.setTransactionNotification(transactionNotification);
		return responseHeader;
	}
	
	private RequestHeader fetchRequesteHeaderWithCredentialsAndConsumer() {
		RequestHeader header = new RequestHeader();
		Consumer consumer = new Consumer();
		consumer.setBusinessTransactionType("test");
		consumer.setBusinessUnit("test");
		consumer.setClientVersion("test");
		consumer.setContextId("test");
		consumer.setHostName("test");
		consumer.setId("test");
		consumer.setName("IV");
		consumer.setRequestDateTime("test");
		consumer.setType("test");
		Credentials credentials = new Credentials();
		credentials.setUserName("test");
		credentials.setPassword("test");
		credentials.setToken("test");
		credentials.setType("test");

		header.setTransactionId("TR1234567890");
		header.setConsumer(consumer);
		header.setCredentials(credentials);
		return header;
	}
	 

}
