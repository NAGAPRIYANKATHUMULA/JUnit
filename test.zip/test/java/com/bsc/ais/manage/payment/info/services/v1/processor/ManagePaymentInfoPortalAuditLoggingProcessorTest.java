package com.bsc.ais.manage.payment.info.services.v1.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;

@RunWith(MockitoJUnitRunner.class)
public class ManagePaymentInfoPortalAuditLoggingProcessorTest extends CamelTestSupport {

	@Mock
	private  RestTemplate restTemplate;

	@InjectMocks
	private ManagePaymentInfoPortalAuditLoggingProcessor managePaymentInfoPortalAuditLoggingProcessor = new ManagePaymentInfoPortalAuditLoggingProcessor();

	private Exchange exchange;

	private Message message;

	@Override
	public void setUp() throws Exception {
		ManagePaymentInfoPortalAuditLoggingProcessor.setRestTemplate(restTemplate);
		managePaymentInfoPortalAuditLoggingProcessor.setPortalAuditEventUri("http://localhost:9080");
		super.setUp();
	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:in").process(managePaymentInfoPortalAuditLoggingProcessor).to("mock:out");
			}
		};
	}

	@Test
	public void processScenario() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
		
			message.setHeader(ManagePaymentInfoServiceConstants.XBSCCLIENTID, "clientId"); 
			message.setHeader(ManagePaymentInfoServiceConstants.XBSCCLIENTSECRET, "clientSecret");
			
			HttpHeaders header = new HttpHeaders();
			header.setContentType(MediaType.APPLICATION_JSON);
	
			ResponseEntity<String> responseEntity = new ResponseEntity<String>(
					"{ \"token_type\": \"test\",\"access_token\": \"test\" }", header, HttpStatus.OK);
			System.out.println("responseEntity.getStatusCode()------------------------"+responseEntity.getStatusCode());
			Mockito.when(restTemplate.exchange(
					Matchers.eq("http://localhost:9080"),
					Matchers.eq(HttpMethod.POST), Matchers.<HttpEntity<String>>any(), Matchers.eq(String.class)))
					.thenReturn(responseEntity);
			
			exchange.setIn(message);
			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioOne() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
		
			message.setHeader(ManagePaymentInfoServiceConstants.XBSCCLIENTID, null); 
			message.setHeader(ManagePaymentInfoServiceConstants.XBSCCLIENTSECRET, null);
			exchange.setIn(message);
			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
