package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceDBConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.SubgroupsSetCancelPaymentRequestBody;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformations;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceDbUtil;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceWPRDbUtil;

@RunWith(MockitoJUnitRunner.class)
public class ManageBankAccCancelDataProcessorTest extends CamelTestSupport  {
	
	@Mock
	private ManagePaymentInfoServiceWPRDbUtil managePaymentInfoServiceWPRDbUtil;
	
	@Mock
	private ManagePaymentInfoServiceDbUtil managePaymentInfoServiceDbUtil;
	
	@InjectMocks
	private ManageBankAccCancelDataProcessor manageBankAccCancelDataProcessor = new ManageBankAccCancelDataProcessor();

	private Exchange exchange;

	private Message message;

	@Override
	public void setUp() throws Exception {
		
		super.setUp();
	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:in").process(manageBankAccCancelDataProcessor).to("mock:out");
			}
		};
	}
	
	@Test
	public void processScenario() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			
			SubgroupsSetCancelPaymentRequestBody body = new SubgroupsSetCancelPaymentRequestBody();
			PaymentInformations paymentInformations = new PaymentInformations();
			List<PaymentInformation> paymentInformationList = new ArrayList<>();
			PaymentInformation paymentInformation = new PaymentInformation();
			paymentInformation.setAccountNickName("accountNickName");
			paymentInformation.setAccountNumber("accountNumber");
			paymentInformation.setGroupIdentifier("groupIde");
			paymentInformation.setAccountHolderName("accountHolderName");
			paymentInformation.setBankAccountType("bankAccountType");
			paymentInformation.setRoutingNumber("routingNumber");
			paymentInformationList.add(paymentInformation);
			paymentInformations.setPaymentInformation(paymentInformationList);
			body.setPaymentInformations(paymentInformations);
			
			request.setRequestBody(body);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST , request);

			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_GROUP_IDENTIIFER, "abc");
			
			List<Map<String, Object>> subgrpsRows = new ArrayList<>();
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("GRP_BLG_UNIT_NUM", "subGroupIdentifier");
			
			map.put("b", "3");
			
			subgrpsRows.add(map);
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.obtainAllSubgrps((String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_GROUP_IDENTIIFER))).thenReturn(subgrpsRows);
			
			Map<String, List<String>> groupInfoMap = new HashMap<String, List<String>>();
			
			List<String> value = new ArrayList<>();
			value.add("Iden");
			
			groupInfoMap.put("subGroup", value);
			
			Mockito.when(managePaymentInfoServiceDbUtil.validateSubGroupIdentifierCount(groupInfoMap)).thenReturn(2);
			
			
			List<Map<String, Object>> paymentRows = new ArrayList<>();
			
			Map<String, Object> map1 = new HashMap<String, Object>();
			map1.put(ManagePaymentInfoServiceDBConstants.ACC_NUMBER, "GroupIdentifier");
			map1.put(ManagePaymentInfoServiceDBConstants.SUB_GROUP_IDEN, "subGroupIdentifier");
			map1.put(ManagePaymentInfoServiceDBConstants.SUB_GROUP_NAME, "3");
			map1.put(ManagePaymentInfoServiceDBConstants.ACC_NICK_NAME, "accountNickName");
			
			paymentRows.add(map1);
			
			
			Mockito.when(managePaymentInfoServiceDbUtil.paymentInfoForGetSchedule(groupInfoMap)).thenReturn(paymentRows);
			
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER,"ide");
			
			
			List<Map<String, Object>> subGrpFeaturedRows = new ArrayList<>();
			
			Map<String, Object> map2 = new HashMap<String, Object>();
			map2.put(ManagePaymentInfoServiceDBConstants.GRP_BLG_UNIT_NUM, "GroupIdentifier");
			
			
			subGrpFeaturedRows.add(map2);
			
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.obtainSubgrpsFeatures(
					(String) exchange
							.getProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER),
					(String) exchange
							.getProperty(ManagePaymentInfoServiceConstants.EXC_GROUP_IDENTIIFER))).thenReturn(subGrpFeaturedRows);
			

			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	@Test
	public void processScenarioZero() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			
			SubgroupsSetCancelPaymentRequestBody body = new SubgroupsSetCancelPaymentRequestBody();
			PaymentInformations paymentInformations = new PaymentInformations();
			List<PaymentInformation> paymentInformationList = new ArrayList<>();
			PaymentInformation paymentInformation = new PaymentInformation();
			paymentInformation.setAccountNickName("accountNickName");
			paymentInformation.setAccountNumber("accountNumber");
			paymentInformation.setGroupIdentifier("groupIde");
			paymentInformation.setAccountHolderName("accountHolderName");
			paymentInformation.setBankAccountType("bankAccountType");
			paymentInformation.setRoutingNumber("routingNumber");
			paymentInformationList.add(paymentInformation);
			paymentInformations.setPaymentInformation(paymentInformationList);
			body.setPaymentInformations(paymentInformations);
			
			request.setRequestBody(body);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST , request);

			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_GROUP_IDENTIIFER, "abc");
			
			List<Map<String, Object>> subgrpsRows = new ArrayList<>();
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("GRP_BLG_UNIT_NUM", "subGroupIdentifier");
			
			map.put("b", "3");
			
			subgrpsRows.add(map);
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.obtainAllSubgrps((String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_GROUP_IDENTIIFER))).thenReturn(subgrpsRows);
			
			Map<String, List<String>> groupInfoMap = new HashMap<String, List<String>>();
			
			List<String> value = new ArrayList<>();
			value.add("Iden");
			
			groupInfoMap.put("subGroup", value);
			
			Mockito.when(managePaymentInfoServiceDbUtil.validateSubGroupIdentifierCount(groupInfoMap)).thenReturn(2);
			
			
			List<Map<String, Object>> paymentRows = new ArrayList<>();
			
			Map<String, Object> map1 = new HashMap<String, Object>();
			map1.put(ManagePaymentInfoServiceDBConstants.ACC_NUMBER, "GroupIdentifier");
			map1.put(ManagePaymentInfoServiceDBConstants.SUB_GROUP_IDEN, "subGroupIdentifier");
			map1.put(ManagePaymentInfoServiceDBConstants.SUB_GROUP_NAME, "3");
			map1.put(ManagePaymentInfoServiceDBConstants.ACC_NICK_NAME, "accountNickName");
			
			paymentRows.add(map1);
			
			
			Mockito.when(managePaymentInfoServiceDbUtil.paymentInfoForGetSchedule(groupInfoMap)).thenReturn(paymentRows);
			
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER,"ide");
			
			
			List<Map<String, Object>> subGrpFeaturedRows = new ArrayList<>();
			
			Map<String, Object> map2 = new HashMap<String, Object>();
			map2.put(ManagePaymentInfoServiceDBConstants.GRP_BLG_UNIT_NUM, "subGroupIdentifier");
			
			
			subGrpFeaturedRows.add(map2);
			
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.obtainSubgrpsFeatures(
					(String) exchange
							.getProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER),
					(String) exchange
							.getProperty(ManagePaymentInfoServiceConstants.EXC_GROUP_IDENTIIFER))).thenReturn(subGrpFeaturedRows);
			

			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	@Test
	public void processScenarioOne() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST , request);

			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_GROUP_IDENTIIFER, "abc");
			
			List<Map<String, Object>> subgrpsRows = new ArrayList<>();
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.obtainAllSubgrps((String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_GROUP_IDENTIIFER))).thenReturn(subgrpsRows);
			
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	@Test
	public void processScenarioTwo() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST , request);

			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_GROUP_IDENTIIFER, "abc");
			
			List<Map<String, Object>> subgrpsRows = new ArrayList<>();
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("GRP_BLG_UNIT_NUM", "subGroupIdentifier");
			
			map.put("b", "3");
			
			subgrpsRows.add(map);
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.obtainAllSubgrps((String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_GROUP_IDENTIIFER))).thenReturn(subgrpsRows);
			
			Map<String, List<String>> groupInfoMap = new HashMap<String, List<String>>();
			
			List<String> value = new ArrayList<>();
			value.add("Iden");
			
			groupInfoMap.put("subGroup", value);
			
			Mockito.when(managePaymentInfoServiceDbUtil.validateSubGroupIdentifierCount(groupInfoMap)).thenReturn(2);
			
			
			List<Map<String, Object>> paymentRows = new ArrayList<>();
			
			Mockito.when(managePaymentInfoServiceDbUtil.paymentInfoForGetSchedule(groupInfoMap)).thenReturn(paymentRows);
			

			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}

}
