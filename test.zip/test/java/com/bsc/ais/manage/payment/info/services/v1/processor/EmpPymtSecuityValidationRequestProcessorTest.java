package com.bsc.ais.manage.payment.info.services.v1.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.bsc.aip.core.model.common.atomic.Consumer;
import com.bsc.aip.core.model.common.atomic.Credentials;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.aip.core.model.common.composite.ResponseHeader;
import com.bsc.aip.core.model.common.composite.TransactionNotification;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsHistoryResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;

@RunWith(MockitoJUnitRunner.class)
public class EmpPymtSecuityValidationRequestProcessorTest extends CamelTestSupport {
	
	@Mock
	private RestTemplate restTemplate;
	
	@InjectMocks
	private EmpPymtSecuityValidationRequestProcessor empPymtSecuityValidationRequestProcessor = new EmpPymtSecuityValidationRequestProcessor();
	
	private Exchange exchange;
	
	private Message message;
	
	@Override
	public void setUp() throws Exception {
		empPymtSecuityValidationRequestProcessor.setRestTemplate(restTemplate);
		empPymtSecuityValidationRequestProcessor.setGetGroupSubGroupUri("http://localhost:9080");
		super.setUp();
	}
	
	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {		
		return new RouteBuilder(){
			@Override
			public void configure() throws Exception {
				from("direct:in")
					.process(empPymtSecuityValidationRequestProcessor)
					.to("mock:out");
			}			
		};
	}
	
	@Test
	public void processScenario() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			
			
			RetrievePaymentInfoResponse response = new RetrievePaymentInfoResponse(); 
			
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			requestHeader.getCredentials().setType("id_token");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQ_HEADER, requestHeader);
			
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESP_HEADER, responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_REFRESH_TOKEN, "refresh_token");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_ID_TOKEN, "id_token");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER, "identifier");
			
			
			HttpHeaders header = new HttpHeaders();
			header.setContentType(MediaType.APPLICATION_JSON);
	
			ResponseEntity<String> responseEntity = new ResponseEntity<String>(
					"{\"responseHeader\":{\"transactionNotification\":{\"status\":\"\",\"statusCode\":\"0\",\"responseDateTime\":\"\",\"transactionId\":\"\",\"remarks\": {\"messages\": [{\"code\": \"\",\"description\": \"\",\"message\": \"\"}]}}}, \"responseBody\": \"body\"}", header, HttpStatus.OK);
			
			Mockito.when(restTemplate.exchange(
					Matchers.eq("http://localhost:9080"),
					Matchers.eq(HttpMethod.POST), Matchers.<HttpEntity<String>>any(), Matchers.eq(String.class)))
					.thenReturn(responseEntity);
			
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME, "autoservice");
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,"getScheduleService");
			
			
			exchange.setIn(message);
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	/**
	 * credentials null
	 */
	@Test
	public void processScenarioOne() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			
			
			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse(); 
			
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			requestHeader.setCredentials(null);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQ_HEADER, requestHeader);
			
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESP_HEADER, responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_REFRESH_TOKEN, "refresh_token");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_ID_TOKEN, "id_token");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER, "identifier");
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME, "subgroupsPymentervice");
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,"subgroupsPymentCancelService");
			
			
			exchange.setIn(message);
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	/**
	 * response entity is null
	 */
	
	@Test
	public void processScenarioTwo() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			
			
			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse(); 
			
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			requestHeader.getCredentials().setType("id_token");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQ_HEADER, requestHeader);
			
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESP_HEADER, responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_REFRESH_TOKEN, "refresh_token");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_ID_TOKEN, "id_token");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER, "identifier");
			
			
			HttpHeaders header = new HttpHeaders();
			header.setContentType(MediaType.APPLICATION_JSON);
	
			ResponseEntity<String> responseEntity = new ResponseEntity<String>(
					"", header, HttpStatus.OK);
			
			Mockito.when(restTemplate.exchange(
					Matchers.eq("http://localhost:9080"),
					Matchers.eq(HttpMethod.POST), Matchers.<HttpEntity<String>>any(), Matchers.eq(String.class)))
					.thenReturn(responseEntity);
			
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME, "scheduleAutopayment");
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,"scheduleAutnt");
			
			
			exchange.setIn(message);
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	/**
	 * catch scenario
	 */
	@Test
	public void processScenarioThree() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			
			
			RetrieveAutoPaymentsResponse response = new RetrieveAutoPaymentsResponse(); 
			
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQ_HEADER, responseHeader);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESP_HEADER, responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_REFRESH_TOKEN, "refresh_token");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_ID_TOKEN, "id_token");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER, "identifier");
		
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME, "autoservice");
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,"retrieveAutoPaymentsForGroupsService");
			
			
			exchange.setIn(message);
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	@Test
	public void processScenarioFour() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			
			
			RetrieveAutoPaymentsHistoryResponse response = new RetrieveAutoPaymentsHistoryResponse(); 
			
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			requestHeader.getCredentials().setType("id_token");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQ_HEADER, requestHeader);
			
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESP_HEADER, responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_REFRESH_TOKEN, "refresh_token");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_ID_TOKEN, "id_token");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER, "identifier");
			
			
			HttpHeaders header = new HttpHeaders();
			header.setContentType(MediaType.APPLICATION_JSON);
	
			ResponseEntity<String> responseEntity = new ResponseEntity<String>(
					"{\"responseHeader\":{\"transactionNotification\":{\"status\":\"\",\"statusCode\":\"0\",\"responseDateTime\":\"\",\"transactionId\":\"\",\"remarks\": {\"messages\": [{\"code\": \"\",\"description\": \"\",\"message\": \"\"}]}}}, \"responseBody\": \"body\"}", header, HttpStatus.CONFLICT);
			
			Mockito.when(restTemplate.exchange(
					Matchers.eq("http://localhost:9080"),
					Matchers.eq(HttpMethod.POST), Matchers.<HttpEntity<String>>any(), Matchers.eq(String.class)))
					.thenReturn(responseEntity);
			
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME, "autoservice");
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,"RetrieveAutoPaymentsHistoryService");
			
			
			exchange.setIn(message);
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	private ResponseHeader fetchResponseHeader() {
		ResponseHeader responseHeader = new ResponseHeader();
		TransactionNotification transactionNotification = new TransactionNotification();
		transactionNotification.setStatusCode("0");
		responseHeader.setTransactionNotification(transactionNotification);
		return responseHeader;
	}
	
	private RequestHeader fetchRequesteHeaderWithCredentialsAndConsumer() {
		RequestHeader header = new RequestHeader();
		Consumer consumer = new Consumer();
		consumer.setBusinessTransactionType("test");
		consumer.setBusinessUnit("test");
		consumer.setClientVersion("test");
		consumer.setContextId("test");
		consumer.setHostName("test");
		consumer.setId("test");
		consumer.setName("IV");
		consumer.setRequestDateTime("test");
		consumer.setType("test");
		Credentials credentials = new Credentials();
		credentials.setUserName("test");
		credentials.setPassword("test");
		credentials.setToken("test");
		credentials.setType("test");

		header.setTransactionId("TR1234567890");
		header.setConsumer(consumer);
		header.setCredentials(credentials);
		return header;
	}
	

}
