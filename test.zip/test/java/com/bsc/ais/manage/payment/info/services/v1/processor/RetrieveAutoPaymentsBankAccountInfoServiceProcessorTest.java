package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.bsc.aip.core.model.common.atomic.Consumer;
import com.bsc.aip.core.model.common.atomic.Credentials;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.response.AutoPaymentHistoryInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsHistoryRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsHistoryResponse;

@RunWith(MockitoJUnitRunner.class)
public class RetrieveAutoPaymentsBankAccountInfoServiceProcessorTest extends CamelTestSupport {

	@Mock
	private RestTemplate restTemplate;

	@InjectMocks
	private RetrieveAutoPaymentsBankAccountInfoServiceProcessor retrieveAutoPaymentsBankAccountInfoServiceProcessor = new RetrieveAutoPaymentsBankAccountInfoServiceProcessor();

	private Exchange exchange;

	private Message message;

	@Override
	public void setUp() throws Exception {
		retrieveAutoPaymentsBankAccountInfoServiceProcessor.setRestTemplate(restTemplate);
		retrieveAutoPaymentsBankAccountInfoServiceProcessor
				.setRetrieveBankAccountInfoServiceUrl("http://localhost:9080");
		super.setUp();
	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:in").process(retrieveAutoPaymentsBankAccountInfoServiceProcessor).to("mock:out");
			}
		};
	}

	@Test
	public void processScenario() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			RetrieveAutoPaymentsHistoryRequest request = new RetrieveAutoPaymentsHistoryRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);

			RetrieveAutoPaymentsHistoryResponse response = new RetrieveAutoPaymentsHistoryResponse();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);

			List<String> subGroupIdentifierList = new ArrayList<String>();
			subGroupIdentifierList.add("1");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUBGROUP_IDENTIFIER_LIST,
					subGroupIdentifierList);

			List<AutoPaymentHistoryInformation> autoPaymentHistoryInformationList = new ArrayList<AutoPaymentHistoryInformation>();
			
			AutoPaymentHistoryInformation information  = new AutoPaymentHistoryInformation();
			information.setAccountNickName("accountNickName");
			autoPaymentHistoryInformationList.add(information);
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENTS_HISTORY_INFO_LIST,
					autoPaymentHistoryInformationList);

			message.setHeader(ManagePaymentInfoServiceConstants.XBSCCLIENTID, "clientId");
			message.setHeader(ManagePaymentInfoServiceConstants.XBSCCLIENTSECRET, "clientSecret");

			HttpHeaders header = new HttpHeaders();
			header.setContentType(MediaType.APPLICATION_JSON);

			ResponseEntity<String> responseEntity = new ResponseEntity<String>(
					"{\"responseHeader\":{ \"transactionNotification\":{\"status\":\"\",\"statusCode\":\"0\",\"responseDateTime\":\"\",\"transactionId\":\"\",\"remarks\": {\"messages\": [{\"code\": \"\",\"description\": \"\",\"message\": \"\"}]}}},\"responseBody\": {\"paymentInformations\": {\"paymentInformation\": [{\"accountNickName\": \"accountNickName\",\"accountHolderName\": \"\",\"accountNumber\": \"\",\"routingNumber\": \"\",\"bankAccountType\": \"\",\"paymentFlag\": \"\",\"subgroupIdentifier\": \"\",\"subgroupName\": \"\",\"groupIdentifier\": \"\",\"paymentAmount\": \"\",\"restrictedStatus\": \"\",\"autoPaymentEffectiveDate\": \"\",\"paymentNotificationMsg\": \"\",\"currentBilledAmount\": \"\",\"previousBalance\": \"\",\"amountDue\": \"\",\"paymentNotificationIndicator\": \"\",\"isInvoiceExists\": \"\"}]}}}",
					header, HttpStatus.OK);
			System.out
					.println("responseEntity.getStatusCode()------------------------" + responseEntity.getStatusCode());
			Mockito.when(restTemplate.exchange(Matchers.eq("http://localhost:9080"), Matchers.eq(HttpMethod.POST),
					Matchers.<HttpEntity<String>>any(), Matchers.eq(String.class))).thenReturn(responseEntity);

			exchange.setIn(message);

			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void processScenarioOne() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			RetrieveAutoPaymentsHistoryRequest request = new RetrieveAutoPaymentsHistoryRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);

			RetrieveAutoPaymentsHistoryResponse response = new RetrieveAutoPaymentsHistoryResponse();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);

			List<String> subGroupIdentifierList = new ArrayList<String>();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUBGROUP_IDENTIFIER_LIST,
					subGroupIdentifierList);

			List<AutoPaymentHistoryInformation> autoPaymentHistoryInformationList = new ArrayList<AutoPaymentHistoryInformation>();
			AutoPaymentHistoryInformation information  = new AutoPaymentHistoryInformation();
			
			autoPaymentHistoryInformationList.add(information);
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENTS_HISTORY_INFO_LIST,
					autoPaymentHistoryInformationList);

			message.setHeader(ManagePaymentInfoServiceConstants.XBSCCLIENTID, null);
			message.setHeader(ManagePaymentInfoServiceConstants.XBSCCLIENTSECRET, null);

			HttpHeaders header = new HttpHeaders();
			header.setContentType(MediaType.APPLICATION_JSON);

			ResponseEntity<String> responseEntity = new ResponseEntity<String>(
					"{\"responseHeader\":{ \"transactionNotification\":{\"status\":\"\",\"statusCode\":\"1\",\"responseDateTime\":\"\",\"transactionId\":\"\",\"remarks\": {\"messages\": [{\"code\": \"666\",\"description\": \"\",\"message\": \"\"}]}}},\"responseBody\": {\"paymentInformations\": {\"paymentInformation\": [{\"accountNickName\": \"\",\"accountHolderName\": \"\",\"accountNumber\": \"\",\"routingNumber\": \"\",\"bankAccountType\": \"\",\"paymentFlag\": \"\",\"subgroupIdentifier\": \"\",\"subgroupName\": \"\",\"groupIdentifier\": \"\",\"paymentAmount\": \"\",\"restrictedStatus\": \"\",\"autoPaymentEffectiveDate\": \"\",\"paymentNotificationMsg\": \"\",\"currentBilledAmount\": \"\",\"previousBalance\": \"\",\"amountDue\": \"\",\"paymentNotificationIndicator\": \"\",\"isInvoiceExists\": \"\"}]}}}",
					header, HttpStatus.OK);
			System.out
					.println("responseEntity.getStatusCode()------------------------" + responseEntity.getStatusCode());
			Mockito.when(restTemplate.exchange(Matchers.eq("http://localhost:9080"), Matchers.eq(HttpMethod.POST),
					Matchers.<HttpEntity<String>>any(), Matchers.eq(String.class))).thenReturn(responseEntity);

			exchange.setIn(message);

			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void processScenarioTwo() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			RetrieveAutoPaymentsHistoryRequest request = new RetrieveAutoPaymentsHistoryRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);

			RetrieveAutoPaymentsHistoryResponse response = new RetrieveAutoPaymentsHistoryResponse();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);

			List<String> subGroupIdentifierList = new ArrayList<String>();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUBGROUP_IDENTIFIER_LIST,
					subGroupIdentifierList);

			List<AutoPaymentHistoryInformation> autoPaymentHistoryInformationList = new ArrayList<AutoPaymentHistoryInformation>();
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENTS_HISTORY_INFO_LIST,
					autoPaymentHistoryInformationList);

			message.setHeader(ManagePaymentInfoServiceConstants.XBSCCLIENTID, null);
			message.setHeader(ManagePaymentInfoServiceConstants.XBSCCLIENTSECRET, null);

			HttpHeaders header = new HttpHeaders();
			header.setContentType(MediaType.APPLICATION_JSON);

			ResponseEntity<String> responseEntity = new ResponseEntity<String>(
					"{\"responseHeader\":{ \"transactionNotification\":{\"status\":\"\",\"statusCode\":\"1\",\"responseDateTime\":\"\",\"transactionId\":\"\",\"remarks\": {\"messages\": [{\"code\": \"66\",\"description\": \"\",\"message\": \"\"}]}}},\"responseBody\": {\"paymentInformations\": {\"paymentInformation\": [{\"accountNickName\": \"\",\"accountHolderName\": \"\",\"accountNumber\": \"\",\"routingNumber\": \"\",\"bankAccountType\": \"\",\"paymentFlag\": \"\",\"subgroupIdentifier\": \"\",\"subgroupName\": \"\",\"groupIdentifier\": \"\",\"paymentAmount\": \"\",\"restrictedStatus\": \"\",\"autoPaymentEffectiveDate\": \"\",\"paymentNotificationMsg\": \"\",\"currentBilledAmount\": \"\",\"previousBalance\": \"\",\"amountDue\": \"\",\"paymentNotificationIndicator\": \"\",\"isInvoiceExists\": \"\"}]}}}",
					header, HttpStatus.OK);
			System.out
					.println("responseEntity.getStatusCode()------------------------" + responseEntity.getStatusCode());
			Mockito.when(restTemplate.exchange(Matchers.eq("http://localhost:9080"), Matchers.eq(HttpMethod.POST),
					Matchers.<HttpEntity<String>>any(), Matchers.eq(String.class))).thenReturn(responseEntity);

			exchange.setIn(message);

			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void processScenarioThree() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			RetrieveAutoPaymentsHistoryRequest request = new RetrieveAutoPaymentsHistoryRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);

			RetrieveAutoPaymentsHistoryResponse response = new RetrieveAutoPaymentsHistoryResponse();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);

			List<String> subGroupIdentifierList = new ArrayList<String>();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUBGROUP_IDENTIFIER_LIST,
					subGroupIdentifierList);

			List<AutoPaymentHistoryInformation> autoPaymentHistoryInformationList = new ArrayList<AutoPaymentHistoryInformation>();
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENTS_HISTORY_INFO_LIST,
					autoPaymentHistoryInformationList);

			message.setHeader(ManagePaymentInfoServiceConstants.XBSCCLIENTID, null);
			message.setHeader(ManagePaymentInfoServiceConstants.XBSCCLIENTSECRET, null);

			HttpHeaders header = new HttpHeaders();
			header.setContentType(MediaType.APPLICATION_JSON);

			ResponseEntity<String> responseEntity = new ResponseEntity<String>(
					"",
					header, HttpStatus.OK);
			System.out
					.println("responseEntity.getStatusCode()------------------------" + responseEntity.getStatusCode());
			Mockito.when(restTemplate.exchange(Matchers.eq("http://localhost:9080"), Matchers.eq(HttpMethod.GET),
					Matchers.<HttpEntity<String>>any(), Matchers.eq(String.class))).thenReturn(responseEntity);

			exchange.setIn(message);

			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioCatch() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			RetrieveAutoPaymentsHistoryRequest request = new RetrieveAutoPaymentsHistoryRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);

			RetrieveAutoPaymentsHistoryResponse response = new RetrieveAutoPaymentsHistoryResponse();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);

			List<String> subGroupIdentifierList = new ArrayList<String>();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUBGROUP_IDENTIFIER_LIST,
					subGroupIdentifierList);

			List<AutoPaymentHistoryInformation> autoPaymentHistoryInformationList = new ArrayList<AutoPaymentHistoryInformation>();
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENTS_HISTORY_INFO_LIST,
					autoPaymentHistoryInformationList);

			message.setHeader(ManagePaymentInfoServiceConstants.XBSCCLIENTID, null);
			message.setHeader(ManagePaymentInfoServiceConstants.XBSCCLIENTSECRET, null);

			HttpHeaders header = new HttpHeaders();
			header.setContentType(MediaType.APPLICATION_JSON);

			ResponseEntity<String> responseEntity = new ResponseEntity<String>(
					"{ \"token_type\": \"test\",\"access_token\": \"test\" }",
					header, HttpStatus.OK);
			System.out
					.println("responseEntity.getStatusCode()------------------------" + responseEntity.getStatusCode());
			Mockito.when(restTemplate.exchange(Matchers.eq("http://localhost:9080"), Matchers.eq(HttpMethod.POST),
					Matchers.<HttpEntity<String>>any(), Matchers.eq(String.class))).thenReturn(responseEntity);

			exchange.setIn(message);

			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private RequestHeader fetchRequesteHeaderWithCredentialsAndConsumer() {
		RequestHeader header = new RequestHeader();
		Consumer consumer = new Consumer();
		consumer.setBusinessTransactionType("test");
		consumer.setBusinessUnit("test");
		consumer.setClientVersion("test");
		consumer.setContextId("test");
		consumer.setHostName("test");
		consumer.setId("test");
		consumer.setName("IV");
		consumer.setRequestDateTime("test");
		consumer.setType("test");
		Credentials credentials = new Credentials();
		credentials.setUserName("test");
		credentials.setPassword("test");
		credentials.setToken("test");
		credentials.setType("test");

		header.setTransactionId("TR1234567890");
		header.setConsumer(consumer);
		header.setCredentials(credentials);
		return header;
	}
}
