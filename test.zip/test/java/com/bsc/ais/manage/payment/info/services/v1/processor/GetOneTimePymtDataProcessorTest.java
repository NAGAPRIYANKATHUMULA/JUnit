package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceDBConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceDbUtil;

@RunWith(MockitoJUnitRunner.class)

public class GetOneTimePymtDataProcessorTest extends CamelTestSupport {
	
	@Mock
	private ManagePaymentInfoServiceDbUtil managePaymentInfoServiceDbUtil;
	
	@InjectMocks
	private GetOneTimePymtDataProcessor getOneTimePymtDataProcessor = new GetOneTimePymtDataProcessor();

	private Exchange exchange;

	private Message message;

	@Override
	public void setUp() throws Exception {
		super.setUp();
	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:in").process(getOneTimePymtDataProcessor).to("mock:out");
			}
		};
	}

	@Test
	public void processScenario() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST,request);
			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE,response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_SUB_GRP_ID, "groupIdentifier");
			
			List<Map<String, Object>> groupInfoRows = new ArrayList<>();
			Map<String, Object> map = new HashMap<>();
			map.put(ManagePaymentInfoServiceDBConstants.GRGR_STS, "TM");
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss:Sss");
			System.out.println(dateFormat.format(new Date()));
			Date date = dateFormat.parse("18/12/2017 12:32:55:68532");
			map.put(ManagePaymentInfoServiceDBConstants.GRGR_TERM_DT, date);
			groupInfoRows.add(map);
			Mockito.when(managePaymentInfoServiceDbUtil.obtainGrpSubGrpInfo(((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_SUB_GRP_ID)).substring(0, 8))).thenReturn(groupInfoRows);
			
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	
	@Test
	public void processScenarioOne() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST,request);
			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE,response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_SUB_GRP_ID, "groupIdentifier");
			
			List<Map<String, Object>> groupInfoRows = new ArrayList<>();
			
			Mockito.when(managePaymentInfoServiceDbUtil.obtainGrpSubGrpInfo(((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_SUB_GRP_ID)).substring(0, 8))).thenReturn(groupInfoRows);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccCancelService");
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			List<String> subGroupList = new ArrayList<String>();
			subGroupList.add("1234");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupList);
			
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	/**
	 * saturday
	 */
	@Test
	public void processScenarioTwo() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST,request);
			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE,response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_SUB_GRP_ID, "groupIdentifier");
			
			List<Map<String, Object>> groupInfoRows = new ArrayList<>();
			Map<String, Object> map = new HashMap<>();
			map.put(ManagePaymentInfoServiceDBConstants.GRGR_STS, "TM");
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy hh:MM:ss:Sss");
	
			Date date = dateFormat.parse("21/12/2019 12:32:55:125");
			map.put(ManagePaymentInfoServiceDBConstants.GRGR_TERM_DT, date);
			groupInfoRows.add(map);
			Mockito.when(managePaymentInfoServiceDbUtil.obtainGrpSubGrpInfo(((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_SUB_GRP_ID)).substring(0, 8))).thenReturn(groupInfoRows);
			
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	
	@Test
	public void processScenarioThree() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST,request);
			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE,response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_SUB_GRP_ID, "groupIdentifier");
			
			List<Map<String, Object>> groupInfoRows = new ArrayList<>();
			Map<String, Object> map = new HashMap<>();
			map.put(ManagePaymentInfoServiceDBConstants.GRGR_STS, "T");
			
			groupInfoRows.add(map);
			Mockito.when(managePaymentInfoServiceDbUtil.obtainGrpSubGrpInfo(((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_SUB_GRP_ID)).substring(0, 8))).thenReturn(groupInfoRows);
			
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	@Test
	public void processScenarioFour() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST,request);
			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE,response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_SUB_GRP_ID, "groupIdentifier");
			
			List<Map<String, Object>> groupInfoRows = new ArrayList<>();
			Map<String, Object> map = new HashMap<>();
			map.put(ManagePaymentInfoServiceDBConstants.GRGR_STS, "TM");
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy hh:MM:ss:Sss");
	
			Date date = dateFormat.parse("17/12/2019 12:32:55:125");
			map.put(ManagePaymentInfoServiceDBConstants.GRGR_TERM_DT, date);
			groupInfoRows.add(map);
			Mockito.when(managePaymentInfoServiceDbUtil.obtainGrpSubGrpInfo(((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_SUB_GRP_ID)).substring(0, 8))).thenReturn(groupInfoRows);
			
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	@Test
	public void processScenarioCatch() {
		try {
			
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST,request);
			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE,response);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_SUB_GRP_ID, 1234);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "abcd");
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			List<String> subGroupList = new ArrayList<String>();
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupList);
			
			template.send("direct:in", exchange);
			
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
}
