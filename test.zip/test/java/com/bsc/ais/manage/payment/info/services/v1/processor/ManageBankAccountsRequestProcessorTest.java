package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bsc.aip.core.camel.template.BscCamelTemplate;
import com.bsc.aip.core.model.common.atomic.Consumer;
import com.bsc.aip.core.model.common.atomic.Credentials;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.EmailInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupIdentifier;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupIdentifiers;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupSubgroup;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupSubgroups;
import com.bsc.ais.manage.payment.info.services.v1.model.request.SubgroupsSetCancelPaymentRequestBody;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformations;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;

@RunWith(MockitoJUnitRunner.class)
public class ManageBankAccountsRequestProcessorTest extends CamelTestSupport {

	@Mock
	private BscCamelTemplate bscCamelTemplate;

	@InjectMocks
	private ManageBankAccountsRequestProcessor manageBankAccountsRequestProcessor = new ManageBankAccountsRequestProcessor();

	private Exchange exchange;

	private Message message;

	@Override
	public void setUp() throws Exception {

		super.setUp();
	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:in").process(manageBankAccountsRequestProcessor).to("mock:out");
			}
		};
	}

	@Test
	public void processScenario() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			
			exchange.setIn(message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetServic");
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void processScenarioOne() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			request.setRequestHeader(null);
			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "id");
			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * consumer null
	 */
	@Test
	public void processScenarioTwo() {

		System.out.println("=== start test: delegation history validation processor ===");
		try {
			CamelContext camelContext = createCamelContext();
			exchange = new DefaultExchange(camelContext);
			message = new DefaultMessage(camelContext);
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader header = fetchRequesteHeaderWithCredentialsAndConsumer();
			header.setConsumer(null);
			request.setRequestHeader(header);

			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * consumer attributes null
	 */
	@Test
	public void processScenarioThree() {

		System.out.println("=== start test: delegation history validation processor ===");
		try {
			CamelContext camelContext = createCamelContext();
			exchange = new DefaultExchange(camelContext);
			message = new DefaultMessage(camelContext);
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader header = fetchRequesteHeaderWithCredentialsAndConsumer();
			Consumer consumer = header.getConsumer();
			consumer.setId("");
			consumer.setHostName("");
			consumer.setBusinessUnit("");
			consumer.setType("");
			consumer.setName("");

			request.setRequestHeader(header);

			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * credentials null
	 */
	@Test
	public void processScenarioFour() {

		System.out.println("=== start test: delegation history validation processor ===");
		try {
			CamelContext camelContext = createCamelContext();
			exchange = new DefaultExchange(camelContext);
			message = new DefaultMessage(camelContext);
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader header = fetchRequesteHeaderWithCredentialsAndConsumer();
			header.setCredentials(null);

			request.setRequestHeader(header);

			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * credentials attribute is empty
	 */
	@Test
	public void processScenarioFive() {

		System.out.println("=== start test: delegation history validation processor ===");
		try {
			CamelContext camelContext = createCamelContext();
			exchange = new DefaultExchange(camelContext);
			message = new DefaultMessage(camelContext);
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader header = fetchRequesteHeaderWithCredentialsAndConsumer();
			Credentials credentials = header.getCredentials();
			credentials.setToken("");
			request.setRequestHeader(header);

			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * credentials attribute is empty
	 */
	@Test
	public void processScenarioSix() {

		System.out.println("=== start test: delegation history validation processor ===");
		try {
			CamelContext camelContext = createCamelContext();
			exchange = new DefaultExchange(camelContext);
			message = new DefaultMessage(camelContext);
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader header = fetchRequesteHeaderWithCredentialsAndConsumer();
			Credentials credentials = header.getCredentials();
			credentials.setType("");
			request.setRequestHeader(header);

			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * transactionId is empty
	 */
	@Test
	public void processScenarioSeven() {

		System.out.println("=== start test: delegation history validation processor ===");
		try {
			CamelContext camelContext = createCamelContext();
			exchange = new DefaultExchange(camelContext);
			message = new DefaultMessage(camelContext);
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader header = fetchRequesteHeaderWithCredentialsAndConsumer();

			header.setTransactionId("");
			request.setRequestHeader(header);

			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void processScenarioEight() {

		System.out.println("=== start test: delegation history validation processor ===");
		try {
			CamelContext camelContext = createCamelContext();
			exchange = new DefaultExchange(camelContext);
			message = new DefaultMessage(camelContext);
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader header = fetchRequesteHeaderWithCredentialsAndConsumer();
			Consumer consumer = header.getConsumer();

			consumer.setType("");

			request.setRequestHeader(header);

			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void processScenarioNine() {

		System.out.println("=== start test: delegation history validation processor ===");
		try {
			CamelContext camelContext = createCamelContext();
			exchange = new DefaultExchange(camelContext);
			message = new DefaultMessage(camelContext);
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader header = fetchRequesteHeaderWithCredentialsAndConsumer();
			Consumer consumer = header.getConsumer();

			consumer.setBusinessUnit("");

			request.setRequestHeader(header);

			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void processScenarioTen() {

		System.out.println("=== start test: delegation history validation processor ===");
		try {
			CamelContext camelContext = createCamelContext();
			exchange = new DefaultExchange(camelContext);
			message = new DefaultMessage(camelContext);
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader header = fetchRequesteHeaderWithCredentialsAndConsumer();
			Consumer consumer = header.getConsumer();

			consumer.setHostName("");

			request.setRequestHeader(header);

			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void processScenarioEleven() {

		System.out.println("=== start test: delegation history validation processor ===");
		try {
			CamelContext camelContext = createCamelContext();
			exchange = new DefaultExchange(camelContext);
			message = new DefaultMessage(camelContext);
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader header = fetchRequesteHeaderWithCredentialsAndConsumer();
			Consumer consumer = header.getConsumer();
			consumer.setId("");

			request.setRequestHeader(header);

			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void processScenarioTwelve() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			request.setRequestBody(null);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void processScenarioThirteen() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			requestBody.setEmailInformation(null);
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void processScenarioFourteen() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			requestBody.getEmailInformation().setName("");
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void processScenarioFifteen() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			requestBody.getEmailInformation().setEmailAddress("");
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void processScenarioSixteen() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			requestBody.getEmailInformation().setGroupIdentifier("groupIdentifier");
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioSeventeen() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			requestBody.getPaymentInformations().getPaymentInformation().get(0).setAccountHolderName("");
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			
			exchange.setIn(message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetService");
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioEighteen() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			requestBody.getPaymentInformations().getPaymentInformation().get(0).setRoutingNumber("");
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			
			exchange.setIn(message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetService");
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioNineteen() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			requestBody.getPaymentInformations().getPaymentInformation().get(0).setBankAccountType("");
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			
			exchange.setIn(message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetService");
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioTwenty() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			requestBody.getPaymentInformations().getPaymentInformation().clear();
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			
			exchange.setIn(message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetServic");
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioTwentyOne() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			PaymentInformation paymentInformation = new PaymentInformation();
			requestBody.getPaymentInformations().getPaymentInformation().add(paymentInformation);
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			
			exchange.setIn(message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetServic");
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioTwentyTwo() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			requestBody.getPaymentInformations().getPaymentInformation().get(0).setGroupIdentifier("");
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			
			exchange.setIn(message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetServic");
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioTwentyThree() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			requestBody.getPaymentInformations().getPaymentInformation().get(0).setAccountNickName("");
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			
			exchange.setIn(message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetServic");
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioTwentyFour() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			requestBody.getPaymentInformations().getPaymentInformation().get(0).setAccountNumber("");
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			
			exchange.setIn(message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetServic");
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioTwentyFive() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			requestBody.getPaymentInformations().getPaymentInformation().get(0).setGroupIdentifier("1234567");
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			
			exchange.setIn(message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetServic");
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioZero() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			
			exchange.setIn(message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccCancelService");
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioTwentySix() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			requestBody.getPaymentInformations().getPaymentInformation().get(0).setAccountHolderName("");
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			
			exchange.setIn(message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccCancelService");
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	@Test
	public void processScenarioTwentySeven() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			requestBody.setIsAutoPaymntCnclCnfrm("");
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			
			exchange.setIn(message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccCancelService");
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioTwentyEight() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			requestBody.setIsAutoPaymntCnclCnfrm("true");
			requestBody.getGroupIdentifiers().getGroupIdentifier().clear();
			request.setRequestBody(requestBody);

			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "");
			message.setBody(request);
			
			exchange.setIn(message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccCancelService");
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioTwentyNine() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			requestBody.setUserIdentifier("");
			request.setRequestBody(requestBody);
			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "id");
			
			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioThirty() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			request.setRequestHeader(requestHeader);

			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			requestBody.getEmailInformation().setGroupIdentifier("");
			request.setRequestBody(requestBody);
			message.setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, "id");
			
			message.setBody(request);
			exchange.setIn(message);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	private RequestHeader fetchRequesteHeaderWithCredentialsAndConsumer() {
		RequestHeader header = new RequestHeader();
		Consumer consumer = new Consumer();
		consumer.setBusinessTransactionType("test");
		consumer.setBusinessUnit("test");
		consumer.setClientVersion("test");
		consumer.setContextId("test");
		consumer.setHostName("test");
		consumer.setId("test");
		consumer.setName("IV");
		consumer.setRequestDateTime("test");
		consumer.setType("test");
		Credentials credentials = new Credentials();
		credentials.setUserName("test");
		credentials.setPassword("test");
		credentials.setToken("test");
		credentials.setType("test");

		header.setTransactionId("TR1234567890");
		header.setConsumer(consumer);
		header.setCredentials(credentials);
		return header;
	}

	
	private SubgroupsSetCancelPaymentRequestBody fetchRequestBody() {
		SubgroupsSetCancelPaymentRequestBody body = new SubgroupsSetCancelPaymentRequestBody();
		EmailInformation emailInformation = new EmailInformation();
		emailInformation.setGroupIdentifier("groupIde");
		emailInformation.setName("name");
		emailInformation.setEmailAddress("emailAddress");
		PaymentInformations paymentInformations = new PaymentInformations();
		List<PaymentInformation> paymentInformationList = new ArrayList<>();
		PaymentInformation paymentInformation = new PaymentInformation();
		paymentInformation.setAccountNickName("accountNickName");
		paymentInformation.setAccountNumber("accountNumber");
		paymentInformation.setGroupIdentifier("groupIde");
		paymentInformation.setAccountHolderName("accountHolderName");
		paymentInformation.setBankAccountType("bankAccountType");
		paymentInformation.setRoutingNumber("routingNumber");
		paymentInformationList.add(paymentInformation);
		paymentInformations.setPaymentInformation(paymentInformationList);
		body.setPaymentInformations(paymentInformations);
		body.setEmailInformation(emailInformation);
		body.setUserIdentifier("W123456");
		body.setIsAutoPaymntCnclCnfrm("true1");
		GroupIdentifiers groupIdentifiers = new GroupIdentifiers();
		List<GroupIdentifier> groupIdentifierList = new ArrayList<>();
		
		GroupIdentifier groupIdentifier = new GroupIdentifier();
		
		GroupSubgroups groupSubgroups = new GroupSubgroups();
		List<GroupSubgroup> groupSubgroupList = new ArrayList<>();
		GroupSubgroup groupSubgroup = new GroupSubgroup();
		groupSubgroup.setGroupSubgroupIdentifier("groupSubgrou");
		groupSubgroupList.add(groupSubgroup);
		groupSubgroups.setGroupSubgroup(groupSubgroupList);
		groupIdentifier.setGroupSubgroups(groupSubgroups);
		
		groupIdentifierList.add(groupIdentifier);
		
		groupIdentifiers.setGroupIdentifier(groupIdentifierList);
		body.setGroupIdentifiers(groupIdentifiers);
		return body;

	}
}
