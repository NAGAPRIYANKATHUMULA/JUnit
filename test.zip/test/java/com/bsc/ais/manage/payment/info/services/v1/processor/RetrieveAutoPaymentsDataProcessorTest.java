package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bsc.aip.core.model.common.composite.Remarks;
import com.bsc.aip.core.model.common.composite.ResponseHeader;
import com.bsc.aip.core.model.common.composite.TransactionNotification;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceWPRDbUtil;

@RunWith(MockitoJUnitRunner.class)
public class RetrieveAutoPaymentsDataProcessorTest extends CamelTestSupport{
	
	@Mock
	private ManagePaymentInfoServiceWPRDbUtil managePaymentInfoServiceWPRDbUtil;

	@InjectMocks
	private RetrieveAutoPaymentsDataProcessor retrieveAutoPaymentsDataProcessor = new RetrieveAutoPaymentsDataProcessor();

	private Exchange exchange;

	private Message message;

	@Override
	public void setUp() throws Exception {
		
		super.setUp();
	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:in").process(retrieveAutoPaymentsDataProcessor).to("mock:out");
			}
		};
	}

	@Test
	public void processScenario() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			RetrieveAutoPaymentsResponse response = new RetrieveAutoPaymentsResponse(); 
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
				
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER,"userIdentifier");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER,"groupIdentifier");
			
			List<Map<String, Object>> userInfoRows = new ArrayList<>();
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("GRP_BLG_UNIT_NUM", "subGroupIdentifier");
			
			map.put("isMaintPermission", "3");
			
			userInfoRows.add(map);
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.retrieveUserInformation(
					(String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER),
					(String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER)))
					.thenReturn(userInfoRows);
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.retrieveScheduleNotifyIndInformation(
					(String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER)))
					.thenReturn("a");
			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	@Test
	public void processScenarioOne() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			RetrieveAutoPaymentsResponse response = new RetrieveAutoPaymentsResponse(); 
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
				
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER,"userIdentifier");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER,"groupIdentifier");
			
			List<Map<String, Object>> userInfoRows = new ArrayList<>();
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("GRP_BLG_UNIT_NUM", "subGroupIdentifier");
			
			map.put("isMaintPermission", "3");
			
			userInfoRows.add(map);
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.retrieveUserInformation(
					(String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER),
					(String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER)))
					.thenReturn(userInfoRows);
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.retrieveScheduleNotifyIndInformation(
					(String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER)))
					.thenReturn(null);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccCancelService");
			
			List<String> subGroupList = new ArrayList<String>();
			subGroupList.add("a");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupList);
			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioTwo() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			RetrieveAutoPaymentsResponse response = new RetrieveAutoPaymentsResponse(); 
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
				
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER,"userIdentifier");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER,"groupIdentifier");
			
			List<Map<String, Object>> userInfoRows = new ArrayList<>();
			
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.retrieveUserInformation(
					(String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER),
					(String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER)))
					.thenReturn(userInfoRows);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetService");
			
			List<String> subGroupList = new ArrayList<String>();
			subGroupList.add("a");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupList);
			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioCatch() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());

			RetrieveAutoPaymentsResponse response = new RetrieveAutoPaymentsResponse(); 
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
				
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER,123);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, "manageBankAccSetService");
			
			List<String> subGroupList = new ArrayList<String>();
			subGroupList.add("a");
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST, subGroupList);
			
			
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private ResponseHeader fetchResponseHeader() {
		ResponseHeader responseHeader = new ResponseHeader();
		TransactionNotification transactionNotification = new TransactionNotification();
		
		Remarks remarks = new Remarks();
		List<com.bsc.aip.core.model.common.atomic.Message> messages = new ArrayList<>();
		com.bsc.aip.core.model.common.atomic.Message  message= new com.bsc.aip.core.model.common.atomic.Message();
		message.setCode("6abc");
		messages.add(message);
		remarks.setMessages(messages);
		transactionNotification.setStatusCode("0");
		transactionNotification.setRemarks(remarks);
		responseHeader.setTransactionNotification(transactionNotification);
		return responseHeader;
	}
}
