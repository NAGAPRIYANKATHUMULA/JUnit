package com.bsc.ais.manage.payment.info.services.v1.model.transactional;

import com.bsc.aip.core.model.common.composite.ResponseHeader;
import com.bsc.ais.manage.payment.info.services.v1.model.response.RetrieveAutoPaymentsHistoryResponseBody;

/**
 * This is the Retrieve Census Reports Service Response Pojo
 * @author Cognizant Technology Solutions
 *
 */
public class RetrieveAutoPaymentsHistoryResponse {

	protected ResponseHeader responseHeader;

	private RetrieveAutoPaymentsHistoryResponseBody responseBody = new RetrieveAutoPaymentsHistoryResponseBody();

	/**
	 * 
	 * @return responseHeader
	 */
	public ResponseHeader getResponseHeader() {
		return responseHeader;
	}

	/**
	 * responseHeader to set
	 * @param responseHeader
	 */
	public void setResponseHeader(ResponseHeader responseHeader) {
		this.responseHeader = responseHeader;
	}

	/**
	 * @return the responseBody
	 */
	public RetrieveAutoPaymentsHistoryResponseBody getResponseBody() {
		return responseBody;
	}

	/**
	 * @param responseBody the responseBody to set
	 */
	public void setResponseBody(RetrieveAutoPaymentsHistoryResponseBody responseBody) {
		this.responseBody = responseBody;
	}

}
