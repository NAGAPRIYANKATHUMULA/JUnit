/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Cognizant
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmailInformation {
	
	private String name;
	private String emailAddress;
	private String groupIdentifier;
	private String additionalEmailAddress;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getGroupIdentifier() {
		return groupIdentifier;
	}
	public void setGroupIdentifier(String groupIdentifier) {
		this.groupIdentifier = groupIdentifier;
	}
	public String getAdditionalEmailAddress() {
		return additionalEmailAddress;
	}
	public void setAdditionalEmailAddress(String additionalEmailAddress) {
		this.additionalEmailAddress = additionalEmailAddress;
	}
	
	

}
