/*
 * CreateEmployerSendEmailServiceProcessor.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */

package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceDBConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional.EmailBody;
import com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional.EmailInput;
import com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional.EmployerUser;
import com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional.SendNotificationServiceRequest;
import com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional.SendNotificationServiceRequestBody;
import com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional.SendNotificationServiceResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceWPRDbUtil;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Processor class to handle sending activation code email notification to  users .
 * 
 * @author Cognizant Technology Solutions
 *
 */
@Component()
public class AutoPaymentSendEmailServiceProcessor implements Processor {

	private static final Logger LOGGER = LogManager.getLogger(AutoPaymentSendEmailServiceProcessor.class);

	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";

	@Value("${manage.subgroups.autopayment.notification.email.fromaddressindicator}")
	private String emailFromaddressindicator;

	@Value("${manage.subgroups.autopayment.notification.email.attachmentneeded}")
	private String emailAttachmentneeded;

	@Value("${manage.subgroups.autopayment.notificationservicev2.service.url}")
	private String notificationv2Uri;

	@Value("${manage.subgroups.autopayment.notificationservicev2.service.jwt.token}")
	private String notificationv2AuthenticationToken;
	
	@Value("${manage.subgroups.autopayment.notification.email.applogin.url}")
	private String appLogInUrl;

	/**
	 * Create an instance of Rest template.
	 */
	private RestTemplate RestTemplate = new RestTemplate();

	@Resource
	private EventLogging eventLogging;
	
	@Resource
	ManagePaymentInfoServiceWPRDbUtil managePaymentInfoServiceWPRDbUtil;

	@Override
	public void process(Exchange exchange) throws Exception {

		final String transactionId = (String) exchange
				.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);

		LOGGER.debug(transactionId+ " - "+ ManagePaymentInfoServiceConstants.METHOD_ENTERING,
				METHOD_PROCESS);
		// Holds list of response messages
		List<Message> message = new ArrayList<Message>();
		
		// Obtain the instance of service request
		SubgroupsSetCancelPaymentRequest request = (SubgroupsSetCancelPaymentRequest) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST);
		
		SubgroupsSetCancelPaymentResponse response = (SubgroupsSetCancelPaymentResponse) exchange
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
		
		try {

			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			ObjectMapper requestMapper = new ObjectMapper();
			RequestHeader requestHeader = new RequestHeader();
			HttpEntity<String> requestEntity;
			EmployerUser empUser = new EmployerUser();
			//fetching data for email request
			LOGGER.debug(METHOD_PROCESS + ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE
					+ " executing query to get email request data  "+ transactionId);
			List<Map<String, Object>>  empDetails = managePaymentInfoServiceWPRDbUtil.obtainEmailDetails(request.getRequestBody().getUserIdentifier());
			
			if (null != empDetails && !empDetails.isEmpty()) {
				empUser.setFirstName((String) empDetails.get(0).get(ManagePaymentInfoServiceDBConstants.ALS_FRST_NM));
				empUser.setLastName((String) empDetails.get(0).get(ManagePaymentInfoServiceDBConstants.ALS_LST_NM));
				empUser.setScheduleInd((String) empDetails.get(0).get(ManagePaymentInfoServiceDBConstants.SCHED_NOTFY_IND));
				empUser.setEmailFormat((String) empDetails.get(0).get(ManagePaymentInfoServiceDBConstants.EMAIL_FMT_TYP_CD));
				empUser.setEmailAddress((String) empDetails.get(0).get(ManagePaymentInfoServiceDBConstants.EMAIL_ADDR_TXT));
			} else {
				LOGGER.debug(METHOD_PROCESS + ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE
						+ " email request data not found in database "+ transactionId);
			}
			LOGGER.debug(METHOD_PROCESS + " checking email schedule indicator "+ empUser.getScheduleInd());
			if (null != empDetails && !empDetails.isEmpty() && "Y".equals(empUser.getScheduleInd())) {
				requestHeader = ManagePaymentInfoServiceUtil.processRequestHeader(requestHeader,
						notificationv2AuthenticationToken);
				SendNotificationServiceRequest notifyRequest = setMemberEmailBody(requestHeader, exchange, empUser);
				requestEntity = new HttpEntity<String>(requestMapper.writeValueAsString(notifyRequest), httpHeaders);
				sendEmail(response, message, transactionId, requestEntity);
			}

		} catch (Exception ex) {			
			LOGGER.error(
					METHOD_PROCESS + ManagePaymentInfoServiceConstants.MSG_TECH_ERROR
							+ transactionId + " - " + ex.getCause());
			LOGGER.debug(METHOD_PROCESS + ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE
					+ "  "+ManagePaymentInfoServiceConstants.MSG_TECH_ERROR+ transactionId);
		}		
		LOGGER.debug(transactionId+ " - "+ ManagePaymentInfoServiceConstants.METHOD_EXITING,
				METHOD_PROCESS);
	}

	/**
	 * @param request
	 * @param exchange
	 * @param notifyRequest
	 * @param notifyRequestBody
	 */
	private SendNotificationServiceRequest setMemberEmailBody(RequestHeader requestHeader,
			Exchange exchange, EmployerUser employerUser) {
		LOGGER.debug(METHOD_PROCESS + ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE
				+ " preparing email request body");
		SendNotificationServiceRequest notifyRequest = new SendNotificationServiceRequest();
		SendNotificationServiceRequestBody notifyRequestBody = new SendNotificationServiceRequestBody();
		notifyRequest.setRequestHeader(requestHeader);       
		EmailInput emailInput = new EmailInput();
		List<String> toEmailList = new ArrayList<String>();
		String email = employerUser.getEmailAddress();
		if (null != email){
		toEmailList.add(email.substring(email.lastIndexOf(":")+1,email.length()));
		}
		emailInput.setToAddress(toEmailList);
		emailInput.setFromAddressIndicator(emailFromaddressindicator);
		if (ManagePaymentInfoServiceConstants.CREATE_AUTOPAYMENT_SERVICENAME.equals((String)exchange.getProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME))) {
			emailInput.setSubject(ManagePaymentInfoServiceConstants.CREATE_AUTOPAYMENT_EMAIL_SUBJECT);
		} else {
			emailInput.setSubject(ManagePaymentInfoServiceConstants.CANCEL_AUTOPAYMENT_EMAIL_SUBJECT);
		}
		
		//emailInput.setTemplateType(employerUser.getEmailFormat());
		if (ManagePaymentInfoServiceConstants.CREATE_AUTOPAYMENT_SERVICENAME.equals((String)exchange.getProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME))) {
			if ("2".equals(employerUser.getEmailFormat())) {
				emailInput.setTemplateIndicator("empAutoPaymentCreatedHTML");
			} else {
				emailInput.setTemplateIndicator("empAutoPaymentCreatedText");
				emailInput.setTemplateType("text/plain");
			}
		} else {
			if ("2".equals(employerUser.getEmailFormat())) {
				emailInput.setTemplateIndicator("empAutoPaymentCancNotificationHTML");
			} else {
				emailInput.setTemplateIndicator("empAutoPaymentCancNotificationText");
				emailInput.setTemplateType("text/plain");
			}
		}
		
		//emailInput.setProcessId("Login");

		emailInput.setAttachmentNeeded(emailAttachmentneeded);
		
		EmailBody emailBody = new EmailBody();		
		emailBody.setUsername(employerUser.getUsername());
		emailBody.setFirstName(employerUser.getFirstName()+" " +employerUser.getLastName());
		emailBody.setPaymentNotificationMsg((String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PAYMENT_NOTIFICATION_MSG));
		emailBody.setGroupId((String)exchange.getProperty(ManagePaymentInfoServiceConstants.GROUP_ID));
		emailBody.setSubgroupId((String)exchange.getProperty(ManagePaymentInfoServiceConstants.SUB_GROUP_ID));
		emailBody.setAppLoginUrl(appLogInUrl);
		emailInput.setEmailBody(emailBody);
		notifyRequestBody.setEmailInput(emailInput);
		notifyRequest.setRequestBody(notifyRequestBody);
		return notifyRequest;
	}

	/**
	 * @param response
	 * @param message
	 * @param transactionId
	 * @param requestEntity
	 * @throws IOException
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 */
	private void sendEmail(SubgroupsSetCancelPaymentResponse response, List<Message> message,
			String transactionId, HttpEntity<String> requestEntity)
			throws IOException, JsonParseException, JsonMappingException {
		LOGGER.debug(METHOD_PROCESS + ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE
				+ " Call notificationv2 service service to send the email "+ transactionId);
		ResponseEntity<String> notifyServiceResponse;
		// Call notificationv2 service service to send the email.
		notifyServiceResponse = RestTemplate.exchange(notificationv2Uri, HttpMethod.POST, requestEntity, String.class);

		// Response objects
		SendNotificationServiceResponse notifyResponse = null;
		if (notifyServiceResponse != null) {

			ObjectMapper responseMapper = new ObjectMapper();
			String notifyResponseString = ManagePaymentInfoServiceUtil.processSyncResponse(notifyServiceResponse,
					ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE);

			if (notifyResponseString != null && !StringUtils.isBlank(notifyResponseString)) {
				notifyResponse = responseMapper.readValue(
						ManagePaymentInfoServiceUtil.processSyncResponse(notifyServiceResponse,
								ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE),
						SendNotificationServiceResponse.class);
				if (StringUtils.equalsIgnoreCase(
						notifyResponse.getResponseHeader().getTransactionNotification().getStatusCode(),
						ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE)) {
					if (notifyResponse.getResponseBody() != null) {
						response.getResponseHeader().getTransactionNotification()
								.setStatusCode(ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE);
						response.getResponseHeader().getTransactionNotification()
								.setStatus(ManagePaymentInfoServiceConstants.SUCCESS);
						LOGGER.debug(METHOD_PROCESS + ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE
								+ "  "+ManagePaymentInfoServiceConstants.SUCCESS+ transactionId);

					}
				} else {
					LOGGER.debug(METHOD_PROCESS + ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE
							+ "  "+ManagePaymentInfoServiceConstants.FAILURE+ transactionId);					
				}

			} else {
				LOGGER.debug(METHOD_PROCESS + ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE
						+ "  "+ManagePaymentInfoServiceConstants.FAILURE+ transactionId);
			}

		}
	}

}
