/*
 * GroupSubgroups.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */

package com.bsc.ais.manage.payment.info.services.v1.model.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * The Class GroupSubgroups.
 *
 * @author Cognizant Technology Solutions
 * @version 1.0
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GroupSubgroups {

	/** The subgroup. */
	private List<GroupSubgroup> groupSubgroup = null;

	/**
	 * Gets the subgroup.
	 *
	 * @return the subgroup
	 */
	public List<GroupSubgroup> getGroupSubgroup() {
		return groupSubgroup;
	}

	/**
	 * Sets the subgroup.
	 *
	 * @param subgroup the new subgroup
	 */
	public void setGroupSubgroup(List<GroupSubgroup> groupSubgroup) {
		this.groupSubgroup = groupSubgroup;
	}

}
