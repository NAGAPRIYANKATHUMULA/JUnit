/*
 * SendNotificationServiceResponse.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */

package com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional;

import com.bsc.aip.core.model.common.composite.ResponseHeader;

/**
 * SendNotificationServiceResponse
 * @author Cognizant
 *
 */
public class SendNotificationServiceResponse {
	
	private ResponseHeader responseHeader;
	
	private SendNotificationServiceResponseBody responseBody;

	/**
	 * @return the responseHeader
	 */
	public ResponseHeader getResponseHeader() {
		return responseHeader;
	}

	/**
	 * @param responseHeader the responseHeader to set
	 */
	public void setResponseHeader(ResponseHeader responseHeader) {
		this.responseHeader = responseHeader;
	}

	/**
	 * @return the responseBody
	 */
	public SendNotificationServiceResponseBody getResponseBody() {
		return responseBody;
	}

	/**
	 * @param responseBody the responseBody to set
	 */
	public void setResponseBody(SendNotificationServiceResponseBody responseBody) {
		this.responseBody = responseBody;
	}
	

}
