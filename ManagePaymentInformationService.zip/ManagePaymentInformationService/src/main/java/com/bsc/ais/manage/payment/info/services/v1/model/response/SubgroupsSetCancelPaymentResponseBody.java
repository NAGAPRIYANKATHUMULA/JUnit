package com.bsc.ais.manage.payment.info.services.v1.model.response;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * 
 * @author Cognizant Technology Solutions
 * @version 1.0
 *
 */
@JsonInclude(Include.NON_NULL)
public class SubgroupsSetCancelPaymentResponseBody {

	private String isAutoPymntScheduled;
	
	private PaymentInformations paymentInformations;
	

	public String getIsAutoPymntScheduled() {
		return isAutoPymntScheduled;
	}

	public void setIsAutoPymntScheduled(String isAutoPymntScheduled) {
		this.isAutoPymntScheduled = isAutoPymntScheduled;
	}

	public PaymentInformations getPaymentInformations() {
		return paymentInformations;
	}

	public void setPaymentInformations(PaymentInformations paymentInformations) {
		this.paymentInformations = paymentInformations;
	}

	
	
	
}
