/*
 * GroupIdentifiers.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */

package com.bsc.ais.manage.payment.info.services.v1.model.request;

import java.util.List;

/**
 * The Class GroupIdentifiers.
 *
 * @author Cognizant Technology Solutions
 * @version 1.0
 * 
 */
public class GroupIdentifiers {

	/** The group identifier. */
	private List<GroupIdentifier> groupIdentifier = null;

	/**
	 * Gets the group identifier.
	 *
	 * @return the group identifier
	 */
	public List<GroupIdentifier> getGroupIdentifier() {
		return groupIdentifier;
	}

	/**
	 * Sets the group identifier.
	 *
	 * @param groupIdentifier the new group identifier
	 */
	public void setGroupIdentifier(List<GroupIdentifier> groupIdentifier) {
		this.groupIdentifier = groupIdentifier;
	}

}
