package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.aip.core.model.common.composite.ResponseHeader;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsHistoryResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;

@Component
public class EmpPymtSecuityGroupsValidationProcessor implements Processor {
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LogManager.getLogger(EmpPymtSecuityValidationRequestProcessor.class);

	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";

	@SuppressWarnings("unchecked")
	@Override
	public void process(Exchange exchange) throws Exception {
		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_ENTERING +  METHOD_PROCESS);
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS, ManagePaymentInfoServiceConstants.STRING_FALSE);
		ResponseHeader responseHeader = (ResponseHeader) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESP_HEADER);
		String serviceName = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME);
		String autoPymtServiceName = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME);
		List<Message> messages = new ArrayList<Message>();
		try {
			LinkedHashMap linkedHashMap = (LinkedHashMap) exchange.getProperty(ManagePaymentInfoServiceConstants.OPENID_CONNECT_GROUP_RESPONSE);
			if(linkedHashMap != null) {
				List<String> groups = (List<String>) linkedHashMap.get(ManagePaymentInfoServiceConstants.GROUPS);
				List<String> subGroups = (List<String>) linkedHashMap.get(ManagePaymentInfoServiceConstants.SUB_GROUPS);
				Set<String> groupIdentifierSet = (Set<String>) exchange.getProperty(ManagePaymentInfoServiceConstants.GROUP_IDENTIFIER_SET);

				Boolean isGrpsExists = true;
				if(groupIdentifierSet != null && !groupIdentifierSet.isEmpty() && groupIdentifierSet.size() > 0) {
					for (String groupIdentifier : groupIdentifierSet) {
						if(!groups.contains(groupIdentifier)) {
							isGrpsExists = false;
						}
					}

				}
				
				Set<String> subgroupIdentifierSet = (Set<String>) exchange.getProperty(ManagePaymentInfoServiceConstants.SUB_GROUP_IDENTIFIER_SET);
				Boolean isSubGrpsExists = true;
				if(subgroupIdentifierSet != null && !subgroupIdentifierSet.isEmpty()) {
					for (String subgroupIdentifier : subgroupIdentifierSet) {
						if(!subGroups.contains(subgroupIdentifier)) {
							isSubGrpsExists = false;
						}
					}
					
				}
				if(isSubGrpsExists && isGrpsExists) {
					exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS,
							ManagePaymentInfoServiceConstants.STRING_TRUE);
				} else {
					exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS,
							ManagePaymentInfoServiceConstants.STRING_FALSE);
					ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.WARNING_SECURITY_ERROR_CODE,
							ManagePaymentInfoServiceConstants.MSG_SECURITY_VALID, ManagePaymentInfoServiceConstants.MSG_DESC_GRP_SUBGRP_ERROR);
					ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.WARNING,
							ManagePaymentInfoServiceConstants.WARNING_STATUS_CODE, responseHeader, messages);
				}
				
			}
		} catch(Exception ex) {
			LOGGER.error(METHOD_PROCESS + ManagePaymentInfoServiceConstants.MSG_TECH_ERROR + transactionId + " - " ,ex);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS, ManagePaymentInfoServiceConstants.STRING_FALSE);
			ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR, ManagePaymentInfoServiceConstants.MSG_GROUPS_ERROR_SECURITY);
			ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE,
					ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, responseHeader, messages);
		}
		if(StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.GET_SCHEDULE_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.RETRIEVE_BANK_ACC_INFO_SERVICE)){
			RetrievePaymentInfoResponse response = (RetrievePaymentInfoResponse) exchange
					.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
			response.setResponseHeader(responseHeader);	
		} else if(StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SET_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_CANCEL_SERVICE)||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.SET_PYMNT_SCHED_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.CANCEL_PYMNT_SCHED_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.BATCH_PYMNT_SCHED_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.SUBGROUPS_BANK_ACCOUNT_INFO_SET_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.SUBGROUPS_BANK_ACCOUNT_INFO_CANCEL_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_SET_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_CANCEL_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.MANAGE_ONE_TIME_PYMT_SET) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.MANAGE_ONE_TIME_PYMT_CANCEL) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.ONE_TIME_PAYMENT_GET_SERVICE)){
			SubgroupsSetCancelPaymentResponse response = (SubgroupsSetCancelPaymentResponse) exchange
					.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);	
		} else if(StringUtils.equalsIgnoreCase(autoPymtServiceName, ManagePaymentInfoServiceConstants.CREATE_AUTOPAYMENT_SERVICENAME) ||
				StringUtils.equalsIgnoreCase(autoPymtServiceName, ManagePaymentInfoServiceConstants.CANCEL_AUTOPAYMENT_SERVICENAME)){
			SubgroupsSetCancelPaymentResponse response = (SubgroupsSetCancelPaymentResponse) exchange
					.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);	
		} else if(StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.RETRIEVE_AUTOPAYMENTS_GROUPS_SERVICE) ){
			RetrieveAutoPaymentsResponse response = (RetrieveAutoPaymentsResponse) exchange
					.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);	
		} else if(StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.RETRIEVE_AUTOPAYMENTS_HISTORY_SERVICE) ){
			RetrieveAutoPaymentsHistoryResponse response = (RetrieveAutoPaymentsHistoryResponse) exchange
					.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);	
		}
		
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_EXITING, METHOD_PROCESS);
	}
}
