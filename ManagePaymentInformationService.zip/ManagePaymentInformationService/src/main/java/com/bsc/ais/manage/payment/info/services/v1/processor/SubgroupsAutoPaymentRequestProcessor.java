/*
 * SubgroupsSetCancelPaymentRequestProcessor.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bsc.aip.core.camel.template.BscCamelTemplate;
import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Consumer;
import com.bsc.aip.core.model.common.atomic.Credentials;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;


/**
 * @author Cognizant Technology Solutions.
 * @version 1.0
 *
 */

@Component
public class SubgroupsAutoPaymentRequestProcessor implements Processor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LogManager.getLogger(SubgroupsAutoPaymentRequestProcessor.class);

	/**
	 * Holds the method name.
	 */
	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";

	/**
	 * Obtain an instance of EventLogging
	 */
	@Resource
	private EventLogging eventLogging;

	/**
	 * Holds transaction identifier.
	 */
	private String transactionId = "";
	
	@Resource(name = "bscCamelTemplate")
	private BscCamelTemplate bscCamelTemplate;
	
	/** Value of id_token. */
	@Value("${api.services.security.passthrough}")
	private String idToken;
	
	/*
	 * (non-Javadoc)
	 * 
	 * This method is used to process the Get Schedule service request
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	public void process(Exchange exchange) throws Exception {
		
		// Create an instance of service response
		SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
		
		// Obtain the instance of service request
		SubgroupsSetCancelPaymentRequest request = (SubgroupsSetCancelPaymentRequest) exchange.getIn().getBody();
		
		// Create an instance of list of Audit event
		List<AuditEvent> auditEventList = new ArrayList<AuditEvent>();
		try {
			
			// set the instance of service request to exchange as property
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);

			// Get transaction id from the request.
			if ((null != request) && (null != request.getRequestHeader())) {
				transactionId = (String) request.getRequestHeader().getTransactionId();
				exchange.setProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID, transactionId);
				exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQ_HEADER,
						request.getRequestHeader());
			}

			LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_ENTERING
					  + METHOD_PROCESS);

			// Logging event for the request.
			eventLogging.logEvent(request.getRequestHeader(), null,
					ManagePaymentInfoServiceConstants.AUDIT,
					ManagePaymentInfoServiceConstants.ENTRY, null, null, null, null,
					(String) exchange.getProperty(
							ManagePaymentInfoServiceConstants.SERVICE_NAME));
			
			// adding transactionId to request header
			if (StringUtils.isEmpty(
					(String) exchange.getIn().getHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID)))
				exchange.getIn().setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID,
						transactionId);
			//validation for request header and request body
			if (validateRequestHeader(request, response) && validateRequestBody(request, response, exchange)
					&& validateRequestStructure(request)) {
				exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS,
						ManagePaymentInfoServiceConstants.STRING_TRUE);
				response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(
						ManagePaymentInfoServiceConstants.SUCCESS,
						ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE, null, null));
				setExchangeProps(request , exchange);
			} else {
				exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS,
						ManagePaymentInfoServiceConstants.STRING_FALSE);
				LOGGER.info(transactionId + " - " + METHOD_PROCESS  +"Request is invalid.");
				
				//audit logging
				//ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.GET_SCHEDULE_EVENT_FAILURE_CODE);
			}
			response.getResponseHeader().getTransactionNotification().setTransactionId(transactionId);

		} catch (Exception ex) {
			LOGGER.error(transactionId + " - " + METHOD_PROCESS , ex);
			List<Message> messages = new ArrayList<Message>();
			ManagePaymentInfoServiceUtil.addMessage(messages,
					ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);
			response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(
					ManagePaymentInfoServiceConstants.FAILURE,
					ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, null, messages));
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			//audit logging
			ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.GET_SCHEDULE_EVENT_FAILURE_CODE);
		}
		response.setResponseBody(null);
		exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESP_HEADER, response.getResponseHeader());
		exchange.getIn().setBody(response);
		
		//call security validation
		String validationSuccess = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS);
		String userIdentifier = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER);
		if(StringUtils.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_TRUE, validationSuccess)
				&& StringUtils.isNotBlank(userIdentifier) && 
				!request.getRequestHeader().getConsumer().getName().equalsIgnoreCase(ManagePaymentInfoServiceConstants.IVR)){
		Credentials credentials = request.getRequestHeader().getCredentials();
		if (credentials != null) {
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_ID_TOKEN, credentials.getToken());
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_REFRESH_TOKEN, ManagePaymentInfoServiceConstants.EMPTY_STR);
			if (!StringUtils.equals(credentials.getToken(), idToken)) {
				bscCamelTemplate.getProducerTemplate()
						.send("direct:empPymtSecurityValidationProcessorCall", exchange);
		}
		}
		}
		LOGGER.debug(ManagePaymentInfoServiceConstants.METHOD_EXITING  +METHOD_PROCESS+ transactionId);

	}
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * This method is used to set the input parameters to exchange object
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	private void setExchangeProps(SubgroupsSetCancelPaymentRequest request, Exchange exchange) {
		LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_ENTERING + "setExchangeProps");
		Set<String> groupIdentifierSet = new HashSet<>();
		Set<String> subGroupIdentifierSet = new HashSet<>();
		if(StringUtils.isNotBlank( request.getRequestBody().getUserIdentifier())){
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER, request.getRequestBody().getUserIdentifier().trim());
		}
		if (ManagePaymentInfoServiceConstants.CREATE_AUTOPAYMENT_SERVICENAME
				.equals(exchange.getProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME))) {
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
					ManagePaymentInfoServiceConstants.SET_PYMNT_SCHED_SERVICE);
		} else {
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
					ManagePaymentInfoServiceConstants.CANCEL_PYMNT_SCHED_SERVICE);
		}
		if (null != request.getRequestBody().getPaymentInformations()
				&& !request.getRequestBody().getPaymentInformations().getPaymentInformation().isEmpty()) {
			for (PaymentInformation paymentInformation : request.getRequestBody().getPaymentInformations()
					.getPaymentInformation()) {
				if(StringUtils.isNotBlank(paymentInformation.getGroupIdentifier())){
					groupIdentifierSet.add(paymentInformation.getGroupIdentifier());
				}
				exchange.setProperty(ManagePaymentInfoServiceConstants.SUB_GROUP_ID,
						paymentInformation.getSubgroupIdentifier());
				if (!StringUtils.isBlank(paymentInformation.getSubgroupIdentifier())) {
					subGroupIdentifierSet.add(paymentInformation.getSubgroupIdentifier());
					exchange.setProperty(ManagePaymentInfoServiceConstants.GROUP_ID,
							paymentInformation.getSubgroupIdentifier().substring(0, 8));
				}
				exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PAYMENT_NOTIFICATION_MSG,
						paymentInformation.getPaymentNotificationMsg());
			}
		}
		exchange.setProperty(ManagePaymentInfoServiceConstants.GROUP_IDENTIFIER_SET,groupIdentifierSet);
		exchange.setProperty(ManagePaymentInfoServiceConstants.SUB_GROUP_IDENTIFIER_SET,subGroupIdentifierSet);

	}

	/**
	 * Method to validate the request structure.
	 * 
	 * @param request
	 * @return
	 */
	private boolean validateRequestStructure(SubgroupsSetCancelPaymentRequest request) {

		boolean isSuccess = true;
		List<Message> messages = new ArrayList<Message>();
		if (request == null) {
			isSuccess = false;
			ManagePaymentInfoServiceUtil.addMessage(messages,
					ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
					ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
					ManagePaymentInfoServiceConstants.MSG_DESC_INVALID_PAYLOAD);

		}
		return isSuccess;
	}

	/**
	 * Method to validate the request body.
	 * 
	 * @param request
	 * @param exchange
	 * @return
	 */
	private boolean validateRequestBody(SubgroupsSetCancelPaymentRequest request,
			SubgroupsSetCancelPaymentResponse response , Exchange exchange) {

		LOGGER.debug(transactionId + " - " +  ManagePaymentInfoServiceConstants.METHOD_ENTERING
				   +"validateRequestBody");
		boolean isSuccess = true;
		List<Message> messages = new ArrayList<Message>();
		String serviceName = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME);
		try {
			if (request != null && request.getRequestBody() != null) {
				
				if ((isSuccess)&&StringUtils.isBlank(request.getRequestBody().getUserIdentifier())){
					isSuccess = false;
					ManagePaymentInfoServiceUtil.addMessage(messages,
							ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
							ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
							ManagePaymentInfoServiceConstants.MSG_DESC_MAND_USER_IDENTIFIER);
				}							
				if (null != request.getRequestBody().getPaymentInformations() && 
						null != request.getRequestBody().getPaymentInformations().getPaymentInformation() &&
						!request.getRequestBody().getPaymentInformations().getPaymentInformation().isEmpty()) {

					for (PaymentInformation paymentInformation : request.getRequestBody().getPaymentInformations()
							.getPaymentInformation()) {
						if (!isSuccess)
							break;

						if (isSuccess && (null == paymentInformation.getAccountNickName()
								|| StringUtils.isBlank(paymentInformation.getAccountNickName()))) {
							isSuccess = false;
							ManagePaymentInfoServiceUtil.addMessage(messages,
									ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
									ManagePaymentInfoServiceConstants.SCS_MSG_DESC_MAND_ACCOUNT_NICK_NAME);
						}
						if (isSuccess && serviceName.equals(ManagePaymentInfoServiceConstants.CREATE_AUTOPAYMENT_SERVICENAME) &&
								(null == paymentInformation.getPaymentNotificationMsg()
								|| StringUtils.isBlank(paymentInformation.getPaymentNotificationMsg()))) {							
								isSuccess = false;
								ManagePaymentInfoServiceUtil.addMessage(messages,
										ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
										ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
										ManagePaymentInfoServiceConstants.SCS_MSG_DESC_MAND_PYMT_NOTIFICATION_MSG);
							
						}

						if (isSuccess && (StringUtils.isBlank(paymentInformation.getSubgroupIdentifier())
								|| paymentInformation.getSubgroupIdentifier().length() != 12 )) {
							isSuccess = false;
							ManagePaymentInfoServiceUtil.addMessage(messages,
									ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_DESC_MAND_SUBGROUPID);
						}

						if (serviceName.equals(ManagePaymentInfoServiceConstants.CREATE_AUTOPAYMENT_SERVICENAME)) {
							if (isSuccess && (StringUtils.isBlank(paymentInformation.getPaymentFlag())
									|| !(null != paymentInformation.getPaymentFlag()
											&& ManagePaymentInfoServiceConstants.STRING_YES
													.equalsIgnoreCase(paymentInformation.getPaymentFlag())
											|| ManagePaymentInfoServiceConstants.STRING_NO
													.equalsIgnoreCase(paymentInformation.getPaymentFlag())))) {
								isSuccess = false;
								ManagePaymentInfoServiceUtil.addMessage(messages,
										ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
										ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
										ManagePaymentInfoServiceConstants.SCS_MSG_DESC_MAND_PAYMENT_FLAG);
							} 
						}
					}
				} else {
					isSuccess = false;						
					ManagePaymentInfoServiceUtil.addMessage(messages,
							ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
							ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
							ManagePaymentInfoServiceConstants.MISSING_PAYMENT_INFOMRATION_MSG);
				}			
				
			} else {
				ManagePaymentInfoServiceUtil.addMessage(messages,
						ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
						ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
						ManagePaymentInfoServiceConstants.MSG_DESC_MAND_BUSINESS_REQ_BODY);

			}
		} catch (Exception ex) {
			isSuccess = false;
			ManagePaymentInfoServiceUtil.addMessage(messages,
					ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
					ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
					ManagePaymentInfoServiceConstants.ERROR_DESCRIPTION_REQ);
		}

		if (!messages.isEmpty()) {
			response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(
					ManagePaymentInfoServiceConstants.FAILURE,
					ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, response.getResponseHeader(),
					messages));
			isSuccess = false;
		}

		LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_EXITING
				 +"validateRequestBody");

		return isSuccess;

	}

	/**
	 * Method to validate the request header.
	 *
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return
	 */
	private boolean validateRequestHeader(SubgroupsSetCancelPaymentRequest request,
			SubgroupsSetCancelPaymentResponse response) {

		LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_ENTERING
				 +"validateRequestHeader");
		boolean isSuccess = true;
		List<Message> messages = new ArrayList<Message>();

		try {
			if (request != null && request.getRequestHeader() != null) {
				if (StringUtils.isBlank(request.getRequestHeader().getTransactionId())) {
					ManagePaymentInfoServiceUtil.addMessage(messages,
							ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
							ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
							ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_TRANSACTION_ID);
					isSuccess = false;
				}
				if (isSuccess) {
					if (request.getRequestHeader().getConsumer() != null) {

						Consumer consumer = request.getRequestHeader().getConsumer();

						if (isSuccess && StringUtils.isBlank(consumer.getName())) {
							isSuccess = false;
							ManagePaymentInfoServiceUtil.addMessage(messages,
									ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_CONSUMER);
						}
						if (isSuccess && StringUtils.isBlank(consumer.getId())) {
							isSuccess = false;
							ManagePaymentInfoServiceUtil.addMessage(messages,
									ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_CONSUMER);
						}
						if (isSuccess && StringUtils.isBlank(consumer.getType())) {
							isSuccess = false;
							ManagePaymentInfoServiceUtil.addMessage(messages,
									ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_CONSUMER);
						}
						if (isSuccess && StringUtils.isBlank(consumer.getBusinessUnit())) {
							isSuccess = false;
							ManagePaymentInfoServiceUtil.addMessage(messages,
									ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_CONSUMER);
						}
						if (isSuccess && StringUtils.isBlank(consumer.getHostName())) {
							isSuccess = false;
							ManagePaymentInfoServiceUtil.addMessage(messages,
									ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_CONSUMER);
						}
					} else {
						isSuccess = false;
						ManagePaymentInfoServiceUtil.addMessage(messages,
								ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
								ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
								ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_CONSUMER);
					}

				}
				

				if (isSuccess && !request.getRequestHeader().getConsumer().getName().equalsIgnoreCase(ManagePaymentInfoServiceConstants.IVR)) {
					if (request.getRequestHeader().getCredentials() != null) {

						Credentials credentials = request.getRequestHeader().getCredentials();

						if (isSuccess && StringUtils.isBlank(credentials.getToken())) {
							isSuccess = false;
							ManagePaymentInfoServiceUtil.addMessage(messages,
									ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_DESC_TOKEN);
						}
						if (isSuccess && StringUtils.isBlank(credentials.getType())) {
							isSuccess = false;
							ManagePaymentInfoServiceUtil.addMessage(messages,
									ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_DESC_TOKEN_TYPE);
						}
					} else {
						isSuccess = false;
						ManagePaymentInfoServiceUtil.addMessage(messages,
								ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
								ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
								ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_CREDENTIALS);
					}
				}
			} else {
				ManagePaymentInfoServiceUtil.addMessage(messages,
						ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
						ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
						ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_HEADER);
			}
		} catch (Exception ex) {
			ManagePaymentInfoServiceUtil.addMessage(messages,
					ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
					ManagePaymentInfoServiceConstants.ERROR_DESCRIPTION_REQ);
		}

		if (!messages.isEmpty()) {
			response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(
					ManagePaymentInfoServiceConstants.FAILURE,
					ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, response.getResponseHeader(),
					messages));
			isSuccess = false;
		}

		LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_EXITING
				  +"validateRequestHeader");

		return isSuccess;
	}

}
