/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceDBConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceDbUtil;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;

/**
 * @author Cognizant
 *
 */
@Component("retrieveBankAccInfoDataProcessor")
public class RetrieveBankAccInfoDataProcessor implements Processor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LogManager.getLogger(RetrieveBankAccInfoDataProcessor.class);

	/** The event logging. */
	@Resource(name = "eventLogging")
	private EventLogging eventLogging;

	@Resource
	private ManagePaymentInfoServiceDbUtil managePaymentInfoServiceDbUtil;

	/**
	 * Holds the method name.
	 */
	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";

	/*
	 * (non-Javadoc)
	 * 
	 * This method is used to populate the parameter name and its value to the
	 * response object.
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	@SuppressWarnings("unchecked")
	public void process(Exchange exchange) throws Exception {

		// Obtain transaction id for logging purpose.
		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_ENTERING + METHOD_PROCESS);

		// Obtain an instance of response from exchange object.
		RetrievePaymentInfoResponse response = (RetrievePaymentInfoResponse) exchange
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);

		// Create an instance of ArrayList to hold response messages.
		List<Message> messages = new ArrayList<Message>();
		Map<String, List<String>> groupInfoMap = (Map<String, List<String>>) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_MAP);
		
		List<String> subGroupIdentifierList = (List<String>) exchange
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST);
		List<PaymentInformation> paymentInformationList = new ArrayList<PaymentInformation>();

		try {
			
			// get the count of valid SubGroupIdentifier present in FACETS
			// database
			LOGGER.debug(transactionId + " - " +"validating group sub group info");
			List<Map<String, Object>> GrpSubGrpRows = managePaymentInfoServiceDbUtil.obtainDistGrpId(groupInfoMap);

			if (null != GrpSubGrpRows && !GrpSubGrpRows.isEmpty()) {
				if (GrpSubGrpRows.size() == 1) {
					LOGGER.debug(transactionId + " - " +"subgroups under single parent group");
					String distinctGroupId = (String) GrpSubGrpRows.get(0)
							.get(ManagePaymentInfoServiceDBConstants.GRGR_ID);
					// validate distinct group id
					Timestamp termDate = (Timestamp) GrpSubGrpRows.get(0)
							.get(ManagePaymentInfoServiceDBConstants.GRGR_TERM_DT);
					List<String> lSubgrpIdActArray = new ArrayList<String>();
					if (null != termDate && (new Date().before(termDate) || new Date().equals(termDate))) {
						LOGGER.debug(transactionId + " - " +"sysdate before or equal to term date");
						List<Map<String, Object>> validSubGrpIdRows = managePaymentInfoServiceDbUtil
								.obtainActSubGrp(distinctGroupId);
						if (null != validSubGrpIdRows && !validSubGrpIdRows.isEmpty() && validSubGrpIdRows.size() > 0) {
							LOGGER.debug(transactionId + " - " +"getting active sub group identifiers from db");
							for (Map<String, Object> row : validSubGrpIdRows) {
								lSubgrpIdActArray
										.add((String) row.get(ManagePaymentInfoServiceDBConstants.SUB_GRP_IDS));
							}
						}
						// Retrieve bank info for actibe sub grps
						if (!lSubgrpIdActArray.isEmpty()) {
							List<String> activeSgsgId = new ArrayList<String>();
							String grgrId = lSubgrpIdActArray.get(0).substring(0, 8);
							for (String sgsg : lSubgrpIdActArray) {
								activeSgsgId.add(sgsg.substring(8, 12));
							}
							List<Map<String, Object>> validBankInfoSubGrpIdRows = managePaymentInfoServiceDbUtil
									.validateBankInfoActSubGrp(grgrId, activeSgsgId);
							List<String> SubgrpIdAccArray = new ArrayList<String>();
							String lsubGrp = null;
							if (null != validBankInfoSubGrpIdRows && !validBankInfoSubGrpIdRows.isEmpty()) {
								LOGGER.debug(transactionId + " - " +"getting sub group identifiers which is having bank information");
								lsubGrp = (String) validBankInfoSubGrpIdRows.get(0)
										.get(ManagePaymentInfoServiceDBConstants.SGSG_ID);
								for (Map<String, Object> row : validBankInfoSubGrpIdRows) {
									SubgrpIdAccArray.add((String) row.get(ManagePaymentInfoServiceDBConstants.SGSG_ID));

								}
							}

							// new sub groups
							List<String> lSubgrpIdArray = new ArrayList<String>();
							for (String sgsg : lSubgrpIdActArray) {
								if (!SubgrpIdAccArray.contains(sgsg)) {
									LOGGER.debug(transactionId + " - " +"new sub groups which is not having associated bank info");
									lSubgrpIdArray.add(sgsg);
								}
								
							}
							
							// iterate the new sub groups
							if (lSubgrpIdArray.size() != lSubgrpIdActArray.size() && lSubgrpIdArray.size() > 0) {
							
								// retrieve bank details to set up for the new
								// sub groups
								List<Map<String, Object>> bankInfoSubGrpIdRows = null;
								if(StringUtils.isNotBlank(lsubGrp)){
								 bankInfoSubGrpIdRows = managePaymentInfoServiceDbUtil
										.obtainBankDetails(lsubGrp.substring(0, 8), lsubGrp.substring(8, 12));
								 LOGGER.debug(transactionId + " - " +"retrieving bank info for existing single sub group");
								}
								final List<String> allinsertStatements = new ArrayList<String>();
								List<String> insertStatements = new ArrayList<String>();
								for (String sgsgId : lSubgrpIdArray) {
						
									// retrieve the BLEI_CK
									int billCkCount = managePaymentInfoServiceDbUtil
											.validateBillInfoCount(sgsgId.substring(0, 8), sgsgId.substring(8, 12));

									if (billCkCount > 0) {
										String bleiCk = managePaymentInfoServiceDbUtil
												.obtainBillInfo(sgsgId.substring(0, 8), sgsgId.substring(8, 12));
										if (null != bankInfoSubGrpIdRows && !bankInfoSubGrpIdRows.isEmpty()
												&& bankInfoSubGrpIdRows.size() > 0) {

											insertStatements = managePaymentInfoServiceDbUtil.insertPayment(bleiCk,
													bankInfoSubGrpIdRows);
											allinsertStatements.addAll(insertStatements);
										}
									}
									
								}

								if (!allinsertStatements.isEmpty()) {
									int countInsertRows = managePaymentInfoServiceDbUtil
											.insertQueriesForPayment(allinsertStatements);
									LOGGER.debug(transactionId + " - " +"inserting bank information for new sub groups");
									if (countInsertRows < 0) {

										ManagePaymentInfoServiceUtil.addMessage(messages,
												ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
												ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
												ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);

									}
								}

							}
						}

					}

					// RETRIEVE BANK INFO FOR GIVEN VALID ARAY OF SUB GROUP
					// IDENITIFERS
                 if ( null == messages || messages.isEmpty()){
					// get the payment information
					List<Map<String, Object>> paymentRows = managePaymentInfoServiceDbUtil
							.paymentInfoForBankAcc(distinctGroupId, groupInfoMap.get(distinctGroupId));

					if ( null != paymentRows && !paymentRows.isEmpty()) {
						// iterate and populate the payment Information List
						for (Map<String, Object> row : paymentRows) {

							// create a instance of PaymentInformation object
							PaymentInformation paymentInformation = new PaymentInformation();
							paymentInformation.setAccountNickName(
									(String) row.get(ManagePaymentInfoServiceDBConstants.ACC_NICK_NAME));
							paymentInformation.setAccountHolderName(
									(String) row.get(ManagePaymentInfoServiceDBConstants.ACC_HOLDER_NAME));
							paymentInformation
									.setAccountNumber((String) row.get(ManagePaymentInfoServiceDBConstants.ACC_NUMBER));
							paymentInformation.setRoutingNumber(
									(String) row.get(ManagePaymentInfoServiceDBConstants.ROUTING_NUMBER));
							paymentInformation
									.setBankAccountType((String) row.get(ManagePaymentInfoServiceDBConstants.ACC_TYPE));
							paymentInformation
									.setPaymentFlag((String) row.get(ManagePaymentInfoServiceDBConstants.PAYMENT_FLAG));
							paymentInformation.setSubgroupIdentifier(
									(String) row.get(ManagePaymentInfoServiceDBConstants.SUB_GROUP_IDEN));
							paymentInformation.setSubgroupName(
									(String) row.get(ManagePaymentInfoServiceDBConstants.SUB_GROUP_NAME));
							// add to paymentInformationList only if
							// SubgroupIdentifier matches is valid and passed in
							// request
							if (subGroupIdentifierList.contains(paymentInformation.getSubgroupIdentifier())) {
								paymentInformationList.add(paymentInformation);
							}
						}
					} else { // no data returned from database
						ManagePaymentInfoServiceUtil.addMessage(messages,
								ManagePaymentInfoServiceConstants.MSG_CODE_NO_DATA_FOUND,
								ManagePaymentInfoServiceConstants.MSG_DATA_NOT_FOUND,
								ManagePaymentInfoServiceConstants.MSG_DESC_NO_DATA_FOUND);

						LOGGER.debug(transactionId + " - "
								+ "No matching payment data present for the given list of subGroupIdentifiers");
					}
                 }
				} else { // no data returned from database
					ManagePaymentInfoServiceUtil.addMessage(messages,
							ManagePaymentInfoServiceConstants.MSG_CODE_SUBGRP_NOT_MATCH,
							ManagePaymentInfoServiceConstants.MSG_SUBGRP_NOT_MATCH,
							ManagePaymentInfoServiceConstants.MSG_SUBGRP_NOT_MATCH);

					LOGGER.debug(transactionId + " - "
							+ "No matching payment data present for the given list of subGroupIdentifiers");
				}

			} else { // no data returned from database
				ManagePaymentInfoServiceUtil.addMessage(messages,
						ManagePaymentInfoServiceConstants.MSG_CODE_NO_DATA_FOUND,
						ManagePaymentInfoServiceConstants.MSG_DATA_NOT_FOUND,
						ManagePaymentInfoServiceConstants.MSG_DESC_SUBGROUP_INVALID);

				LOGGER.debug(transactionId + " - "
						+ "No matching payment data present for the given list of subGroupIdentifiers");
			}

			if (!messages.isEmpty()) {
				exchange.setProperty(ManagePaymentInfoServiceConstants.FACETS_EXCEPTION, ManagePaymentInfoServiceConstants.STRING_TRUE);
				response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(
						ManagePaymentInfoServiceConstants.WARNING,
						ManagePaymentInfoServiceConstants.WARNING_STATUS_CODE, response.getResponseHeader(), messages));
				messages.clear();
			}

		} catch (Exception ex) {
			LOGGER.error(transactionId + " - " + METHOD_PROCESS, ex);
			exchange.setProperty(ManagePaymentInfoServiceConstants.FACETS_EXCEPTION, ManagePaymentInfoServiceConstants.STRING_TRUE);
			ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR, ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);

			if (!messages.isEmpty()) {
				response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(
						ManagePaymentInfoServiceConstants.FAILURE,
						ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, response.getResponseHeader(), messages));
			}
		}
		// set the response to exchange object
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_PAYMENT_INFO_LIST, paymentInformationList);
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
		response.setResponseBody(null);
		exchange.getIn().setBody(response);

		LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_EXITING + METHOD_PROCESS);
	}
}
