package com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AuditEvent {

	private String groupIdentifier;
	private String userRoleType;
	private String activationCode;
	private String eventDate;
	private String userIpAddress;
	private String sessionId;
	private String memberNumber;
	private String eventTime;
	private String userAccessIdentifier;
	private String featureAssignIdentifier;
	private String adminUserType;
	private String userIdentifier;
	private String productIdentifier;
	private String memberSSN;
	private String lockStatus;
	private String subscriberIdentifier;
	private String groupSubgroupIdentifier;
	private String viewedUserIdentifier;
	private String registrationAttemptIdentifier;
	private String eventCode;

	public String getGroupIdentifier() {
		return groupIdentifier;
	}

	public void setGroupIdentifier(String groupIdentifier) {
		this.groupIdentifier = groupIdentifier;
	}

	public String getUserRoleType() {
		return userRoleType;
	}

	public void setUserRoleType(String userRoleType) {
		this.userRoleType = userRoleType;
	}

	public String getActivationCode() {
		return activationCode;
	}

	public void setActivationCode(String activationCode) {
		this.activationCode = activationCode;
	}
	
	public String getEventDate() {
		return eventDate;
	}

	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}

	public String getUserIpAddress() {
		return userIpAddress;
	}

	public void setUserIpAddress(String userIpAddress) {
		this.userIpAddress = userIpAddress;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getMemberNumber() {
		return memberNumber;
	}

	public void setMemberNumber(String memberNumber) {
		this.memberNumber = memberNumber;
	}

	public String getEventTime() {
		return eventTime;
	}

	public void setEventTime(String eventTime) {
		this.eventTime = eventTime;
	}

	public String getUserAccessIdentifier() {
		return userAccessIdentifier;
	}

	public void setUserAccessIdentifier(String userAccessIdentifier) {
		this.userAccessIdentifier = userAccessIdentifier;
	}

	public String getFeatureAssignIdentifier() {
		return featureAssignIdentifier;
	}

	public void setFeatureAssignIdentifier(String featureAssignIdentifier) {
		this.featureAssignIdentifier = featureAssignIdentifier;
	}

	public String getAdminUserType() {
		return adminUserType;
	}

	public void setAdminUserType(String adminUserType) {
		this.adminUserType = adminUserType;
	}

	public String getUserIdentifier() {
		return userIdentifier;
	}

	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}

	public String getProductIdentifier() {
		return productIdentifier;
	}

	public void setProductIdentifier(String productIdentifier) {
		this.productIdentifier = productIdentifier;
	}

	public String getMemberSSN() {
		return memberSSN;
	}

	public void setMemberSSN(String memberSSN) {
		this.memberSSN = memberSSN;
	}

	public String getLockStatus() {
		return lockStatus;
	}

	public void setLockStatus(String lockStatus) {
		this.lockStatus = lockStatus;
	}

	public String getSubscriberIdentifier() {
		return subscriberIdentifier;
	}

	public void setSubscriberIdentifier(String subscriberIdentifier) {
		this.subscriberIdentifier = subscriberIdentifier;
	}

	public String getGroupSubgroupIdentifier() {
		return groupSubgroupIdentifier;
	}

	public void setGroupSubgroupIdentifier(String groupSubgroupIdentifier) {
		this.groupSubgroupIdentifier = groupSubgroupIdentifier;
	}

	public String getViewedUserIdentifier() {
		return viewedUserIdentifier;
	}

	public void setViewedUserIdentifier(String viewedUserIdentifier) {
		this.viewedUserIdentifier = viewedUserIdentifier;
	}

	public String getRegistrationAttemptIdentifier() {
		return registrationAttemptIdentifier;
	}

	public void setRegistrationAttemptIdentifier(String registrationAttemptIdentifier) {
		this.registrationAttemptIdentifier = registrationAttemptIdentifier;
	}

	public String getEventCode() {
		return eventCode;
	}

	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}
}
