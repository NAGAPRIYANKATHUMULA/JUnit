/*
 * RetrieveAutoPaymentsHistoryDataProcessor.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceDBConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.response.AutoPaymentHistoryInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsHistoryResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceWPRDbUtil;





/**
 * <HTML> This processor is used to retrieve data about auto payments from WPR database 
 * </HTML>.
 *
 * @author Cognizant Technology Solutions.
 * @version 1.0
 * 
 */

@Component("retrieveAutoPaymentsHistoryDataProcessor")
public class RetrieveAutoPaymentsHistoryDataProcessor implements Processor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LogManager.getLogger(RetrieveAutoPaymentsHistoryDataProcessor.class);

	/** The event logging. */
	@Resource(name = "eventLogging")
	private EventLogging eventLogging;
	
	/**
	 * Holds the method name.
	 */
	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";
	
	@Resource
	private ManagePaymentInfoServiceWPRDbUtil managePaymentInfoServiceWPRDbUtil;

	/*
	 * (non-Javadoc)
	 * 
	 * This method is used to populate the  parameter name and its value to the response object.
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	@SuppressWarnings("unchecked")
	public void process(Exchange exchange) throws Exception {
		
		// Obtain transaction id for logging purpose.
		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_ENTERING + METHOD_PROCESS);
		
		// Obtain an instance of response from exchange object.
		RetrieveAutoPaymentsHistoryResponse response = (RetrieveAutoPaymentsHistoryResponse) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
		
		// Obtain an instance of audit list from exchange object.
		List<AuditEvent> auditEventList = (List<AuditEvent>) exchange.getProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST);
		
		// Create an instance of ArrayList to hold response messages.
		List<Message> messages = new ArrayList<Message>();
		
		try {
		
		//Get all the values from exchange object and use it for census retrieval	
		String groupIdentifier = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER);
		String userName = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_NAME);
		String fromDate = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_FROM_DATE);
		String toDate = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_TO_DATE);
		String action = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_ACTION);
		String startIndex = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_START_INDEX);
		String endIndex = (String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_END_INDEX);
		
		exchange.setProperty(ManagePaymentInfoServiceConstants.IS_HISTORYINFO_PRESENT, ManagePaymentInfoServiceConstants.STRING_FALSE);
		int totalHistoryCount = 0;
		
		//Execute WPR database query to obtain totalHistoryCount value
		if(null != groupIdentifier && null != userName && null != fromDate && null != toDate && null != action){
			totalHistoryCount = managePaymentInfoServiceWPRDbUtil.retrieveTotalHistoryCountByUserNameAndAction(groupIdentifier,userName,fromDate,toDate,action);
		
		if(totalHistoryCount > 0 && StringUtils.isNotBlank(endIndex) && endIndex.equalsIgnoreCase(ManagePaymentInfoServiceConstants.INDEX_ZERO)){
			startIndex = ManagePaymentInfoServiceConstants.INDEX_ONE;
			endIndex = String.valueOf(totalHistoryCount);
		}else if(totalHistoryCount > 0 && StringUtils.isBlank(startIndex) && StringUtils.isNotBlank(endIndex)){
			startIndex = ManagePaymentInfoServiceConstants.INDEX_ZERO;
		}else if(totalHistoryCount > 0 && StringUtils.isNotBlank(startIndex) && StringUtils.isBlank(endIndex)){
			endIndex = String.valueOf(totalHistoryCount);
		}
		
		if(totalHistoryCount > 0){//Retrieve the userName,action,date and subGroupIdentifier values using below query.
			List<Map<String, Object>> autoPaymentHistoryInfoRows = managePaymentInfoServiceWPRDbUtil.retrieveAutoPaymentHistoryInfo(groupIdentifier,userName,fromDate,toDate,action,startIndex,endIndex);
			if(null != autoPaymentHistoryInfoRows && !autoPaymentHistoryInfoRows.isEmpty()){
				List<String> subGroupIdList = new ArrayList<String>();
				List<AutoPaymentHistoryInformation> autoPaymentHistoryInformationList = new ArrayList<AutoPaymentHistoryInformation>();
				for(Map<String, Object> row: autoPaymentHistoryInfoRows){
					AutoPaymentHistoryInformation autoPaymentHistoryInformation = new AutoPaymentHistoryInformation();
					autoPaymentHistoryInformation.setAction((String)row.get(ManagePaymentInfoServiceDBConstants.ACT_NM));
					Timestamp dateTime = (Timestamp)row.get(ManagePaymentInfoServiceDBConstants.PMT_ACT_DT);
					autoPaymentHistoryInformation.setDate(ManagePaymentInfoServiceUtil.convertDateToString(new Date(dateTime.getTime()), ManagePaymentInfoServiceConstants.DATE_TIME_FORMAT));
					autoPaymentHistoryInformation.setUserName((String)row.get(ManagePaymentInfoServiceDBConstants.USR_NM));
					autoPaymentHistoryInformation.setSubgroupIdentifier((String)row.get(ManagePaymentInfoServiceDBConstants.GRP_SUB_GRP_NBR));
					autoPaymentHistoryInformation.setAccountNickName((String)row.get(ManagePaymentInfoServiceDBConstants.BNK_ACCT_NCKNM));
					autoPaymentHistoryInformation.setAccountNumber("");
					autoPaymentHistoryInformation.setRoutingNumber("");
					autoPaymentHistoryInformationList.add(autoPaymentHistoryInformation);
					subGroupIdList.add(autoPaymentHistoryInformation.getSubgroupIdentifier());
				}
				exchange.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENTS_HISTORY_INFO_LIST,autoPaymentHistoryInformationList);
				exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUBGROUP_IDENTIFIER_LIST,subGroupIdList);
				exchange.setProperty(ManagePaymentInfoServiceConstants.IS_HISTORYINFO_PRESENT, ManagePaymentInfoServiceConstants.STRING_TRUE);
			}
		}else {
			LOGGER.debug(transactionId + " - "+ "auto payment history info is not available in WPR Database.");
			ManagePaymentInfoServiceUtil.addMessage(messages,
					ManagePaymentInfoServiceConstants.MSG_CODE_NO_DATA_FOUND,
					ManagePaymentInfoServiceConstants.MSG_DATA_NOT_FOUND,
					ManagePaymentInfoServiceConstants.MSG_HISTORY_DATA_NOT_FOUND);
			//audit logging
			ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.RETRIEVE_AUTOPAYMENTS_HISTORY_EVENT_FAILURE_CODE);
		}
		
		}else{ //obtain totalHistoryCount value only using groupIdentifier
			totalHistoryCount = managePaymentInfoServiceWPRDbUtil.retrieveTotalHistoryCountByGroupIdentifier(groupIdentifier);
			
			if(!(totalHistoryCount > 0)){
				LOGGER.debug(transactionId + " - "+ "auto payment history info is not available in WPR Database.");
				ManagePaymentInfoServiceUtil.addMessage(messages,
						ManagePaymentInfoServiceConstants.MSG_CODE_NO_DATA_FOUND,
						ManagePaymentInfoServiceConstants.MSG_DATA_NOT_FOUND,
						ManagePaymentInfoServiceConstants.MSG_HISTORY_DATA_NOT_FOUND);
				//audit logging
				ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.RETRIEVE_AUTOPAYMENTS_HISTORY_EVENT_FAILURE_CODE);
			}
		}
		
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_TOTAL_HISTORY_COUNT, String.valueOf(totalHistoryCount));
		
		if (!messages.isEmpty()) {
			response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.WARNING,
					ManagePaymentInfoServiceConstants.WARNING_STATUS_CODE, response.getResponseHeader(), messages));
			messages.clear();
		}
		
		
		}catch (Exception ex) {
			LOGGER.error(transactionId + " - "+ METHOD_PROCESS , ex);
			ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);
			
			//audit logging
			ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.RETRIEVE_AUTOPAYMENTS_EVENT_FAILURE_CODE);
		}
		
		if (!messages.isEmpty()) {
			response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE,
					ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, response.getResponseHeader(), messages));
		}
		
		//set the response to exchange object
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
		exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
		response.setResponseBody(null);
		exchange.getIn().setBody(response);
		
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_EXITING + METHOD_PROCESS);
	}
	
}
