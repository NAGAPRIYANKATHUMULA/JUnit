package com.bsc.ais.manage.payment.info.services.v1.model.request.receipts;

import com.bsc.aip.core.model.common.composite.RequestHeader;

/**
 * This is the Patient Accumulator Service Request Pojo
 * 
 * @author Cognizant Technology Solutions
 *
 */
public class RetrieveReceiptsForSubGroupRequest {

	private RequestHeader requestHeader;

	private RetrieveReceiptsForSubGroupRequestBody requestBody;

	/**
	 * 
	 * @return 
	 */
	public RequestHeader getRequestHeader() {
		return requestHeader;
	}

	/**
	 * requestHeader to set
	 * @param requestHeader
	 */
	public void setRequestHeader(RequestHeader requestHeader) {
		this.requestHeader = requestHeader;
	}

	/**
	 * @return the requestBody
	 */
	public RetrieveReceiptsForSubGroupRequestBody getRequestBody() {
		return requestBody;
	}

	/**
	 * @param requestBody the requestBody to set
	 */
	public void setRequestBody(RetrieveReceiptsForSubGroupRequestBody requestBody) {
		this.requestBody = requestBody;
	}

	

}
