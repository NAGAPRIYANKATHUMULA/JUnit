/*
 * SendNotificationServiceRequest.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */

package com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional;

import com.bsc.aip.core.model.common.composite.RequestHeader;

/**
 * SendNotificationServiceRequest
 * @author Cognizant
 *
 */
public class SendNotificationServiceRequest {

	private RequestHeader requestHeader;
	private SendNotificationServiceRequestBody requestBody;

	/**
	 * @return
	 */
	public RequestHeader getRequestHeader() {
		return requestHeader;
	}

	/**
	 * @param requestHeader
	 */
	public void setRequestHeader(RequestHeader requestHeader) {
		this.requestHeader = requestHeader;
	}

	/**
	 * @return the requestBody
	 */
	public SendNotificationServiceRequestBody getRequestBody() {
		return requestBody;
	}

	/**
	 * @param requestBody the requestBody to set
	 */
	public void setRequestBody(SendNotificationServiceRequestBody requestBody) {
		this.requestBody = requestBody;
	}
}
