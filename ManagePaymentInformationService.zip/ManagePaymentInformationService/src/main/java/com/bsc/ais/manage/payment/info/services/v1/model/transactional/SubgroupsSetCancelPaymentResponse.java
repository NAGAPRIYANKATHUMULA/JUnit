package com.bsc.ais.manage.payment.info.services.v1.model.transactional;

import com.bsc.aip.core.model.common.composite.ResponseHeader;
import com.bsc.ais.manage.payment.info.services.v1.model.response.SubgroupsSetCancelPaymentResponseBody;

/**
 * This is the Patient Accumulator Service Response Pojo
 * @author Cognizant Technology Solutions
 *
 */
public class SubgroupsSetCancelPaymentResponse {

	protected ResponseHeader responseHeader;

	private SubgroupsSetCancelPaymentResponseBody responseBody = new SubgroupsSetCancelPaymentResponseBody();

	/**
	 * 
	 * @return responseHeader
	 */
	public ResponseHeader getResponseHeader() {
		return responseHeader;
	}

	/**
	 * responseHeader to set
	 * @param responseHeader
	 */
	public void setResponseHeader(ResponseHeader responseHeader) {
		this.responseHeader = responseHeader;
	}

	/**
	 * @return the responseBody
	 */
	public SubgroupsSetCancelPaymentResponseBody getResponseBody() {
		return responseBody;
	}

	/**
	 * @param responseBody the responseBody to set
	 */
	public void setResponseBody(SubgroupsSetCancelPaymentResponseBody responseBody) {
		this.responseBody = responseBody;
	}
	
}
