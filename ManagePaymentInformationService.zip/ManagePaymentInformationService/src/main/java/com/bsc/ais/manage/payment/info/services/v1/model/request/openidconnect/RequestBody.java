package com.bsc.ais.manage.payment.info.services.v1.model.request.openidconnect;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * RequestBody POJO for Employer OpenIdConnect API
 *
 * @author Vipul Gupta
 * @version 1.0
 * @since Mar 30, 2019
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestBody {

	private String access_token;
	private String refresh_token;
	private String id_token;
	private String userIdentifier;

	public String getAccess_token() {
		return access_token;
	}
	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}
	public String getRefresh_token() {
		return refresh_token;
	}
	public void setRefresh_token(String refresh_token) {
		this.refresh_token = refresh_token;
	}
	public String getId_token() {
		return id_token;
	}
	public void setId_token(String id_token) {
		this.id_token = id_token;
	}
	public String getUserIdentifier() {
		return userIdentifier;
	}
	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}
}
