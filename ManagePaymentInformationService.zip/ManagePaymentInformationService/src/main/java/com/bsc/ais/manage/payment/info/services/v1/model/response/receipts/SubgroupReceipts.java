package com.bsc.ais.manage.payment.info.services.v1.model.response.receipts;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class SubgroupReceipts {
	
	private SubgroupReceipt subgroupReceipt;

	/**
	 * @return the subgroupReceipt
	 */
	public SubgroupReceipt getSubgroupReceipt() {
		return subgroupReceipt;
	}

	/**
	 * @param subgroupReceipt the subgroupReceipt to set
	 */
	public void setSubgroupReceipt(SubgroupReceipt subgroupReceipt) {
		this.subgroupReceipt = subgroupReceipt;
	}
	
	
}
