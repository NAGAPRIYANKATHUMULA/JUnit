/*
 * GroupSubgroup.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */

package com.bsc.ais.manage.payment.info.services.v1.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * The Class GroupSubgroup.
 *
 * @author Cognizant Technology Solutions
 * @version 1.0
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GroupSubgroup {

	/** The group subgroup identifier. */
	private String groupSubgroupIdentifier;

	/**
	 * Gets the group subgroup identifier.
	 *
	 * @return the group subgroup identifier
	 */
	public String getGroupSubgroupIdentifier() {
		return groupSubgroupIdentifier;
	}

	/**
	 * Sets the group subgroup identifier.
	 *
	 * @param groupSubgroupIdentifier the new group subgroup identifier
	 */
	public void setGroupSubgroupIdentifier(String groupSubgroupIdentifier) {
		this.groupSubgroupIdentifier = groupSubgroupIdentifier;
	}


}
