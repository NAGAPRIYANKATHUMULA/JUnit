package com.bsc.ais.manage.payment.info.services.v1.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;



@Component("managePaymentInfoServiceWPRDbUtil")
@EnableAsync
public class ManagePaymentInfoServiceWPRDbUtil extends NamedParameterJdbcDaoSupport {
	
	private static final Logger LOGGER = LogManager.getLogger(ManagePaymentInfoServiceWPRDbUtil.class);
	
	private static String INSERT_PAYMENT_HISTORY_LOG = null;
	private static String OBTAIN_EMAIL_DETAILS = null;
	private static String FETCH_EMAIL_INFO =  null;
	private static String OBTAIN_SG_FEATURES = null;
	private static String OBTAIN_SUB_GRPS = null;
	private static String OBTAIN_USER_INFO = null;
	private static String RETRIEVE_SCHEDULE_NOTIFY_IND = null;
	private static String RETRIEVE_HISTORY_COUNT_BY_USERNAME_ACTION = null;
	private static String RETRIEVE_AUTO_PAYMENT_HISTORY_INFO = null;
	private static String RETRIEVE_HISTORY_COUNT_BY_GROUP_IDENTIFIER = null;
	private static String PYMT_NOTIFY_IND = null;
	
	static {
		try {
			INSERT_PAYMENT_HISTORY_LOG = ManagePaymentInfoServiceUtil.readResourceFile("sql/insertPaymentHistory.sql");
			OBTAIN_EMAIL_DETAILS = ManagePaymentInfoServiceUtil.readResourceFile("sql/obtainEmailDetails.sql");
			FETCH_EMAIL_INFO = ManagePaymentInfoServiceUtil.readResourceFile("sql/FetchEmailInfo.sql");
			OBTAIN_SG_FEATURES = ManagePaymentInfoServiceUtil.readResourceFile("sql/ObtainSubgrpsWithFeatures.sql");
			OBTAIN_SUB_GRPS = ManagePaymentInfoServiceUtil.readResourceFile("sql/ObtainAllSubGrps.sql");
			OBTAIN_USER_INFO = ManagePaymentInfoServiceUtil.readResourceFile("sql/ObtainUserInfoQuery.sql");
			RETRIEVE_SCHEDULE_NOTIFY_IND = ManagePaymentInfoServiceUtil.readResourceFile("sql/retrieveScheduleNotifyInd.sql");
			RETRIEVE_HISTORY_COUNT_BY_USERNAME_ACTION = ManagePaymentInfoServiceUtil.readResourceFile("sql/retrieveHistoryCountByUsernameAction.sql");
			RETRIEVE_AUTO_PAYMENT_HISTORY_INFO = ManagePaymentInfoServiceUtil.readResourceFile("sql/retrieveAutoPaymentsHistoryInfo.sql");
			RETRIEVE_HISTORY_COUNT_BY_GROUP_IDENTIFIER = ManagePaymentInfoServiceUtil.readResourceFile("sql/retrieveHistoryCountByGroupIdentifier.sql");
			PYMT_NOTIFY_IND = ManagePaymentInfoServiceUtil.readResourceFile("sql/PymtNotifyInfo.sql");
		} catch (IOException ex) {
			LOGGER.error("Exception occured while reading the SQL file.",ex);
		}
	}
	
	/**
	 * this method is used to insert data in PAYMENT_HISTORY_LOG table.
	 * @param userId
	 * @param accountName
	 * @param accountNumber
	 * @param subgroupId
	 * @param accountNickName
	 * @return
	 */
	public int insertIntoEmpGroupAdminUserHist(String userId, String accountName,
			String accountNumber, String subgroupId, String accountNickName){
		
		String query = INSERT_PAYMENT_HISTORY_LOG;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		paramMap.put("userId", userId);
		paramMap.put("accountName", accountName);
		paramMap.put("accountNumber", accountNumber);
		paramMap.put("subgroupId", subgroupId);
		paramMap.put("accountNickName", accountNickName);
		
		return getNamedParameterJdbcTemplate().update(query, paramMap);
	}
	/**
	 * this method is used to retrieve email details
	 * @param userId
	 * @return
	 */
	public List<Map<String, Object>> obtainEmailDetails(String userId) {
		String query = OBTAIN_EMAIL_DETAILS;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		paramMap.put("userId", userId);
		return getNamedParameterJdbcTemplate().queryForList(query, paramMap);
	}
	
	/**
	 * this method is used to retrieve email details
	 * @param userId
	 * @return
	 */
	public List<Map<String, Object>> fetchEmailInfo(String userId) {
		String query = FETCH_EMAIL_INFO;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		paramMap.put("userId", userId);
		return getNamedParameterJdbcTemplate().queryForList(query, paramMap);
	}
	
	
	/**
	 * this method is used to retrieve email details
	 * @param userId
	 * @return
	 */
	public List<Map<String, Object>> obtainSubgrpsFeatures(String userId , String groupId) {
		String query = OBTAIN_SG_FEATURES;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		paramMap.put("userId", userId);
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_GROUP_IDENTIIFER, groupId);
		return getNamedParameterJdbcTemplate().queryForList(query, paramMap);
	}
	
	/**
	 * this method is used to retrieve email details
	 * @param userId
	 * @return
	 */
	public List<Map<String, Object>> obtainAllSubgrps(String groupId) {
		String query = OBTAIN_SUB_GRPS;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_GROUP_IDENTIIFER, groupId);
		return getNamedParameterJdbcTemplate().queryForList(query, paramMap);
	}
	
	
	
	/**
	 * this method is used to insert new user details into into employer_group_admin_user_hist and employer_group_admin_user table for PRI_CONTC flow
	 * 
	 *
	 */
	public int insertPaymentHistoryLog( List<String> subGrpIdentifiers ,String userId , String accountNickName) throws Exception {
		List<String> insertStatements = new ArrayList<String>();
		int insertCount = 0;
		try {
				
				for(String subgrp : subGrpIdentifiers){
				StringBuilder sql = new StringBuilder(ManagePaymentInfoServiceConstants.EMPTY_STR);
				sql.append(ManagePaymentInfoServiceConstants.INSERT).append(ManagePaymentInfoServiceConstants.INTO)
						.append(ManagePaymentInfoServiceConstants.PAYMENT_HISTORY_LOG)
						.append(ManagePaymentInfoServiceConstants.VALUES)
						.append(ManagePaymentInfoServiceConstants.OPEN_PARENTHESIS)
						.append(ManagePaymentInfoServiceConstants.PAYMENT_ID) // acss_eff_dt
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString(userId)) //USER ID 
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString(ManagePaymentInfoServiceConstants.STRING_CANCEL)) //grp_nbr
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceConstants.SYSDATE) //delgt_usr_id
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString(null)) // delgtr_usr_id
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString(null)) // updt_dt
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString(subgrp)) // insrt_usr_id
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString(accountNickName)) // delgtr_admin_usr_typ_cd
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString(userId)) // usrid
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceConstants.SYSDATE) // actv_btch_log_id
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString(userId)) // user id
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceConstants.SYSDATE) 
						.append(ManagePaymentInfoServiceConstants.CLOSE_PARENTHESIS);
				insertStatements.add(sql.toString());
			}
				String[] sqlArray = insertStatements.toArray(new String[0]);
				int count[] = getJdbcTemplate().batchUpdate(sqlArray);
				insertCount = count.length;	
			
		}catch (Exception ex) {
			LOGGER.error("Exception occured while executing batch update in payment history log table "+ ex);
			throw new Exception(ex);
		}
		return insertCount;
	}
	
	/**
	 * this method is used to get total report count
	 * @param userIdentifier
	 * @param groupIdentifier
	 *
	 */
	public List<Map<String, Object>> retrieveUserInformation(String userIdentifier, String groupIdentifier){
		
		String query = OBTAIN_USER_INFO;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER, userIdentifier);
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER, groupIdentifier);
		
		return getNamedParameterJdbcTemplate().queryForList(query, paramMap);
	}
	
	/**
	 * this method is used to get total report count
	 * @param userIdentifier
	 * @param groupIdentifier
	 *
	 */
	public String retrieveScheduleNotifyIndInformation(String userIdentifier){
		
		String query = RETRIEVE_SCHEDULE_NOTIFY_IND;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER, userIdentifier);
		
		return getNamedParameterJdbcTemplate().queryForObject(query, paramMap, String.class);
	}
	
	/**
	 * this method is used to get auto payments history count
	 * @param groupIdentifier
	 * @param userName
	 * @param fromDate
	 * @param toDate
	 * @param action
	 *
	 */
	public Integer retrieveTotalHistoryCountByUserNameAndAction(String groupIdentifier,String userName,String fromDate,String toDate,String action){
		
		String query = RETRIEVE_HISTORY_COUNT_BY_USERNAME_ACTION;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER, groupIdentifier);
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_PROP_USER_NAME, userName);
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_PROP_FROM_DATE, fromDate);
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_PROP_TO_DATE, toDate);
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_PROP_ACTION, action);
		
		return getNamedParameterJdbcTemplate().queryForObject(query, paramMap, Integer.class);
	}
	
	/**
	 * this method is used to get auto payments history informations
	 * @param groupIdentifier
	 * @param userName
	 * @param fromDate
	 * @param toDate
	 * @param action
	 * @param startIndex
	 * @param endIndex
	 *
	 */
	public List<Map<String, Object>> retrieveAutoPaymentHistoryInfo(String groupIdentifier,String userName,String fromDate,String toDate,String action,String startIndex,String endIndex){
		
		String query = RETRIEVE_AUTO_PAYMENT_HISTORY_INFO;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER, groupIdentifier);
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_PROP_USER_NAME, userName);
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_PROP_FROM_DATE, fromDate);
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_PROP_TO_DATE, toDate);
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_PROP_ACTION, action);
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_PROP_START_INDEX, startIndex);
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_PROP_END_INDEX, endIndex);
		
		return getNamedParameterJdbcTemplate().queryForList(query, paramMap);
	}
	
	/**
	 * this method is used to get auto payments history count
	 * @param groupIdentifier
	 * @param userName
	 * @param fromDate
	 * @param toDate
	 * @param action
	 *
	 */
	public Integer retrieveTotalHistoryCountByGroupIdentifier(String groupIdentifier){
		
		String query = RETRIEVE_HISTORY_COUNT_BY_GROUP_IDENTIFIER;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER, groupIdentifier);
		
		return getNamedParameterJdbcTemplate().queryForObject(query, paramMap, Integer.class);
	}
	
	/**
	 * this method is used to retrieve email details
	 * @param userId
	 * @return
	 */
	public String obtainPymtNotify(String userId) {
		String query = PYMT_NOTIFY_IND;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		paramMap.put("userId", userId);
		return getNamedParameterJdbcTemplate().queryForObject(query, paramMap , String.class);
	}
	
}
