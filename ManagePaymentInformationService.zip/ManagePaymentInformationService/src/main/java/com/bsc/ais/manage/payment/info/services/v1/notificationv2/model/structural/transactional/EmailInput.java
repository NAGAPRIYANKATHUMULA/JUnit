/*
 * EmailInput.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */

package com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;



/**
 * EmailInput
 * @author Cognizant Technology Solutions
 *
 */
@JsonInclude(Include.NON_NULL)
public class EmailInput {
	
	private List<String> toAddress = new ArrayList<String>();
	
	private String fromAddress;
	
	private String fromAddressIndicator;
	
	private String subject;
	
	private String templateIndicator;
	
	private String attachmentNeeded;
	
	private EmailBody emailBody = new EmailBody();
	
	private String templateType ;
	
	private String processId ;

	/**
	 * @return the toAddress
	 */
	public List<String> getToAddress() {
		return toAddress;
	}

	/**
	 * @param toAddress the toAddress to set
	 */
	public void setToAddress(List<String> toAddress) {
		this.toAddress = toAddress;
	}


	/**
	 * @return the fromAddress
	 */
	public String getFromAddress() {
		return fromAddress;
	}

	/**
	 * @param fromAddress the fromAddress to set
	 */
	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}

	/**
	 * @return the fromAddressIndicator
	 */
	public String getFromAddressIndicator() {
		return fromAddressIndicator;
	}

	/**
	 * @param fromAddressIndicator the fromAddressIndicator to set
	 */
	public void setFromAddressIndicator(String fromAddressIndicator) {
		this.fromAddressIndicator = fromAddressIndicator;
	}

	/**
	 * @return the subject
	 */
	public String getSubject() {
		return subject;
	}

	/**
	 * @param subject the subject to set
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * @return the templateIndicator
	 */
	public String getTemplateIndicator() {
		return templateIndicator;
	}

	/**
	 * @param templateIndicator the templateIndicator to set
	 */
	public void setTemplateIndicator(String templateIndicator) {
		this.templateIndicator = templateIndicator;
	}

	/**
	 * @return the attachmentNeeded
	 */
	public String getAttachmentNeeded() {
		return attachmentNeeded;
	}

	/**
	 * @param attachmentNeeded the attachmentNeeded to set
	 */
	public void setAttachmentNeeded(String attachmentNeeded) {
		this.attachmentNeeded = attachmentNeeded;
	}

	/**
	 * @return the emailBody
	 */
	public EmailBody getEmailBody() {
		return emailBody;
	}

	/**
	 * @param emailBody the emailBody to set
	 */
	public void setEmailBody(EmailBody emailBody) {
		this.emailBody = emailBody;
	}

	/**
	 * @return the templateType
	 */
	public String getTemplateType() {
		return templateType;
	}

	/**
	 * @param templateType the templateType to set
	 */
	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	/**
	 * @return the processId
	 */
	public String getProcessId() {
		return processId;
	}

	/**
	 * @param processId the processId to set
	 */
	public void setProcessId(String processId) {
		this.processId = processId;
	}
	
}
