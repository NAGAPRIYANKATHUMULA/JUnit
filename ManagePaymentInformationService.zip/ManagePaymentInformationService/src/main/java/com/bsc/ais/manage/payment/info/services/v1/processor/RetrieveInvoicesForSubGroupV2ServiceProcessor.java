/*
 * RetrieveInvoicesForSubGroupV2ServiceProcessor.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.invoices.RetrieveInvoiceInformationRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.request.invoices.RetrieveInvoiceInformationRequestBody;
import com.bsc.ais.manage.payment.info.services.v1.model.request.invoices.SubgroupIdentifier;
import com.bsc.ais.manage.payment.info.services.v1.model.request.invoices.SubgroupIdentifiers;
import com.bsc.ais.manage.payment.info.services.v1.model.response.AutoPaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.response.invoices.InvoiceInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.response.invoices.RetrieveInvoiceInformationResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * <HTML> This class contains the process method for the retrieving invoices info
 * using RetrieveInvoicesForSubGroupV2 service </HTML>
 *
 * @author Cognizant Technology Solutions.
 * @version 1.0
 * 
 */
@Component
public class RetrieveInvoicesForSubGroupV2ServiceProcessor implements Processor {

	private static final Logger LOGGER = LogManager.getLogger(RetrieveInvoicesForSubGroupV2ServiceProcessor.class);

	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";

	private RestTemplate restTemplate = new RestTemplate();

	@Value("${retrieve.autopayments.invoices.subgroups.service.url}")
	private String retrieveInvoicesforSubgroupV2ServiceUrl;
	
	@Value("${manage.payment.info.composite.custom.header.x-ibm-client-id}")
	private String xClientId;
	
	@Value("${manage.payment.info.composite.custom.header.x-ibm-client-secret}")
	private String xClientSecret;
	
	@Value("${api.services.security.passthrough}")
	private String idToken;
	
	@Resource
	private EventLogging eventLogging;

	/*
	 * (non-Javadoc)
	 * 
	 * This class is used for retrieving invoices info using RetrieveInvoicesforSubGroupV2 Service
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	@SuppressWarnings({ "unchecked" })
	public void process(Exchange exchange) throws Exception {
		
		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_ENTERING, METHOD_PROCESS);
		
			exchange.setProperty(ManagePaymentInfoServiceConstants.IS_RETRIEVE_INVOICES_SUCCESS, ManagePaymentInfoServiceConstants.STRING_FALSE);
		
			// Obtain an instance of service request from exchange object.
			RetrieveAutoPaymentsRequest request = (RetrieveAutoPaymentsRequest) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST);
			// Obtain an instance of service response from exchange object.
			RetrieveAutoPaymentsResponse response = (RetrieveAutoPaymentsResponse) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
			// Obtain the list of subGroupIdentifier from exchange object.
			List<String> subGroupIdentifierList =(List<String>) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUBGROUP_IDENTIFIER_LIST);
			// Obtain the userIdentifier value from exchange object.
			String userIdentifier = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER);
			// Obtain the instance of paymentResponse Map from exchange object.
			Map<String,AutoPaymentInformation> paymentResponseMap = (Map<String, AutoPaymentInformation>) exchange.getProperty(ManagePaymentInfoServiceConstants.PAYMENT_RESPONSE_MAP);
			List<Message> messages = new ArrayList<Message>();
			
			try {
				//obtain HttpHeaders info
				HttpHeaders httpHeaders = ManagePaymentInfoServiceUtil.obtainHttpHeadersInfo(exchange,xClientId,xClientSecret);
				
				ObjectMapper requestMapper = new ObjectMapper();
				RequestHeader requestHeader = new RequestHeader();
				HttpEntity<String> requestEntity;
				ResponseEntity<String> invoicesServiceResponse = null;
				
				//Build Retrieve Invoice for SubGroup Service Request
				RetrieveInvoiceInformationRequest retrieveInvoiceInformationRequest = new RetrieveInvoiceInformationRequest();
				requestHeader = request.getRequestHeader();
				if(null != requestHeader.getCredentials()){
					requestHeader.getCredentials().setToken(idToken);
					requestHeader.getCredentials().setType(ManagePaymentInfoServiceConstants.ID_TOKEN);
				}
		
				retrieveInvoiceInformationRequest.setRequestHeader(requestHeader);
				retrieveInvoiceInformationRequest.setRequestBody(new RetrieveInvoiceInformationRequestBody());
				
				SubgroupIdentifiers subgroupIdentifiers = new SubgroupIdentifiers();
				List<SubgroupIdentifier> subGroupIdList = new ArrayList<SubgroupIdentifier>();
				for(String subGroupId: subGroupIdentifierList){
					SubgroupIdentifier subgroupIdentifier = new SubgroupIdentifier();
					subgroupIdentifier.setSubgroupIdentifier(subGroupId);
					subGroupIdList.add(subgroupIdentifier);
				}
				subgroupIdentifiers.setSubgroupIdentifier(subGroupIdList);
				
				retrieveInvoiceInformationRequest.getRequestBody().setUserIdentifier(userIdentifier);
				retrieveInvoiceInformationRequest.getRequestBody().setRequestType(ManagePaymentInfoServiceConstants.REQUEST_TYPE_SG);
				retrieveInvoiceInformationRequest.getRequestBody().setIsInvoiceFilterRequired(ManagePaymentInfoServiceConstants.STRING_NO);
				retrieveInvoiceInformationRequest.getRequestBody().setSubgroupIdentifiers(subgroupIdentifiers);
				
				requestEntity = new HttpEntity<String>(requestMapper.writeValueAsString(retrieveInvoiceInformationRequest), httpHeaders);
				LOGGER.debug(transactionId + " - "+ "Retrieve invoices for Subgroup Service Request: "+requestEntity);
				//call the RetrieveInvoicesforSubGroup Service and get the response
				invoicesServiceResponse = restTemplate.exchange(retrieveInvoicesforSubgroupV2ServiceUrl, HttpMethod.POST, requestEntity, String.class);
		
				if (invoicesServiceResponse != null) {
					ObjectMapper responseMapper = new ObjectMapper();
					String invoicesServiceResponseString = ManagePaymentInfoServiceUtil.processSyncResponse(invoicesServiceResponse, ManagePaymentInfoServiceConstants.RETRIEVE_INVOICES_FOR_SUBGROUP_SERVICE);
					if (!StringUtils.isBlank(invoicesServiceResponseString)) {
						RetrieveInvoiceInformationResponse subgroupInvoicesResponse = responseMapper.readValue(invoicesServiceResponseString, RetrieveInvoiceInformationResponse.class);
						//validate if service returns SUCCESS or not
						if (StringUtils.equalsIgnoreCase(
								subgroupInvoicesResponse.getResponseHeader().getTransactionNotification().getStatusCode(), ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE)) {
							exchange.setProperty(ManagePaymentInfoServiceConstants.IS_RETRIEVE_INVOICES_SUCCESS,
									ManagePaymentInfoServiceConstants.STRING_TRUE);
							//iterate and get the list of subgroupInvoices
							if(null != subgroupInvoicesResponse.getResponseBody() && null != subgroupInvoicesResponse.getResponseBody().getInvoiceInformations() 
									&& null != subgroupInvoicesResponse.getResponseBody().getInvoiceInformations().getInvoiceInformation() 
									&& !subgroupInvoicesResponse.getResponseBody().getInvoiceInformations().getInvoiceInformation().isEmpty()){
								List<InvoiceInformation> invoiceInformationList = subgroupInvoicesResponse.getResponseBody().getInvoiceInformations().getInvoiceInformation();
								
								for(InvoiceInformation invoiceInformation: invoiceInformationList){
									AutoPaymentInformation paymentInformation = paymentResponseMap.get(invoiceInformation.getSubgroupIdentifier());
									if(null != paymentInformation){
									if(invoiceInformation.getSubgroupIdentifier().equalsIgnoreCase(paymentInformation.getSubgroupIdentifier())){
										String billedAmount = invoiceInformation.getInvoiceBilledAmount();
										String paidAmount = invoiceInformation.getInvoicePaidAmount();
										String invoiceAmount = paymentInformation.getInvoiceDue();
										Double invoiceDueAmount = 0.0;
										if(null != invoiceAmount){
											invoiceDueAmount = Double.valueOf(invoiceAmount);
										}
										
										Double invoiceBilledAmount = Double.valueOf(billedAmount);
										Double invoicePaidAmount = Double.valueOf(paidAmount);
										
										if(null != invoiceBilledAmount && null != invoicePaidAmount){
											Double invoiceDue = invoiceBilledAmount-invoicePaidAmount;
											invoiceDue = invoiceDue + invoiceDueAmount;
											paymentInformation.setInvoiceDue(String.valueOf(invoiceDue));
											paymentResponseMap.put(paymentInformation.getSubgroupIdentifier(), paymentInformation);
										}	
								   }
									
								}
								}
						  }
						} else  {
							
							ManagePaymentInfoServiceUtil.addMessage(messages, subgroupInvoicesResponse.getResponseHeader().getTransactionNotification().getRemarks().getMessages().get(0).getCode(),
									ManagePaymentInfoServiceConstants.RETRIEVE_INVOICES_SERVICE_FAILED,
									subgroupInvoicesResponse.getResponseHeader().getTransactionNotification().getRemarks().getMessages().get(0).getDescription());	
							LOGGER.error(transactionId + " - "+ METHOD_PROCESS + ManagePaymentInfoServiceConstants.FAILURE );
							
							if (!messages.isEmpty()) {
								response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.WARNING,
										ManagePaymentInfoServiceConstants.WARNING_STATUS_CODE, response.getResponseHeader(), messages));
								messages.clear();
							}
						}
					}
				} else {
					messages.clear();
					ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
							ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
							ManagePaymentInfoServiceConstants.RETRIEVE_INVOICES_SERVICE_ERROR);
					LOGGER.error(transactionId + " - "+ METHOD_PROCESS + ManagePaymentInfoServiceConstants.FAILURE );
				}
			} catch (Exception ex) {
				
				messages.clear();
				ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
						ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
						ManagePaymentInfoServiceConstants.RETRIEVE_INVOICES_SERVICE_ERROR);
				LOGGER.error(transactionId + " - "+ METHOD_PROCESS + ManagePaymentInfoServiceConstants.RETRIEVE_INVOICES_SERVICE_ERROR, ex);
			}
			
			if (!messages.isEmpty()) {
				response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE,
						ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, response.getResponseHeader(), messages));
			}
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			response.setResponseBody(null);
			exchange.getIn().setBody(response);
		
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_EXITING, METHOD_PROCESS);
	}

}