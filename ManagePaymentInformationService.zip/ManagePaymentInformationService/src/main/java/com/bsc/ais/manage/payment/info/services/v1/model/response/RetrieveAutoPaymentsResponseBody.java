package com.bsc.ais.manage.payment.info.services.v1.model.response;

public class RetrieveAutoPaymentsResponseBody {

	/** The isScheduledNotification. */
	private String isScheduledNotification;

	/** The PaymentInformations object . */
	private AutoPaymentInformations autoPaymentInformations;

	/**
	 * @return the isScheduledNotification
	 */
	public String getIsScheduledNotification() {
		return isScheduledNotification;
	}

	/**
	 * @param isScheduledNotification the isScheduledNotification to set
	 */
	public void setIsScheduledNotification(String isScheduledNotification) {
		this.isScheduledNotification = isScheduledNotification;
	}

	/**
	 * @return the autoPaymentInformations
	 */
	public AutoPaymentInformations getAutoPaymentInformations() {
		return autoPaymentInformations;
	}

	/**
	 * @param autoPaymentInformations the autoPaymentInformations to set
	 */
	public void setAutoPaymentInformations(AutoPaymentInformations autoPaymentInformations) {
		this.autoPaymentInformations = autoPaymentInformations;
	}

	
	
}
