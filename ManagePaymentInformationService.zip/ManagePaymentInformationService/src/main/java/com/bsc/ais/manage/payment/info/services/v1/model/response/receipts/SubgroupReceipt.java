package com.bsc.ais.manage.payment.info.services.v1.model.response.receipts;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class SubgroupReceipt {
	
	private String subgroupIdentifier;
	private String subgroupName;
	private String status;
	private String paymentType;
	private String checkNumber;
	private String receiptID;
	private String paymentAmount;
	private String paymentDate;
	private String bankAccount;
	private String netCreditsDebits;
	private String retroactiveAdjustments;
	private String suspenseAmount;
	private String currentCharge;
	private String invoiceID;
	private String invoiceDuedate;
	private String receiptGenerationDate;
	private String totalDueAmount;
	private String balance;
	private String previousAmountDue;
	/**
	 * @return the subgroupIdentifier
	 */
	public String getSubgroupIdentifier() {
		return subgroupIdentifier;
	}
	/**
	 * @param subgroupIdentifier the subgroupIdentifier to set
	 */
	public void setSubgroupIdentifier(String subgroupIdentifier) {
		this.subgroupIdentifier = subgroupIdentifier;
	}
	/**
	 * @return the subgroupName
	 */
	public String getSubgroupName() {
		return subgroupName;
	}
	/**
	 * @param subgroupName the subgroupName to set
	 */
	public void setSubgroupName(String subgroupName) {
		this.subgroupName = subgroupName;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the paymentType
	 */
	public String getPaymentType() {
		return paymentType;
	}
	/**
	 * @param paymentType the paymentType to set
	 */
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	/**
	 * @return the checkNumber
	 */
	public String getCheckNumber() {
		return checkNumber;
	}
	/**
	 * @param checkNumber the checkNumber to set
	 */
	public void setCheckNumber(String checkNumber) {
		this.checkNumber = checkNumber;
	}
	/**
	 * @return the receiptID
	 */
	public String getReceiptID() {
		return receiptID;
	}
	/**
	 * @param receiptID the receiptID to set
	 */
	public void setReceiptID(String receiptID) {
		this.receiptID = receiptID;
	}
	/**
	 * @return the paymentAmount
	 */
	public String getPaymentAmount() {
		return paymentAmount;
	}
	/**
	 * @param paymentAmount the paymentAmount to set
	 */
	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	/**
	 * @return the paymentDate
	 */
	public String getPaymentDate() {
		return paymentDate;
	}
	/**
	 * @param paymentDate the paymentDate to set
	 */
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}
	/**
	 * @return the bankAccount
	 */
	public String getBankAccount() {
		return bankAccount;
	}
	/**
	 * @param bankAccount the bankAccount to set
	 */
	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}
	/**
	 * @return the netCreditsDebits
	 */
	public String getNetCreditsDebits() {
		return netCreditsDebits;
	}
	/**
	 * @param netCreditsDebits the netCreditsDebits to set
	 */
	public void setNetCreditsDebits(String netCreditsDebits) {
		this.netCreditsDebits = netCreditsDebits;
	}
	/**
	 * @return the retroactiveAdjustments
	 */
	public String getRetroactiveAdjustments() {
		return retroactiveAdjustments;
	}
	/**
	 * @param retroactiveAdjustments the retroactiveAdjustments to set
	 */
	public void setRetroactiveAdjustments(String retroactiveAdjustments) {
		this.retroactiveAdjustments = retroactiveAdjustments;
	}
	/**
	 * @return the suspenseAmount
	 */
	public String getSuspenseAmount() {
		return suspenseAmount;
	}
	/**
	 * @param suspenseAmount the suspenseAmount to set
	 */
	public void setSuspenseAmount(String suspenseAmount) {
		this.suspenseAmount = suspenseAmount;
	}
	/**
	 * @return the currentCharge
	 */
	public String getCurrentCharge() {
		return currentCharge;
	}
	/**
	 * @param currentCharge the currentCharge to set
	 */
	public void setCurrentCharge(String currentCharge) {
		this.currentCharge = currentCharge;
	}
	/**
	 * @return the invoiceID
	 */
	public String getInvoiceID() {
		return invoiceID;
	}
	/**
	 * @param invoiceID the invoiceID to set
	 */
	public void setInvoiceID(String invoiceID) {
		this.invoiceID = invoiceID;
	}
	/**
	 * @return the invoiceDuedate
	 */
	public String getInvoiceDuedate() {
		return invoiceDuedate;
	}
	/**
	 * @param invoiceDuedate the invoiceDuedate to set
	 */
	public void setInvoiceDuedate(String invoiceDuedate) {
		this.invoiceDuedate = invoiceDuedate;
	}	
	/**
	 * @return the receiptGenerationDate
	 */
	public String getReceiptGenerationDate() {
		return receiptGenerationDate;
	}
	/**
	 * @param receiptGenerationDate the receiptGenerationDate to set
	 */
	public void setReceiptGenerationDate(String receiptGenerationDate) {
		this.receiptGenerationDate = receiptGenerationDate;
	}
	/**
	 * @return the totalDueAmount
	 */
	public String getTotalDueAmount() {
		return totalDueAmount;
	}
	/**
	 * @param totalDueAmount the totalDueAmount to set
	 */
	public void setTotalDueAmount(String totalDueAmount) {
		this.totalDueAmount = totalDueAmount;
	}
	/**
	 * @return the balance
	 */
	public String getBalance() {
		return balance;
	}
	/**
	 * @param balance the balance to set
	 */
	public void setBalance(String balance) {
		this.balance = balance;
	}
	/**
	 * @return the previousAmountDue
	 */
	public String getPreviousAmountDue() {
		return previousAmountDue;
	}
	/**
	 * @param previousAmountDue the previousAmountDue to set
	 */
	public void setPreviousAmountDue(String previousAmountDue) {
		this.previousAmountDue = previousAmountDue;
	}
	
	
	
}
