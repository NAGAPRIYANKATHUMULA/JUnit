/*
 * RetrieveReceiptsForSubGroupServiceProcessor.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupIdentifier;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupIdentifiers;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupSubgroup;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupSubgroups;
import com.bsc.ais.manage.payment.info.services.v1.model.request.receipts.RetrieveReceiptsForSubGroupRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.request.receipts.RetrieveReceiptsForSubGroupRequestBody;
import com.bsc.ais.manage.payment.info.services.v1.model.response.AutoPaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.response.receipts.SubgroupReceipt;
import com.bsc.ais.manage.payment.info.services.v1.model.response.receipts.SubgroupReceiptsResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * <HTML> This class contains the process method for the retrieving receipts info
 * using RetrieveReceiptsforSubGroup service </HTML>
 *
 * @author Cognizant Technology Solutions.
 * @version 1.0
 * 
 */
@Component
public class RetrieveReceiptsForSubGroupServiceProcessor implements Processor {

	private static final Logger LOGGER = LogManager.getLogger(RetrieveReceiptsForSubGroupServiceProcessor.class);

	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";

	private RestTemplate restTemplate = new RestTemplate();

	@Value("${retrieve.autopayments.receipts.subgroups.service.url}")
	private String retrieveReceiptsforSubgroupServiceUrl;
	
	@Value("${manage.payment.info.composite.custom.header.x-ibm-client-id}")
	private String xClientId;
	
	@Value("${manage.payment.info.composite.custom.header.x-ibm-client-secret}")
	private String xClientSecret;
	
	@Value("${api.services.security.passthrough}")
	private String idToken;
	
	@Resource
	private EventLogging eventLogging;

	/*
	 * (non-Javadoc)
	 * 
	 * This class is used for retrieving receipts info using RetrieveReceiptsforSubGroup Service
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	@SuppressWarnings({ "unchecked" })
	public void process(Exchange exchange) throws Exception {
		
		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_ENTERING, METHOD_PROCESS);
		
			exchange.setProperty(ManagePaymentInfoServiceConstants.IS_RETRIEVE_RECEIPTS_SUCCESS, ManagePaymentInfoServiceConstants.STRING_FALSE);
		
			// Obtain an instance of service request from exchange object.
			RetrieveAutoPaymentsRequest request = (RetrieveAutoPaymentsRequest) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST);
			// Obtain an instance of service response from exchange object.
			RetrieveAutoPaymentsResponse response = (RetrieveAutoPaymentsResponse) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
			// Obtain the list of subGroupIdentifier from exchange object.
			List<String> subGroupIdentifierList =(List<String>) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUBGROUP_IDENTIFIER_LIST);
			// Obtain the userIdentifier value from exchange object.
			String userIdentifier = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER);
			// Obtain the instance of paymentResponse Map from exchange object.
			Map<String,AutoPaymentInformation> paymentResponseMap = (Map<String, AutoPaymentInformation>) exchange.getProperty(ManagePaymentInfoServiceConstants.PAYMENT_RESPONSE_MAP);
			// Obtain the instance of userInfo Map from exchange object.
			Map<String,String> userInfoMap = (Map<String, String>) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USERINFO_MAP);
			List<Message> messages = new ArrayList<Message>();
			
			try {
				//obtain HttpHeaders info
				HttpHeaders httpHeaders = ManagePaymentInfoServiceUtil.obtainHttpHeadersInfo(exchange,xClientId,xClientSecret);
				
				ObjectMapper requestMapper = new ObjectMapper();
				RequestHeader requestHeader = new RequestHeader();
				HttpEntity<String> requestEntity;
				ResponseEntity<String> receiptsServiceResponse = null;
				
				//Build Retrieve Receipts For SubGroup Service Request
				RetrieveReceiptsForSubGroupRequest retrieveReceiptsForSubGroupRequest = new RetrieveReceiptsForSubGroupRequest();
				requestHeader = request.getRequestHeader();
				if(null != requestHeader.getCredentials()){
					requestHeader.getCredentials().setToken(idToken);
					requestHeader.getCredentials().setType(ManagePaymentInfoServiceConstants.ID_TOKEN);
				}
		
				request.getRequestHeader().getConsumer().setName(ManagePaymentInfoServiceConstants.CONSUMER_IVR);
				retrieveReceiptsForSubGroupRequest.setRequestHeader(requestHeader);
				retrieveReceiptsForSubGroupRequest.setRequestBody(new RetrieveReceiptsForSubGroupRequestBody());
				
				GroupIdentifiers groupIdentifiers = new GroupIdentifiers();
				List<GroupIdentifier> groupIdentifierList = new ArrayList<GroupIdentifier>();
				GroupIdentifier groupIdentifier = new GroupIdentifier();
				GroupSubgroups groupSubgroups = new GroupSubgroups();
				List<GroupSubgroup> groupSubgroupList = new ArrayList<GroupSubgroup>();
				for(String subGroupId: subGroupIdentifierList){
					GroupSubgroup groupSubgroup = new GroupSubgroup();
					groupSubgroup.setGroupSubgroupIdentifier(subGroupId);
					groupSubgroupList.add(groupSubgroup);
				}
				groupSubgroups.setGroupSubgroup(groupSubgroupList);
				groupIdentifier.setGroupSubgroups(groupSubgroups);
				groupIdentifierList.add(groupIdentifier);
				groupIdentifiers.setGroupIdentifier(groupIdentifierList);
				retrieveReceiptsForSubGroupRequest.getRequestBody().setGroupIdentifiers(groupIdentifiers);
				retrieveReceiptsForSubGroupRequest.getRequestBody().setUserIdentifier(userIdentifier);
				retrieveReceiptsForSubGroupRequest.getRequestBody().setRequestType(ManagePaymentInfoServiceConstants.REQUEST_TYPE_SG);
				retrieveReceiptsForSubGroupRequest.getRequestBody().setReceiptPeriod("");
				String[] requestStatus = new String[]{""};
				retrieveReceiptsForSubGroupRequest.getRequestBody().setRequestStatus(requestStatus);
				
				
				requestEntity = new HttpEntity<String>(requestMapper.writeValueAsString(retrieveReceiptsForSubGroupRequest), httpHeaders);
				LOGGER.debug(transactionId + " - "+ "Retrieve receipts for Subgroup Service Request: "+requestEntity);
				//call the RetrieveReceiptsforSubGroup Service and get the response
				receiptsServiceResponse = restTemplate.exchange(retrieveReceiptsforSubgroupServiceUrl, HttpMethod.POST, requestEntity, String.class);
		
				if (receiptsServiceResponse != null) {
					ObjectMapper responseMapper = new ObjectMapper();
					String receiptsServiceResponseString = ManagePaymentInfoServiceUtil.processSyncResponse(receiptsServiceResponse, ManagePaymentInfoServiceConstants.RETRIEVE_RECEIPTS_FOR_SUBGROUP_SERVICE);
					if (!StringUtils.isBlank(receiptsServiceResponseString)) {
						SubgroupReceiptsResponse subgroupReceiptsResponse = responseMapper.readValue(receiptsServiceResponseString, SubgroupReceiptsResponse.class);
						//validate if service returns SUCCESS or not
						if (StringUtils.equalsIgnoreCase(
								subgroupReceiptsResponse.getResponseHeader().getTransactionNotification().getStatusCode(), ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE) ||
								StringUtils.equalsIgnoreCase(
										subgroupReceiptsResponse.getResponseHeader().getTransactionNotification().getRemarks().getMessages().get(0).getCode(), ManagePaymentInfoServiceConstants.MSG_CODE_NO_DATA_FOUND)) {
							exchange.setProperty(ManagePaymentInfoServiceConstants.IS_RETRIEVE_RECEIPTS_SUCCESS,
									ManagePaymentInfoServiceConstants.STRING_TRUE);
							//iterate and get the list of subgroupReceipts
							if(null != subgroupReceiptsResponse.getResponseBody() && null != subgroupReceiptsResponse.getResponseBody().getSubgroupReceipts() 
									&& !subgroupReceiptsResponse.getResponseBody().getSubgroupReceipts().isEmpty()){
								List<SubgroupReceipt> subgroupReceiptsList = subgroupReceiptsResponse.getResponseBody().getSubgroupReceipts();
								List<SubgroupReceipt> subgroupReceiptsCompletedList = new ArrayList<SubgroupReceipt>();
								Map<String,List<SubgroupReceipt>> subgroupReceiptsMap = new HashMap<String,List<SubgroupReceipt>>();
								for(SubgroupReceipt subgroupReceipt: subgroupReceiptsList){
									if(subgroupReceipt.getStatus().equalsIgnoreCase(ManagePaymentInfoServiceConstants.COMPLETED)){
										if(subgroupReceiptsMap.containsKey(subgroupReceipt.getSubgroupIdentifier())){
											subgroupReceiptsCompletedList = subgroupReceiptsMap.get(subgroupReceipt.getSubgroupIdentifier());
											subgroupReceiptsCompletedList.add(subgroupReceipt);
											subgroupReceiptsMap.put(subgroupReceipt.getSubgroupIdentifier(), subgroupReceiptsCompletedList);
										}else{
											subgroupReceiptsCompletedList = new ArrayList<SubgroupReceipt>(); 
											subgroupReceiptsCompletedList.add(subgroupReceipt);
											subgroupReceiptsMap.put(subgroupReceipt.getSubgroupIdentifier(), subgroupReceiptsCompletedList);
										}
								   }
								}
								
						for(String subgroupId:userInfoMap.keySet()){
							if(null != subgroupId && null != subgroupReceiptsMap.get(subgroupId)){
								Collections.sort(subgroupReceiptsMap.get(subgroupId), new Comparator<SubgroupReceipt>() {
							        DateFormat f = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS"); 
							        @Override
							        public int compare(SubgroupReceipt o1, SubgroupReceipt o2) {
							            try {
							                return f.parse(o2.getPaymentDate()).compareTo(f.parse(o1.getPaymentDate()));
							            } catch (ParseException e) {
							                throw new IllegalArgumentException(e);
							            }
							        }
									
							    });
								
								SubgroupReceipt sortedSubgroupReceipt = subgroupReceiptsMap.get(subgroupId).get(0);
								String lastPaidDate = sortedSubgroupReceipt.getPaymentDate();
								String receiptId = sortedSubgroupReceipt.getReceiptID();
								Double amount = 0.0;
								for(SubgroupReceipt subgroupReceipt :subgroupReceiptsMap.get(subgroupId)){
									if(subgroupReceipt.getReceiptID().equalsIgnoreCase(receiptId)){
										amount = amount + Double.valueOf(subgroupReceipt.getPaymentAmount());
									}
								}
								AutoPaymentInformation paymentInformation = paymentResponseMap.get(subgroupId);
								if(null != paymentInformation){
									paymentInformation.setLastPaidDate(lastPaidDate);
									paymentInformation.setLastPaidAmount(String.valueOf(amount));
								}
							}
							}
						  }
						} else  {
							
							exchange.setProperty(ManagePaymentInfoServiceConstants.IS_RETRIEVE_RECEIPTS_SUCCESS,
									ManagePaymentInfoServiceConstants.STRING_FALSE);
							
							ManagePaymentInfoServiceUtil.addMessage(messages, subgroupReceiptsResponse.getResponseHeader().getTransactionNotification().getRemarks().getMessages().get(0).getCode(),
									ManagePaymentInfoServiceConstants.RETRIEVE_RECEIPTS_SERVICE_FAILED,
									subgroupReceiptsResponse.getResponseHeader().getTransactionNotification().getRemarks().getMessages().get(0).getDescription());	
							LOGGER.error(transactionId + " - "+ METHOD_PROCESS + ManagePaymentInfoServiceConstants.FAILURE );
							
							if (!messages.isEmpty()) {
								response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.WARNING,
										ManagePaymentInfoServiceConstants.WARNING_STATUS_CODE, response.getResponseHeader(), messages));
								messages.clear();
							}
						}
					}
				} else {
					messages.clear();
					ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
							ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
							ManagePaymentInfoServiceConstants.RETRIEVE_RECEIPTS_SERVICE_ERROR);
					LOGGER.error(transactionId + " - "+ METHOD_PROCESS + ManagePaymentInfoServiceConstants.FAILURE );
				}
			} catch (Exception ex) {
				
				messages.clear();
				ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
						ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
						ManagePaymentInfoServiceConstants.RETRIEVE_RECEIPTS_SERVICE_ERROR);
				LOGGER.error(transactionId + " - "+ METHOD_PROCESS + ManagePaymentInfoServiceConstants.RETRIEVE_RECEIPTS_SERVICE_ERROR, ex);
			}
			
			if (!messages.isEmpty()) {
				response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE,
						ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, response.getResponseHeader(), messages));
			}
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			response.setResponseBody(null);
			exchange.getIn().setBody(response);
		
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_EXITING, METHOD_PROCESS);
	}

}