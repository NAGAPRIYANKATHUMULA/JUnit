/*
 * ManagePaymentInfoServiceAPI.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.api;

import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bsc.aip.core.framewrok.config.AbstractRouteBuilder;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsHistoryRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsHistoryResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.rules.ManagePaymentInfoServiceRules;

/**
 * <HTML> This class implements, initializes and binds 
 * the camel components 
 * used in the manage payment Service </HTML>
 *
 * @author Cognizant Technology Solutions
 * @version 1.0
 *     
 */

@Component
public class ManagePaymentInfoServiceAPI extends AbstractRouteBuilder{
	
	
	@Value("${manage.payment.getschedule.service.api.uri}")
	private String getScheduleServiceUri;

	@Value("${manage.payment.getschedule.service.api.desc}")
	private String getScheduleServiceApiDesc;

	@Value("${manage.payment.getschedule.service.api.processor}")
	private String getScheduleServiceRequestProcessor;
	
	@Value("${manage.payment.retrievebankaccountinfo.service.api.uri}")
	private String retrieveBankAccInfoServiceUri;

	@Value("${manage.payment.retrievebankaccountinfo.service.api.desc}")
	private String retrieveBankAccInfoServiceApiDesc;

	@Value("${manage.payment.retrievebankaccountinfo.service.api.processor}")
	private String retrieveBankAccInfoServiceRequestProcessor;
	
	@Value("${manage.subgroups.payment.set.service.api.uri}")
	private String subgroupsPaymentSetServiceUri;

	@Value("${manage.subgroups.payment.set.service.api.desc}")
	private String subgroupsPaymentSetServiceApiDesc;

	@Value("${manage.subgroups.payment.set.service.api.processor}")
	private String subgroupsPaymentSetServiceRequestProcessor;
	
	@Value("${manage.subgroups.payment.cancel.service.api.uri}")
	private String subgroupsPaymentCancelServiceUri;

	@Value("${manage.subgroups.payment.cancel.service.api.desc}")
	private String subgroupsPaymentCancelServiceApiDesc;

	@Value("${manage.subgroups.payment.cancel.service.api.processor}")
	private String subgroupsPaymentCancelServiceRequestProcessor;
	
	//Set Or Cancel Payment Schedule
	
	@Value("${manage.subgroups.set.payment.schedule.service.api.uri}")
	private String subgroupsSetPaymentScheduleApiUri;
	
	@Value("${manage.subgroups.set.payment.schedule.service.api.processor}")
	private String subgroupsSetPaymentScheduleRequestProcessor;
	
	@Value("${manage.subgroups.set.payment.schedule.service.api.desc}")
	private String subgroupsSetPaymentScheduleApiDesc;
	
	@Value("${manage.subgroups.cancel.payment.schedule.service.api.uri}")
	private String subgroupsCancelPaymentScheduleApiUri;
	
	@Value("${manage.subgroups.cancel.payment.schedule.service.api.processor}")
	private String subgroupsCancelPaymentScheduleRequestProcessor;
	
	@Value("${manage.subgroups.cancel.payment.schedule.service.api.desc}")
	private String subgroupsCancelPaymentScheduleApiDesc;
	
	@Value("${manage.subgroups.batch.payment.schedule.service.api.uri}")
	private String subgroupsBatchPaymentScheduleApiUri;
	
	@Value("${manage.subgroups.batch.payment.schedule.service.api.processor}")
	private String subgroupsBatchPaymentScheduleRequestProcessor;
	
	@Value("${manage.subgroups.batch.payment.schedule.service.api.desc}")
	private String subgroupsBatchPaymentScheduleApiDesc;
	//autopayment service
	
	@Value("${manage.subgroups.autopayment.set.service.api.uri}")
	private String subgroupsAutoPaymentSetServiceUri;

	@Value("${manage.subgroups.autopayment.set.service.api.desc}")
	private String subgroupsAutoPaymentSetServiceApiDesc;

	@Value("${manage.subgroups.autopayment.set.service.api.processor}")
	private String subgroupsAutoPaymentSetServiceRequestProcessor;
	
	@Value("${manage.subgroups.autopayment.cancel.service.api.uri}")
	private String subgroupsAutoPaymentCancelServiceUri;

	@Value("${manage.subgroups.autopayment.cancel.service.api.desc}")
	private String subgroupsAutoPaymentCancelServiceApiDesc;

	@Value("${manage.subgroups.autopayment.cancel.service.api.processor}")
	private String subgroupsAutoPaymentCancelServiceRequestProcessor;
	
	//Set or Cancel Bank Account Info
	
	@Value("${manage.subgroups.bankaccountinfo.set.service.api.uri}")
	private String subgroupsBankAccInfoSetServiceUri;

	@Value("${manage.subgroups.bankaccountinfo.set.service.api.desc}")
	private String subgroupsBankAccInfoSetServiceApiDesc;

	@Value("${manage.subgroups.bankaccountinfo.set.service.api.processor}")
	private String subgroupsBankAccInfoSetServiceRequestProcessor;
	
	@Value("${manage.subgroups.bankaccountinfo.cancel.service.api.uri}")
	private String subgroupsBankAccInfoCancelServiceUri;

	@Value("${manage.subgroups.bankaccountinfo.cancel.service.api.desc}")
	private String subgroupsBankAccInfoCancelServiceApiDesc;

	@Value("${manage.subgroups.bankaccountinfo.cancel.service.api.processor}")
	private String subgroupsBankAccInfoCancelServiceRequestProcessor;
	
	//manage bank account info set 
	@Value("${manage.bank.accounts.set.service.api.uri}")
	private String manageBankAccSetServiceUri;

	@Value("${manage.bank.accounts.set.service.api.desc}")
	private String manageBankAccSetServiceApiDesc;

	@Value("${manage.bank.accounts.set.service.api.processor}")
	private String manageBankAccSetServiceRequestProcessor;
	
	@Value("${manage.bank.accounts.cancel.service.api.uri}")
	private String manageBankAccCancelServiceUri;

	@Value("${manage.bank.accounts.cancel.service.api.desc}")
	private String manageBankAccCancelServiceApiDesc;

	@Value("${manage.bank.accounts.cancel.service.api.processor}")
	private String manageBankAccCancelServiceRequestProcessor;
	
	// Retrieve AutoPayments for Groups Service
	
	@Value("${employers.retrieve.autopayments.service.api.uri}")
	private String retrieveAutoPaymentsServiceUri;

	@Value("${employers.retrieve.autopayments.service.api.desc}")
	private String retrieveAutoPaymentsServiceApiDesc;

	@Value("${employers.retrieve.autopayments.service.api.processor}")
	private String retrieveAutoPaymentsServiceRequestProcessor;
	
	// Retrieve AutoPayments History Service
	
	@Value("${employers.retrieve.autopayments.history.service.api.uri}")
	private String retrieveAutoPaymentsHistoryServiceUri;

	@Value("${employers.retrieve.autopayments.history.service.api.desc}")
	private String retrieveAutoPaymentsHistoryServiceApiDesc;

	@Value("${employers.retrieve.autopayments.history.service.api.processor}")
	private String retrieveAutoPaymentsHistoryServiceRequestProcessor;
	
	//manage one time payment set
	@Value("${manage.onetime.payment.set.service.api.uri}")
	private String manageOneTimePymtSetServiceUri;

	@Value("${manage.onetime.payment.set.service.api.desc}")
	private String manageOneTimePymtSetServiceApiDesc;

	@Value("${manage.onetime.payment.set.service.api.processor}")
	private String manageOneTimePymtSetServiceRequestProcessor;
	
	// Cancel One Time Payment Service
	@Value("${manage.onetime.payment.cancel.service.api.uri}")
	private String manageOnetimePayCancelServiceUri;

	@Value("${manage.onetime.payment.cancel.service.api.desc}")
	private String manageOnetimePayCancelServiceApiDesc;

	@Value("${manage.onetime.payment.cancel.service.api.processor}")
	private String manageOneTimePymtRequestProcessor;	
	

	@Value("${manage.onetimepayment.get.service.api.uri}")
	private String manageOnetimePaymentGetServiceUri;

	@Value("${manage.onetimepayment.get.service.api.desc}")
	private String manageOnetimePaymentGetServiceApiDesc;

	@Value("${manage.onetimepayment.get.service.api.processor}")
	private String manageOnetimePaymentGetServiceRequestProcessor;	
	@Override
	public void configure() throws Exception {
 
		super.configure();
		
		onException(Throwable.class).handled(true).process(ManagePaymentInfoServiceRules.MANAGE_PAYMENT_INFO_SERVICE_ERROR_PROCESSOR);
		
		rest(getScheduleServiceUri).bindingMode(RestBindingMode.json_xml).post().type(RetrievePaymentInfoRequest.class).description(getScheduleServiceApiDesc)
		.outType(RetrievePaymentInfoResponse.class).to(getScheduleServiceRequestProcessor);
		
		rest(retrieveBankAccInfoServiceUri).bindingMode(RestBindingMode.json_xml).post().type(RetrievePaymentInfoRequest.class).description(retrieveBankAccInfoServiceApiDesc)
		.outType(RetrievePaymentInfoResponse.class).to(retrieveBankAccInfoServiceRequestProcessor);
		
		rest(subgroupsPaymentSetServiceUri).bindingMode(RestBindingMode.json_xml).post().type(SubgroupsSetCancelPaymentRequest.class).description(subgroupsPaymentSetServiceApiDesc)
		.outType(SubgroupsSetCancelPaymentResponse.class).to(subgroupsPaymentSetServiceRequestProcessor);
		
		rest(subgroupsPaymentCancelServiceUri).bindingMode(RestBindingMode.json_xml).post().type(SubgroupsSetCancelPaymentRequest.class).description(subgroupsPaymentCancelServiceApiDesc)
		.outType(SubgroupsSetCancelPaymentResponse.class).to(subgroupsPaymentCancelServiceRequestProcessor);
		//SCS or SCB
		rest(subgroupsSetPaymentScheduleApiUri).bindingMode(RestBindingMode.json_xml).post().type(SubgroupsSetCancelPaymentRequest.class).description(subgroupsPaymentCancelServiceApiDesc)
		.outType(SubgroupsSetCancelPaymentResponse.class).to(subgroupsSetPaymentScheduleRequestProcessor);
		
		rest(subgroupsCancelPaymentScheduleApiUri).bindingMode(RestBindingMode.json_xml).post().type(SubgroupsSetCancelPaymentRequest.class).description(subgroupsPaymentCancelServiceApiDesc)
		.outType(SubgroupsSetCancelPaymentResponse.class).to(subgroupsCancelPaymentScheduleRequestProcessor);
		 
		rest(subgroupsBatchPaymentScheduleApiUri).bindingMode(RestBindingMode.json_xml).post().type(SubgroupsSetCancelPaymentRequest.class).description(subgroupsPaymentCancelServiceApiDesc)
		.outType(SubgroupsSetCancelPaymentResponse.class).to(subgroupsBatchPaymentScheduleRequestProcessor);
		
		rest(subgroupsBankAccInfoSetServiceUri).bindingMode(RestBindingMode.json_xml).post().type(SubgroupsSetCancelPaymentRequest.class).description(subgroupsBankAccInfoSetServiceApiDesc)
		.outType(SubgroupsSetCancelPaymentResponse.class).to(subgroupsBankAccInfoSetServiceRequestProcessor);
		
		rest(subgroupsAutoPaymentSetServiceUri).bindingMode(RestBindingMode.json_xml).post().type(SubgroupsSetCancelPaymentRequest.class).description(subgroupsAutoPaymentSetServiceApiDesc)
		.outType(SubgroupsSetCancelPaymentResponse.class).to(subgroupsAutoPaymentSetServiceRequestProcessor);
		
		rest(subgroupsAutoPaymentCancelServiceUri).bindingMode(RestBindingMode.json_xml).post().type(SubgroupsSetCancelPaymentRequest.class).description(subgroupsAutoPaymentCancelServiceApiDesc)
		.outType(SubgroupsSetCancelPaymentResponse.class).to(subgroupsAutoPaymentCancelServiceRequestProcessor);
		
		rest(subgroupsBankAccInfoCancelServiceUri).bindingMode(RestBindingMode.json_xml).post().type(SubgroupsSetCancelPaymentRequest.class).description(subgroupsBankAccInfoCancelServiceApiDesc)
		.outType(SubgroupsSetCancelPaymentResponse.class).to(subgroupsBankAccInfoCancelServiceRequestProcessor);

		rest(manageBankAccSetServiceUri).bindingMode(RestBindingMode.json_xml).post().type(SubgroupsSetCancelPaymentRequest.class).description(manageBankAccSetServiceApiDesc)
		.outType(SubgroupsSetCancelPaymentResponse.class).to(manageBankAccSetServiceRequestProcessor);
		
		rest(manageBankAccCancelServiceUri).bindingMode(RestBindingMode.json_xml).post().type(SubgroupsSetCancelPaymentRequest.class).description(manageBankAccCancelServiceApiDesc)
		.outType(SubgroupsSetCancelPaymentResponse.class).to(manageBankAccCancelServiceRequestProcessor);

		// Retrieve AutoPayments for Groups Service
		rest(retrieveAutoPaymentsServiceUri).bindingMode(RestBindingMode.json_xml).post().type(RetrieveAutoPaymentsRequest.class).description(retrieveAutoPaymentsServiceApiDesc)
		.outType(RetrieveAutoPaymentsResponse.class).to(retrieveAutoPaymentsServiceRequestProcessor);
		
		// Retrieve AutoPayments History Service
		rest(retrieveAutoPaymentsHistoryServiceUri).bindingMode(RestBindingMode.json_xml).post().type(RetrieveAutoPaymentsHistoryRequest.class).description(retrieveAutoPaymentsHistoryServiceApiDesc)
		.outType(RetrieveAutoPaymentsHistoryResponse.class).to(retrieveAutoPaymentsHistoryServiceRequestProcessor);
		
		//manage one time payment set
		rest(manageOneTimePymtSetServiceUri).bindingMode(RestBindingMode.json_xml).post().type(SubgroupsSetCancelPaymentRequest.class).description(manageOneTimePymtSetServiceApiDesc)
		.outType(SubgroupsSetCancelPaymentResponse.class).to(manageOneTimePymtSetServiceRequestProcessor);
		
		// Cancel One Time Payment Service
		rest(manageOnetimePayCancelServiceUri).bindingMode(RestBindingMode.json_xml).post().type(SubgroupsSetCancelPaymentRequest.class).description(manageOnetimePayCancelServiceApiDesc)
		.outType(SubgroupsSetCancelPaymentResponse.class).to(manageOneTimePymtRequestProcessor);
		
		// Get Onetime Payment Service
		rest(manageOnetimePaymentGetServiceUri).bindingMode(RestBindingMode.json_xml).post().type(SubgroupsSetCancelPaymentRequest.class).description(manageOnetimePaymentGetServiceApiDesc)
		.outType(SubgroupsSetCancelPaymentResponse.class).to(manageOnetimePaymentGetServiceRequestProcessor);

	}
}
