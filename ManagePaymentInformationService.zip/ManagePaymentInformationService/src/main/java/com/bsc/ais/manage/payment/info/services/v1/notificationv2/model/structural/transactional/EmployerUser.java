/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/**
 * @author Cognizant Technology Solutions
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmployerUser {
	
	private String userIdentifier;
	private String username;
	private String firstName;
	private String lastName;
	private String emailAddress;
	private String emailFormat;
	private String name;
	private String scheduleInd;
	
	/**
	 * @return the userIdentifier
	 */
	public String getUserIdentifier() {
		return userIdentifier;
	}
	/**
	 * @param userIdentifier the userIdentifier to set
	 */
	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}	
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}
	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	/**
	 * @return the emailFormat
	 */
	public String getEmailFormat() {
		return emailFormat;
	}
	/**
	 * @param emailFormat the emailFormat to set
	 */
	public void setEmailFormat(String emailFormat) {
		this.emailFormat = emailFormat;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the scheduleInd
	 */
	public String getScheduleInd() {
		return scheduleInd;
	}
	/**
	 * @param scheduleInd the scheduleInd to set
	 */
	public void setScheduleInd(String scheduleInd) {
		this.scheduleInd = scheduleInd;
	}
	
	
}
