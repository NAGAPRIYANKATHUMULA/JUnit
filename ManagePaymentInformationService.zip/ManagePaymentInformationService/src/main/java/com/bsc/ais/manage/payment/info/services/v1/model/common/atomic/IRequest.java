package com.bsc.ais.manage.payment.info.services.v1.model.common.atomic;

import com.bsc.aip.core.model.common.composite.RequestHeader;

public interface IRequest {
	
	RequestHeader getRequestHeader();

}
