/*
 * EmployersFetchInvoicesResponseBody.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.model.response.invoices;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
/**
 * This class contains response body used in Manage Bills and Invoices Service
 * @author Cognizant Technology Solutions
 *
 */
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class RetrieveInvoiceInformationResponseBody {

	
	private InvoiceInformations invoiceInformations;


	/**
	 * @return the invoiceInformations
	 */
	public InvoiceInformations getInvoiceInformations() {
		return invoiceInformations;
	}

	/**
	 * @param invoiceInformations the invoiceInformations to set
	 */
	public void setInvoiceInformations(InvoiceInformations invoiceInformations) {
		this.invoiceInformations = invoiceInformations;
	}
	
	
	
	
	
}
