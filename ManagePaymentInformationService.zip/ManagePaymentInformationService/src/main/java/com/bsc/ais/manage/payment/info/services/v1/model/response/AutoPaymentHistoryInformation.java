/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author Cognizant Technology Solutions
 *
 */
@JsonInclude(Include.NON_NULL)
public class AutoPaymentHistoryInformation {

	private String action;
	private String date;
	private String subgroupIdentifier;
	private String accountNumber;
	private String routingNumber;
	private String userName;
	private String accountNickName;
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}
	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}
	/**
	 * @return the subgroupIdentifier
	 */
	public String getSubgroupIdentifier() {
		return subgroupIdentifier;
	}
	/**
	 * @param subgroupIdentifier the subgroupIdentifier to set
	 */
	public void setSubgroupIdentifier(String subgroupIdentifier) {
		this.subgroupIdentifier = subgroupIdentifier;
	}
	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}
	/**
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	/**
	 * @return the routingNumber
	 */
	public String getRoutingNumber() {
		return routingNumber;
	}
	/**
	 * @param routingNumber the routingNumber to set
	 */
	public void setRoutingNumber(String routingNumber) {
		this.routingNumber = routingNumber;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the accountNickName
	 */
	public String getAccountNickName() {
		return accountNickName;
	}
	/**
	 * @param accountNickName the accountNickName to set
	 */
	public void setAccountNickName(String accountNickName) {
		this.accountNickName = accountNickName;
	}
	
}
