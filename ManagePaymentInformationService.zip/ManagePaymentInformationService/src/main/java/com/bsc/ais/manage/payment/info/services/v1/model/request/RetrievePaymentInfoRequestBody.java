package com.bsc.ais.manage.payment.info.services.v1.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RetrievePaymentInfoRequestBody {

	private String  userIdentifier;
	private GroupIdentifiers groupIdentifiers;
	
	

	public String getUserIdentifier() {
		return userIdentifier;
	}

	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}

	public GroupIdentifiers getGroupIdentifiers() {
		return groupIdentifiers;
	}

	public void setGroupIdentifiers(GroupIdentifiers groupIdentifiers) {
		this.groupIdentifiers = groupIdentifiers;
	}
	
}
