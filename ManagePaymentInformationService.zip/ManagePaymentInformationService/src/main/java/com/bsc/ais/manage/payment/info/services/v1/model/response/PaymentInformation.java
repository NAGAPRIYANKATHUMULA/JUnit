/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author Cognizant Technology Solutions
 *
 */
@JsonInclude(Include.NON_NULL)
public class PaymentInformation {

	private String accountNickName;
	private String accountHolderName;
	private String accountNumber;
	private String routingNumber;
	private String bankAccountType;
	private String paymentFlag;
	private String subgroupIdentifier;
	private String subgroupName;
	private String groupIdentifier;
	private String paymentAmount;
	private String restrictedStatus;
	private String autoPaymentEffectiveDate;
	private String paymentNotificationMsg;
	private String currentBilledAmount;
	private String previousBalance;
	private String amountDue;
	private String paymentNotificationIndicator;
	private String isInvoiceExists;
	
	
	
	public String getCurrentBilledAmount() {
		return currentBilledAmount;
	}
	public void setCurrentBilledAmount(String currentBilledAmount) {
		this.currentBilledAmount = currentBilledAmount;
	}
	public String getPreviousBalance() {
		return previousBalance;
	}
	public void setPreviousBalance(String previousBalance) {
		this.previousBalance = previousBalance;
	}
	public String getAmountDue() {
		return amountDue;
	}
	public void setAmountDue(String amountDue) {
		this.amountDue = amountDue;
	}
	public String getPaymentNotificationIndicator() {
		return paymentNotificationIndicator;
	}
	public void setPaymentNotificationIndicator(String paymentNotificationIndicator) {
		this.paymentNotificationIndicator = paymentNotificationIndicator;
	}
	public String getIsInvoiceExists() {
		return isInvoiceExists;
	}
	public void setIsInvoiceExists(String isInvoiceExists) {
		this.isInvoiceExists = isInvoiceExists;
	}
	public String getAccountNickName() {
		return accountNickName;
	}
	public void setAccountNickName(String accountNickName) {
		this.accountNickName = accountNickName;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getRoutingNumber() {
		return routingNumber;
	}
	public void setRoutingNumber(String routingNumber) {
		this.routingNumber = routingNumber;
	}
	public String getBankAccountType() {
		return bankAccountType;
	}
	public void setBankAccountType(String bankAccountType) {
		this.bankAccountType = bankAccountType;
	}
	public String getPaymentFlag() {
		return paymentFlag;
	}
	public void setPaymentFlag(String paymentFlag) {
		this.paymentFlag = paymentFlag;
	}
	public String getSubgroupIdentifier() {
		return subgroupIdentifier;
	}
	public void setSubgroupIdentifier(String subgroupIdentifier) {
		this.subgroupIdentifier = subgroupIdentifier;
	}
	public String getSubgroupName() {
		return subgroupName;
	}
	public void setSubgroupName(String subgroupName) {
		this.subgroupName = subgroupName;
	}
	
	/**
	 * @return the groupIdentifier
	 */
	public String getGroupIdentifier() {
		return groupIdentifier;
	}
	/**
	 * @param groupIdentifier the groupIdentifier to set
	 */
	public void setGroupIdentifier(String groupIdentifier) {
		this.groupIdentifier = groupIdentifier;
	}
	/**
	 * @return the paymentAmount
	 */
	public String getPaymentAmount() {
		return paymentAmount;
	}
	/**
	 * @param paymentAmount the paymentAmount to set
	 */
	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	/**
	 * @return the restrictedStatus
	 */
	public String getRestrictedStatus() {
		return restrictedStatus;
	}
	/**
	 * @param restrictedStatus the restrictedStatus to set
	 */
	public void setRestrictedStatus(String restrictedStatus) {
		this.restrictedStatus = restrictedStatus;
	}
	/**
	 * @return the autoPaymentEffectiveDate
	 */
	public String getAutoPaymentEffectiveDate() {
		return autoPaymentEffectiveDate;
	}
	/**
	 * @param autoPaymentEffectiveDate the autoPaymentEffectiveDate to set
	 */
	public void setAutoPaymentEffectiveDate(String autoPaymentEffectiveDate) {
		this.autoPaymentEffectiveDate = autoPaymentEffectiveDate;
	}
	/**
	 * @return the paymentNotificationMsg
	 */
	public String getPaymentNotificationMsg() {
		return paymentNotificationMsg;
	}
	/**
	 * @param paymentNotificationMsg the paymentNotificationMsg to set
	 */
	public void setPaymentNotificationMsg(String paymentNotificationMsg) {
		this.paymentNotificationMsg = paymentNotificationMsg;
	}	
	
}
