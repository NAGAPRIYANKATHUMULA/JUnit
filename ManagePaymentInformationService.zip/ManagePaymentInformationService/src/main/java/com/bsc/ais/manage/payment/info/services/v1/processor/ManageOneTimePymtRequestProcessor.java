/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bsc.aip.core.camel.template.BscCamelTemplate;
import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Consumer;
import com.bsc.aip.core.model.common.atomic.Credentials;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupIdentifier;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupSubgroup;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformations;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;

/**
 * @author Cognizant
 *
 */
@Component("manageOneTimePymtRequestProcessor")
public class ManageOneTimePymtRequestProcessor implements Processor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LogManager.getLogger(ManageBankAccountsRequestProcessor.class);

	/**
	 * Holds the method name.
	 */
	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";

	/**
	 * Obtain an instance of EventLogging
	 */
	@Resource
	private EventLogging eventLogging;

	/**
	 * Holds transaction identifier.
	 */
	private String transactionId = "";
	
	@Resource(name = "bscCamelTemplate")
	private BscCamelTemplate bscCamelTemplate;
	
	/** Value of id_token. */
	@Value("${api.services.security.passthrough}")
	private String idToken;

	/*
	 * (non-Javadoc)
	 * 
	 * This method is used to process the bank account info set service request
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	public void process(Exchange exchange) throws Exception {

		// Create an instance of service response
		SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();

		// Obtain the instance of service request
		SubgroupsSetCancelPaymentRequest request = (SubgroupsSetCancelPaymentRequest) exchange.getIn().getBody();

		// Create an instance of list of Audit event
		List<AuditEvent> auditEventList = new ArrayList<AuditEvent>();
		try {

			// set the instance of service request to exchange as property
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);

			// Get transaction id from the request.
			if ((null != request) && (null != request.getRequestHeader())) {
				transactionId = (String) request.getRequestHeader().getTransactionId();
				exchange.setProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID, transactionId);
				exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQ_HEADER, request.getRequestHeader());
			}

			LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_ENTERING + METHOD_PROCESS);

			// Logging event for the request.
			eventLogging.logEvent(request.getRequestHeader(), null, ManagePaymentInfoServiceConstants.AUDIT,
					ManagePaymentInfoServiceConstants.ENTRY, null, null, null, null,
					(String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME));

			// adding transactionId to request header
			if (StringUtils
					.isEmpty((String) exchange.getIn().getHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID)))
				exchange.getIn().setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, transactionId);
			// validation for request header and request body
			if (validateRequestHeader(request, response) && validateRequestBody(request, response, exchange)
					&& validateRequestStructure(request)) {
				exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS,
						ManagePaymentInfoServiceConstants.STRING_TRUE);
				response.setResponseHeader(
						ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.SUCCESS,
								ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE, null, null));
				setExchangeProps(request, exchange);
				LOGGER.info(transactionId + " - " + METHOD_PROCESS + "Request is valid.");
			} else {
				exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS,
						ManagePaymentInfoServiceConstants.STRING_FALSE);
				LOGGER.info(transactionId + " - " + METHOD_PROCESS + "Request is invalid.");

				// audit logging
				ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,
						ManagePaymentInfoServiceConstants.SET_BANK_ACC_EVENT_FAILURE_CODE);
			}
			response.getResponseHeader().getTransactionNotification().setTransactionId(transactionId);

		} catch (Exception ex) {
			LOGGER.error(transactionId + " - " + METHOD_PROCESS, ex);
			List<Message> messages = new ArrayList<Message>();
			ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR, ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);
			response.setResponseHeader(
					ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE,
							ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, null, messages));
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);

			// audit logging
			ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,
					ManagePaymentInfoServiceConstants.SET_BANK_ACC_EVENT_FAILURE_CODE);
		}
		response.setResponseBody(null);
		exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESP_HEADER, response.getResponseHeader());
		exchange.getIn().setBody(response);
		
		//call security validation
		String validationSuccess = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS);
		String userIdentifier = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER);
		if(StringUtils.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_TRUE, validationSuccess)
				&& StringUtils.isNotBlank(userIdentifier) && 
				!request.getRequestHeader().getConsumer().getName().equalsIgnoreCase(ManagePaymentInfoServiceConstants.IVR)){
		Credentials credentials = request.getRequestHeader().getCredentials();
		if (credentials != null) {
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_ID_TOKEN, credentials.getToken());
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_REFRESH_TOKEN, ManagePaymentInfoServiceConstants.EMPTY_STR);
		if (!StringUtils.equals(credentials.getToken(), idToken)) {
			bscCamelTemplate.getProducerTemplate()
										.send("direct:empPymtSecurityValidationProcessorCall", exchange);
		}
		}
		}
		LOGGER.debug(ManagePaymentInfoServiceConstants.METHOD_EXITING + METHOD_PROCESS + transactionId);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * This method is used to set the input parameters to exchange object
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	private void setExchangeProps(SubgroupsSetCancelPaymentRequest request, Exchange exchange) {
		LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_ENTERING + "setExchangeProps");
		String serviceName = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME);
		
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER,
				request.getRequestBody().getUserIdentifier());
		if (serviceName.equals(ManagePaymentInfoServiceConstants.MANAGE_ONE_TIME_PYMT_SET)){
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_SUB_GRP_ID,
				request.getRequestBody().getGroupIdentifiers().getGroupIdentifier().get(0).getGroupSubgroups()
						.getGroupSubgroup().get(0).getGroupSubgroupIdentifier());
		request.getRequestBody().getPaymentInformations().getPaymentInformation().get(0).setSubgroupIdentifier(request.getRequestBody().getGroupIdentifiers().getGroupIdentifier().get(0).getGroupSubgroups()
						.getGroupSubgroup().get(0).getGroupSubgroupIdentifier());
		request.getRequestBody().getPaymentInformations().getPaymentInformation().get(0).setGroupIdentifier(request.getRequestBody().getGroupIdentifiers().getGroupIdentifier().get(0).getGroupSubgroups()
						.getGroupSubgroup().get(0).getGroupSubgroupIdentifier().substring(0, 8));
		if( null != request.getRequestBody().getEmailInformation() && StringUtils.isNotBlank(request.getRequestBody().getEmailInformation().getName()) &&
				StringUtils.isNotBlank(request.getRequestBody().getEmailInformation().getGroupIdentifier()) &&
				StringUtils.isNotBlank(request.getRequestBody().getEmailInformation().getEmailAddress())){
			exchange.setProperty(ManagePaymentInfoServiceConstants.EMAIL_INFO_EXISTS,ManagePaymentInfoServiceConstants.STRING_TRUE);
		} else{
			exchange.setProperty(ManagePaymentInfoServiceConstants.EMAIL_INFO_EXISTS,ManagePaymentInfoServiceConstants.STRING_FALSE);
		}
		if(StringUtils.isNotBlank(request.getRequestBody().getPaymentInformations().getPaymentInformation().get(0).getAccountNumber()) &&
				StringUtils.isNotBlank(request.getRequestBody().getPaymentInformations().getPaymentInformation().get(0).getAccountHolderName()) &&
				StringUtils.isNotBlank(request.getRequestBody().getPaymentInformations().getPaymentInformation().get(0).getRoutingNumber()) &&
				StringUtils.isNotBlank(request.getRequestBody().getPaymentInformations().getPaymentInformation().get(0).getBankAccountType()) &&
				StringUtils.isNotBlank(request.getRequestBody().getPaymentInformations().getPaymentInformation().get(0).getRestrictedStatus())
				){
	      exchange.setProperty(ManagePaymentInfoServiceConstants.BANK_ACC_SET_CALL_SUCCESS,ManagePaymentInfoServiceConstants.STRING_TRUE);
	      exchange.setProperty(ManagePaymentInfoServiceConstants.SET_BANK_ACC_RESPONSE_SUCCESS,ManagePaymentInfoServiceConstants.STRING_FALSE);
	      exchange.setProperty(ManagePaymentInfoServiceConstants.CANCEL_BANK_ACC,ManagePaymentInfoServiceConstants.STRING_FALSE);
		} else{
			exchange.setProperty(ManagePaymentInfoServiceConstants.BANK_ACC_SET_CALL_SUCCESS,ManagePaymentInfoServiceConstants.STRING_FALSE);
		}
		} else if(serviceName.equals(ManagePaymentInfoServiceConstants.MANAGE_ONE_TIME_PYMT_CANCEL)){
			PaymentInformation paymentInformation = new PaymentInformation();
			List<PaymentInformation> paymentInformationList = new ArrayList<>();
			paymentInformationList.add(paymentInformation);
			PaymentInformations paymentInformations = new PaymentInformations();
			paymentInformations.setPaymentInformation(paymentInformationList);
			request.getRequestBody().setPaymentInformations(paymentInformations);
			request.getRequestBody().getPaymentInformations().getPaymentInformation().get(0).setSubgroupIdentifier(request.getRequestBody().getGroupIdentifiers().getGroupIdentifier().get(0).getGroupSubgroups()
					.getGroupSubgroup().get(0).getGroupSubgroupIdentifier());	
		} else{
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_SUB_GRP_ID,
					request.getRequestBody().getGroupIdentifiers().getGroupIdentifier().get(0).getGroupSubgroups()
							.getGroupSubgroup().get(0).getGroupSubgroupIdentifier());
		}
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER, request.getRequestBody().getUserIdentifier().trim());
		Set<String> groupIdentifierSet = new HashSet<>();
		Set<String> subGroupIdentifierSet = new HashSet<>();
		if (null != request.getRequestBody() && null != request.getRequestBody().getGroupIdentifiers()
				&& null != request.getRequestBody().getGroupIdentifiers().getGroupIdentifier()
				&& !request.getRequestBody().getGroupIdentifiers().getGroupIdentifier().isEmpty()) {
			for (GroupIdentifier grpIdentifier : request.getRequestBody().getGroupIdentifiers().getGroupIdentifier()) {

				if (StringUtils.isNotBlank(grpIdentifier.getGroupIdentifier())) {
					groupIdentifierSet.add(grpIdentifier.getGroupIdentifier());
				}
				if (null != grpIdentifier.getGroupSubgroups()
						&& null != grpIdentifier.getGroupSubgroups().getGroupSubgroup()
						&& !grpIdentifier.getGroupSubgroups().getGroupSubgroup().isEmpty()) {
					for (GroupSubgroup groupSubgroup : grpIdentifier.getGroupSubgroups().getGroupSubgroup()) {
						if (StringUtils.isNotBlank(groupSubgroup.getGroupSubgroupIdentifier())) {
							subGroupIdentifierSet.add(groupSubgroup.getGroupSubgroupIdentifier());
						}
					}
				}
			}
		}
		exchange.setProperty(ManagePaymentInfoServiceConstants.GROUP_IDENTIFIER_SET, groupIdentifierSet);
		exchange.setProperty(ManagePaymentInfoServiceConstants.SUB_GROUP_IDENTIFIER_SET,subGroupIdentifierSet);
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);
	}

	/**
	 * Method to validate the request structure.
	 * 
	 * @param request
	 * @return
	 */
	private boolean validateRequestStructure(SubgroupsSetCancelPaymentRequest request) {

		boolean isSuccess = true;
		List<Message> messages = new ArrayList<Message>();
		if (request == null) {
			isSuccess = false;
			ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
					ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
					ManagePaymentInfoServiceConstants.MSG_DESC_INVALID_PAYLOAD);

		}
		return isSuccess;
	}

	/**
	 * Method to validate the request body.
	 * 
	 * @param request
	 * @param exchange
	 * @return
	 */
	private boolean validateRequestBody(SubgroupsSetCancelPaymentRequest request,
			SubgroupsSetCancelPaymentResponse response, Exchange exchange) {

		LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_ENTERING + "validateRequestBody");
		boolean isSuccess = true;
		List<Message> messages = new ArrayList<Message>();

		try {
			if (request != null && request.getRequestBody() != null) {

				if (isSuccess && StringUtils.isBlank(request.getRequestBody().getUserIdentifier())) {
					isSuccess = false;
					ManagePaymentInfoServiceUtil.addMessage(messages,
							ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
							ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
							ManagePaymentInfoServiceConstants.MSG_DESC_MAND_USER_IDENTIFIER);
				}

				if ((isSuccess) && (request.getRequestBody().getGroupIdentifiers() == null
						|| request.getRequestBody().getGroupIdentifiers().getGroupIdentifier().isEmpty())) {
					isSuccess = false;
					ManagePaymentInfoServiceUtil.addMessage(messages,
							ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
							ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
							ManagePaymentInfoServiceConstants.MSG_DESC_MAND_GROUP_SUB_GROUP_IDENTIFIER);
				}

				if ((isSuccess) && (!request.getRequestBody().getGroupIdentifiers().getGroupIdentifier().isEmpty())) {

					if (request.getRequestBody().getGroupIdentifiers().getGroupIdentifier().size() > 1) {
						isSuccess = false;
						ManagePaymentInfoServiceUtil.addMessage(messages,
								ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
								ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
								ManagePaymentInfoServiceConstants.SINGLE_SUB_GRP);
					} else {
						for (GroupIdentifier groupIdentifier : request.getRequestBody().getGroupIdentifiers()
								.getGroupIdentifier()) {

							if (isSuccess) {
								if ((null == groupIdentifier.getGroupSubgroups()
										|| null == groupIdentifier.getGroupSubgroups().getGroupSubgroup()
										|| groupIdentifier.getGroupSubgroups().getGroupSubgroup().isEmpty())) {

									isSuccess = false;
									ManagePaymentInfoServiceUtil.addMessage(messages,
											ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
											ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
											ManagePaymentInfoServiceConstants.MSG_DESC_MAND_GROUP_SUB_GROUP_IDENTIFIER);
								} else if (!groupIdentifier.getGroupSubgroups().getGroupSubgroup().isEmpty()) {

									if (groupIdentifier.getGroupSubgroups().getGroupSubgroup().size() > 1) {
										isSuccess = false;
										ManagePaymentInfoServiceUtil.addMessage(messages,
												ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
												ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
												ManagePaymentInfoServiceConstants.SINGLE_SUB_GRP);
									}

									for (GroupSubgroup groupSubgroup : groupIdentifier.getGroupSubgroups()
											.getGroupSubgroup()) {
										if (isSuccess) {
											if (StringUtils.isBlank(groupSubgroup.getGroupSubgroupIdentifier())) {
												isSuccess = false;
												ManagePaymentInfoServiceUtil.addMessage(messages,
														ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
														ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
														ManagePaymentInfoServiceConstants.MSG_DESC_MAND_GROUP_SUB_GROUP_IDENTIFIER);

											} else if (groupSubgroup.getGroupSubgroupIdentifier().length() != 12) {
												isSuccess = false;
												ManagePaymentInfoServiceUtil.addMessage(messages,
														ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
														ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
														ManagePaymentInfoServiceConstants.MSG_DESC_MAND_GROUP_SUB_GROUP_INVALID);
											}
										}
									}
								}
							}
						}
					}
				}

				if (exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME)
						.equals(ManagePaymentInfoServiceConstants.MANAGE_ONE_TIME_PYMT_SET)) {

					if ((isSuccess) && (request.getRequestBody().getPaymentInformations() == null
							|| request.getRequestBody().getPaymentInformations().getPaymentInformation().isEmpty())) {
						isSuccess = false;
						ManagePaymentInfoServiceUtil.addMessage(messages,
								ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
								ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
								ManagePaymentInfoServiceConstants.NO_PAYMENT_INFO);
					}

					if ((isSuccess) && (request.getRequestBody().getPaymentInformations() == null
							|| request.getRequestBody().getPaymentInformations().getPaymentInformation().size() > 1)) {
						isSuccess = false;
						ManagePaymentInfoServiceUtil.addMessage(messages,
								ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
								ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
								ManagePaymentInfoServiceConstants.MULTIPLE_BANK_ACC_INFO);
					}
					if ((isSuccess)
							&& (!request.getRequestBody().getPaymentInformations().getPaymentInformation().isEmpty())) {

						for (PaymentInformation paymentInformation : request.getRequestBody().getPaymentInformations()
								.getPaymentInformation()) {

							if (isSuccess && (StringUtils.isBlank(paymentInformation.getAccountNickName()))) {
								ManagePaymentInfoServiceUtil.addMessage(messages,
										ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
										ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
										ManagePaymentInfoServiceConstants.MSG_DESC_MAND_ACC_NICK_NAME);
								isSuccess = false;
							}
							if (isSuccess && (StringUtils.isBlank(paymentInformation.getPaymentAmount()))) {
								ManagePaymentInfoServiceUtil.addMessage(messages,
										ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
										ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
										ManagePaymentInfoServiceConstants.MSG_DEC_PYMT_AMT);
								isSuccess = false;
							}
							if (isSuccess &&
							StringUtils.isNotBlank(request.getRequestBody().getPaymentInformations().getPaymentInformation().get(0).getAccountNumber()) &&
							StringUtils.isNotBlank(request.getRequestBody().getPaymentInformations().getPaymentInformation().get(0).getAccountHolderName()) &&
							StringUtils.isNotBlank(request.getRequestBody().getPaymentInformations().getPaymentInformation().get(0).getRoutingNumber()) &&
							StringUtils.isNotBlank(request.getRequestBody().getPaymentInformations().getPaymentInformation().get(0).getBankAccountType()) &&
							StringUtils.isNotBlank(request.getRequestBody().getPaymentInformations().getPaymentInformation().get(0).getRestrictedStatus())){
								if(isSuccess && (StringUtils.isNotBlank(paymentInformation.getBankAccountType()) && !StringUtils.equalsIgnoreCase(paymentInformation.getBankAccountType(), ManagePaymentInfoServiceConstants.SAVINGS) 
										&& !StringUtils.equalsIgnoreCase(paymentInformation.getBankAccountType(), ManagePaymentInfoServiceConstants.CHECKING))){
									ManagePaymentInfoServiceUtil.addMessage(messages,
											ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
											ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
											ManagePaymentInfoServiceConstants.MSG_DESC_BANKACC_TYPE_INVALID);
									isSuccess = false;
								}
								
								if(isSuccess && (!StringUtils.equalsIgnoreCase(paymentInformation.getRestrictedStatus(), ManagePaymentInfoServiceConstants.STRING_TRUE) 
										&& !StringUtils.equalsIgnoreCase(paymentInformation.getRestrictedStatus(), ManagePaymentInfoServiceConstants.STRING_FALSE))){
									ManagePaymentInfoServiceUtil.addMessage(messages,
											ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
											ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
											ManagePaymentInfoServiceConstants.MSG_DESC_RESTRCT_STATUS_INVALID);
									isSuccess = false;
								}
								
							}
							
						}
					}

				}

			} else {
				ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
						ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
						ManagePaymentInfoServiceConstants.MSG_DESC_MAND_BUSINESS_REQ_BODY);

			}
		} catch (Exception ex) {
			isSuccess = false;
			ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
					ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
					ManagePaymentInfoServiceConstants.ERROR_DESCRIPTION_REQ);
		}

		if (!messages.isEmpty()) {
			response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(
					ManagePaymentInfoServiceConstants.FAILURE, ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE,
					response.getResponseHeader(), messages));
			isSuccess = false;
		}

		LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_EXITING + "validateRequestBody");

		return isSuccess;

	}

	/**
	 * Method to validate the request header.
	 *
	 * @param request
	 *            the request
	 * @param response
	 *            the response
	 * @return
	 */
	private boolean validateRequestHeader(SubgroupsSetCancelPaymentRequest request,
			SubgroupsSetCancelPaymentResponse response) {

		LOGGER.debug(
				transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_ENTERING + "validateRequestHeader");
		boolean isSuccess = true;
		List<Message> messages = new ArrayList<Message>();

		try {
			if (request != null && request.getRequestHeader() != null) {
				if (StringUtils.isBlank(request.getRequestHeader().getTransactionId())) {
					ManagePaymentInfoServiceUtil.addMessage(messages,
							ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
							ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
							ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_TRANSACTION_ID);
					isSuccess = false;
				}
				if (isSuccess) {
					if (request.getRequestHeader().getConsumer() != null) {

						Consumer consumer = request.getRequestHeader().getConsumer();

						if (isSuccess && StringUtils.isBlank(consumer.getName())) {
							isSuccess = false;
							ManagePaymentInfoServiceUtil.addMessage(messages,
									ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_CONSUMER);
						}
						if (isSuccess && StringUtils.isBlank(consumer.getId())) {
							isSuccess = false;
							ManagePaymentInfoServiceUtil.addMessage(messages,
									ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_CONSUMER);
						}
						if (isSuccess && StringUtils.isBlank(consumer.getType())) {
							isSuccess = false;
							ManagePaymentInfoServiceUtil.addMessage(messages,
									ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_CONSUMER);
						}
						if (isSuccess && StringUtils.isBlank(consumer.getBusinessUnit())) {
							isSuccess = false;
							ManagePaymentInfoServiceUtil.addMessage(messages,
									ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_CONSUMER);
						}
						if (isSuccess && StringUtils.isBlank(consumer.getHostName())) {
							isSuccess = false;
							ManagePaymentInfoServiceUtil.addMessage(messages,
									ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_CONSUMER);
						}
					} else {
						isSuccess = false;
						ManagePaymentInfoServiceUtil.addMessage(messages,
								ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
								ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
								ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_CONSUMER);
					}

				}
				if (isSuccess && !request.getRequestHeader().getConsumer().getName().equalsIgnoreCase(ManagePaymentInfoServiceConstants.IVR)) {
					if (request.getRequestHeader().getCredentials() != null) {

						Credentials credentials = request.getRequestHeader().getCredentials();

						if (isSuccess && StringUtils.isBlank(credentials.getToken())) {
							isSuccess = false;
							ManagePaymentInfoServiceUtil.addMessage(messages,
									ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_DESC_TOKEN);
						}
						if (isSuccess && StringUtils.isBlank(credentials.getType())) {
							isSuccess = false;
							ManagePaymentInfoServiceUtil.addMessage(messages,
									ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
									ManagePaymentInfoServiceConstants.MSG_DESC_TOKEN_TYPE);
						}
					} else {
						isSuccess = false;
						ManagePaymentInfoServiceUtil.addMessage(messages,
								ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
								ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
								ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_CREDENTIALS);
					}
				}
			} else {
				ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
						ManagePaymentInfoServiceConstants.MSG_FORBIDDEN,
						ManagePaymentInfoServiceConstants.MSG_DESC_FORBIDDEN_HEADER);
			}
		} catch (Exception ex) {
			ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
					ManagePaymentInfoServiceConstants.ERROR_DESCRIPTION_REQ);
		}

		if (!messages.isEmpty()) {
			response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(
					ManagePaymentInfoServiceConstants.FAILURE, ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE,
					response.getResponseHeader(), messages));
			isSuccess = false;
		}

		LOGGER.debug(
				transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_EXITING + "validateRequestHeader");

		return isSuccess;
	}

}
