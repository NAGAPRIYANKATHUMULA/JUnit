/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.invoices.RetrieveInvoiceInformationRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.request.invoices.RetrieveInvoiceInformationRequestBody;
import com.bsc.ais.manage.payment.info.services.v1.model.request.invoices.SubgroupIdentifier;
import com.bsc.ais.manage.payment.info.services.v1.model.request.invoices.SubgroupIdentifiers;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformations;
import com.bsc.ais.manage.payment.info.services.v1.model.response.SubgroupsSetCancelPaymentResponseBody;
import com.bsc.ais.manage.payment.info.services.v1.model.response.invoices.InvoiceInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.response.invoices.RetrieveInvoiceInformationResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceWPRDbUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author 690294
 *
 */
@Component("getOneTimePymtServiceProcessor")
public class GetOneTimePymtServiceProcessor implements Processor {

	private static final Logger LOGGER = LogManager.getLogger(GetOneTimePymtServiceProcessor.class);

	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";

	private RestTemplate restTemplate = new RestTemplate();

	@Value("${retrieve.autopayments.invoices.subgroups.service.url}")
	private String retrieveInvoicesforSubgroupV2ServiceUrl;

	@Value("${manage.payment.info.composite.custom.header.x-ibm-client-id}")
	private String xClientId;

	@Value("${manage.payment.info.composite.custom.header.x-ibm-client-secret}")
	private String xClientSecret;

	@Value("${api.services.security.passthrough}")
	private String idToken;
	
	@Resource
	private EventLogging eventLogging;

	
	@Resource
	ManagePaymentInfoServiceWPRDbUtil managePaymentInfoServiceWPRDbUtil;
	
	/*
	 * (non-Javadoc)
	 * 
	 * This class is used for retrieving invoices info using
	 * RetrieveInvoicesforSubGroupV2 Service
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	@SuppressWarnings({ "unchecked" })
	public void process(Exchange exchange) throws Exception {

		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_ENTERING, METHOD_PROCESS);

		// Obtain an instance of service request from exchange object.
		SubgroupsSetCancelPaymentRequest request = (SubgroupsSetCancelPaymentRequest) exchange
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST);
		// Obtain an instance of service response from exchange object.
		SubgroupsSetCancelPaymentResponse response = (SubgroupsSetCancelPaymentResponse) exchange
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);

		SubgroupsSetCancelPaymentResponseBody responseBody = new SubgroupsSetCancelPaymentResponseBody();
		// Obtain the list of subGroupIdentifier from exchange object.
		String subgroupId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_SUB_GRP_ID);

		List<Message> messages = new ArrayList<Message>();

		try {
			// obtain HttpHeaders info
			HttpHeaders httpHeaders = ManagePaymentInfoServiceUtil.obtainHttpHeadersInfo(exchange, xClientId,
					xClientSecret);

			ObjectMapper requestMapper = new ObjectMapper();
			RequestHeader requestHeader = new RequestHeader();
			HttpEntity<String> requestEntity;
			ResponseEntity<String> invoicesServiceResponse = null;

			// Build Retrieve Invoice for SubGroup Service Request
			RetrieveInvoiceInformationRequest retrieveInvoiceInformationRequest = new RetrieveInvoiceInformationRequest();
			requestHeader = request.getRequestHeader();
			if(null != requestHeader.getCredentials()){
				requestHeader.getCredentials().setToken(idToken);
				requestHeader.getCredentials().setType(ManagePaymentInfoServiceConstants.ID_TOKEN);
			}
			retrieveInvoiceInformationRequest.setRequestHeader(requestHeader);
			retrieveInvoiceInformationRequest.setRequestBody(new RetrieveInvoiceInformationRequestBody());
           
			String userIdentifier = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER);
			SubgroupIdentifiers subgroupIdentifiers = new SubgroupIdentifiers();
			List<SubgroupIdentifier> subGroupIdList = new ArrayList<SubgroupIdentifier>();
			SubgroupIdentifier subgroupIdentifier = new SubgroupIdentifier();
			subgroupIdentifier.setSubgroupIdentifier(subgroupId);
			subGroupIdList.add(subgroupIdentifier);
			subgroupIdentifiers.setSubgroupIdentifier(subGroupIdList);

			retrieveInvoiceInformationRequest.getRequestBody().setUserIdentifier(userIdentifier);
			retrieveInvoiceInformationRequest.getRequestBody().setStatus("O,D");
			retrieveInvoiceInformationRequest.getRequestBody()
					.setRequestType(ManagePaymentInfoServiceConstants.REQUEST_TYPE_SG);
			retrieveInvoiceInformationRequest.getRequestBody()
					.setIsInvoiceFilterRequired(ManagePaymentInfoServiceConstants.STRING_NO);
			retrieveInvoiceInformationRequest.getRequestBody().setSubgroupIdentifiers(subgroupIdentifiers);

			requestEntity = new HttpEntity<String>(requestMapper.writeValueAsString(retrieveInvoiceInformationRequest),
					httpHeaders);
			LOGGER.debug(transactionId + " - " + "Retrieve invoices for Subgroup Service Request: " + requestEntity);
			// call the RetrieveInvoicesforSubGroup Service and get the response
			invoicesServiceResponse = restTemplate.exchange(retrieveInvoicesforSubgroupV2ServiceUrl, HttpMethod.POST,
					requestEntity, String.class);

			if (invoicesServiceResponse != null) {
				ObjectMapper responseMapper = new ObjectMapper();
				String invoicesServiceResponseString = ManagePaymentInfoServiceUtil.processSyncResponse(
						invoicesServiceResponse,
						ManagePaymentInfoServiceConstants.RETRIEVE_INVOICES_FOR_SUBGROUP_SERVICE);
				if (!StringUtils.isBlank(invoicesServiceResponseString)) {
					RetrieveInvoiceInformationResponse subgroupInvoicesResponse = responseMapper
							.readValue(invoicesServiceResponseString, RetrieveInvoiceInformationResponse.class);
					// validate if service returns SUCCESS or not
					if (StringUtils.equalsIgnoreCase(
							subgroupInvoicesResponse.getResponseHeader().getTransactionNotification().getStatusCode(),
							ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE)) {
						exchange.setProperty(ManagePaymentInfoServiceConstants.IS_RETRIEVE_INVOICES_SUCCESS,
								ManagePaymentInfoServiceConstants.STRING_TRUE);
						// iterate and get the list of subgroupInvoices
						if (null != subgroupInvoicesResponse.getResponseBody()
								&& null != subgroupInvoicesResponse.getResponseBody().getInvoiceInformations()
								&& null != subgroupInvoicesResponse.getResponseBody().getInvoiceInformations()
										.getInvoiceInformation()
								&& !subgroupInvoicesResponse.getResponseBody().getInvoiceInformations()
										.getInvoiceInformation().isEmpty()) {
							PaymentInformation responseInvoiceInfo = new PaymentInformation();
							
							if (StringUtils.isNotBlank(subgroupInvoicesResponse.getResponseBody()
									.getInvoiceInformations().getTotalCount())) {
								
								
								
								List<InvoiceInformation> invoiceInformationList = subgroupInvoicesResponse
										.getResponseBody().getInvoiceInformations().getInvoiceInformation();
								if (null != invoiceInformationList && !invoiceInformationList.isEmpty()) {

									// sort to calculate max generation date
									Collections.sort(invoiceInformationList, new Comparator<InvoiceInformation>() {
										DateFormat f = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");

										@Override
										public int compare(InvoiceInformation o1, InvoiceInformation o2) {
											try {
												return f.parse(o2.getInvoiceGenerationDate())
														.compareTo(f.parse(o1.getInvoiceGenerationDate()));
											} catch (ParseException e) {
												throw new IllegalArgumentException(e);
											}
										}

									});

									InvoiceInformation sortedInvoiceInfoByGenerationDate = invoiceInformationList
											.get(0);
									String invoiceGenerationDate = sortedInvoiceInfoByGenerationDate
											.getInvoiceGenerationDate();
									String invoiceDueDate =sortedInvoiceInfoByGenerationDate.getInvoiceDueDate();
                                   Double sumOfOldInvoice = 0.0;
									for (InvoiceInformation respinvoice : subgroupInvoicesResponse.getResponseBody()
											.getInvoiceInformations().getInvoiceInformation()) {

										if (!(respinvoice.getInvoiceGenerationDate()
												.equals(invoiceGenerationDate)
												&& respinvoice.getInvoiceDueDate()
														.equals(invoiceDueDate))) {
											String billedAmount = respinvoice.getInvoiceBilledAmount();
											String paidAmount = respinvoice.getInvoicePaidAmount();
									
											Double invoiceBilledAmount = Double.valueOf(billedAmount);
											Double invoicePaidAmount = Double.valueOf(paidAmount);
											
											if(null != invoiceBilledAmount && null != invoicePaidAmount){
												Double invoiceDue = invoiceBilledAmount-invoicePaidAmount;
												sumOfOldInvoice = sumOfOldInvoice + invoiceDue;
											
											}
										 
										}
									}
									Double amountDue = 0.0;
									Double previousBal = 0.0;
									if( null != sumOfOldInvoice){
										previousBal = sumOfOldInvoice - Double.valueOf(sortedInvoiceInfoByGenerationDate.getInvoicePaidAmount());
										amountDue = Double.valueOf(sortedInvoiceInfoByGenerationDate.getInvoiceBilledAmount()) + 
												previousBal;
										
									}
							
									responseInvoiceInfo.setCurrentBilledAmount(String.valueOf(sortedInvoiceInfoByGenerationDate.getInvoiceBilledAmount()));
									responseInvoiceInfo.setPreviousBalance(String.valueOf(previousBal));
									responseInvoiceInfo.setAmountDue(String.valueOf(amountDue));
									responseInvoiceInfo.setIsInvoiceExists(ManagePaymentInfoServiceConstants.STRING_TRUE);
								}
							} else {
								responseInvoiceInfo.setCurrentBilledAmount(String.valueOf(0.0));
								responseInvoiceInfo.setPreviousBalance(String.valueOf(0.0));
								responseInvoiceInfo.setAmountDue(String.valueOf(0.0));
								responseInvoiceInfo.setIsInvoiceExists(ManagePaymentInfoServiceConstants.STRING_FALSE);
							}
							
							String paymentNotify = managePaymentInfoServiceWPRDbUtil.obtainPymtNotify((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER));
							
							if( null != paymentNotify && paymentNotify.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_YES)){
								responseInvoiceInfo.setPaymentNotificationIndicator(ManagePaymentInfoServiceConstants.STRING_TRUE);
							} else{
								responseInvoiceInfo.setPaymentNotificationIndicator(ManagePaymentInfoServiceConstants.STRING_FALSE);	
							}
							List<PaymentInformation> PaymentInformationList = new ArrayList<PaymentInformation>();
							PaymentInformationList.add(responseInvoiceInfo);
							responseBody.setPaymentInformations(new PaymentInformations());
							responseBody.getPaymentInformations().setPaymentInformation(PaymentInformationList);
						}
					} else if(!subgroupInvoicesResponse.getResponseHeader().getTransactionNotification().getRemarks()
							.getMessages().isEmpty() && (StringUtils.equalsIgnoreCase(
								subgroupInvoicesResponse.getResponseHeader().getTransactionNotification().getRemarks()
										.getMessages().get(0).getCode(), ManagePaymentInfoServiceConstants.MSG_CODE_INVOICE_INVALID_REQUEST) ||
									StringUtils.equalsIgnoreCase(
											subgroupInvoicesResponse.getResponseHeader().getTransactionNotification().getRemarks()
													.getMessages().get(0).getCode(), ManagePaymentInfoServiceConstants.MSG_CODE_NO_DATA_FOUND) )){

						ManagePaymentInfoServiceUtil.addMessage(messages,
								ManagePaymentInfoServiceConstants.MSG_CODE_NO_DATA_FOUND,
								ManagePaymentInfoServiceConstants.MSG_DATA_NOT_FOUND,
								ManagePaymentInfoServiceConstants.MSG_DATA_NOT_FOUND);

						if (!messages.isEmpty()) {
							response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(
									ManagePaymentInfoServiceConstants.WARNING,
									ManagePaymentInfoServiceConstants.WARNING_STATUS_CODE, response.getResponseHeader(),
									messages));
							messages.clear();
						}
					} else{
						ManagePaymentInfoServiceUtil.addMessage(messages,
								ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
								ManagePaymentInfoServiceConstants.RETRIEVE_INVOICES_SERVICE_FAILED,
								subgroupInvoicesResponse.getResponseHeader().getTransactionNotification().getRemarks()
								.getMessages().get(0).getDescription());
						LOGGER.error(
								transactionId + " - " + METHOD_PROCESS + ManagePaymentInfoServiceConstants.FAILURE);
					}
				}
			} else {
				
				ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
						ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
						ManagePaymentInfoServiceConstants.RETRIEVE_INVOICES_SERVICE_ERROR);
				LOGGER.error(transactionId + " - " + METHOD_PROCESS + ManagePaymentInfoServiceConstants.FAILURE);
			}
		} catch (Exception ex) {

			messages.clear();
			ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
					ManagePaymentInfoServiceConstants.RETRIEVE_INVOICES_SERVICE_ERROR);
			LOGGER.error(transactionId + " - " + METHOD_PROCESS
					+ ManagePaymentInfoServiceConstants.RETRIEVE_INVOICES_SERVICE_ERROR, ex);
		}

		if (!messages.isEmpty()) {
			response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(
					ManagePaymentInfoServiceConstants.FAILURE, ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE,
					response.getResponseHeader(), messages));
		}
       response.setResponseBody(responseBody);
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);

		exchange.getIn().setBody(response);

		LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_EXITING, METHOD_PROCESS);
	}

}
