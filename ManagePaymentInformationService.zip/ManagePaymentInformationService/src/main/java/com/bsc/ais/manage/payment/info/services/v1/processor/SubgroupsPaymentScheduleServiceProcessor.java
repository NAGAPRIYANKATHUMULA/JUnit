/*
 * SubgroupsSetCancelPaymentServiceProcessor.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceDbUtil;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;




/**
 * <HTML> This processor is used for subgroups payment set/cancel.
 * </HTML>.
 *
 * @author Cognizant Technology Solutions.
 * @version 1.0
 * 
 */

@Component()
public class SubgroupsPaymentScheduleServiceProcessor implements Processor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LogManager.getLogger(SubgroupsPaymentScheduleServiceProcessor.class);

	/**
	 * Holds the facets database schema name.
	 */
	private static String FACETS_DB_SCHEMA_NAME = ManagePaymentInfoServiceConstants.STRING_FACETS;
	
	/** The event logging. */
	@Resource(name = "eventLogging")
	private EventLogging eventLogging;
	
	@Resource
	private ManagePaymentInfoServiceDbUtil managePaymentInfoServiceDbUtil;
	
	@Value("${jndi.aisfacets.ro}")
	private String facetsLookUpName;
	
	/**
	 * Holds the method name.
	 */
	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";
	

	/*
	 * (non-Javadoc)
	 * 
	 * This method is used to populate the  parameter name and its value to the response object.
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */

	@SuppressWarnings("unchecked")
	public void process(Exchange exchange) throws Exception {
		
		// Obtain transaction id for logging purpose.
		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_ENTERING + METHOD_PROCESS);
		
		// Obtain the instance of service request
		SubgroupsSetCancelPaymentRequest request = (SubgroupsSetCancelPaymentRequest) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST);
		
		// Obtain an instance of response from exchange object.
		SubgroupsSetCancelPaymentResponse response = (SubgroupsSetCancelPaymentResponse) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
		
		String serviceName = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME);
		
		// Obtain an instance of audit list from exchange object.
		List<AuditEvent> auditEventList = (List<AuditEvent>) exchange.getProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST);
		
		// Create an instance of ArrayList to hold response messages.
		List<Message> messages = new ArrayList<Message>();
		
		// Holds an instance of data source.
		DataSource facetsDataSource = null;
		// Holds an instance of SQL Connection.
		Connection connection = null;
		// Holds an instance of CallableStatement to call stored procedure.
		CallableStatement stmt = null;
		// Holds an instance of ResultSet.
		ArrayList<String> payInfoArrayList = new ArrayList<String>();		
		String requestType = null;
		String activity = null;
		String autoPaymentEffectiveDate = "";
		String groupId = "";
		try {
			// Create an instance of InitialContext 
			final Context context = new InitialContext();
			// Perform JNDI lookup to obtain an instance of data source.
			facetsDataSource = (DataSource) context.lookup(facetsLookUpName);
			// Obtain an instance of SQL connection from data source.
	        connection = facetsDataSource.getConnection();
	        
	        // Holds the response code from stored procedure. This is used to determine if the response from stored procedure is success or failure.
			int storedProcedureResponseCode = 0;
			// Holds the response description from stored procedure.
			String storedProcedureResponseDescription = null;
			// checking whether activity set or cancel
			
			if (ManagePaymentInfoServiceConstants.SET_PYMNT_SCHED_SERVICE.equalsIgnoreCase(serviceName)
					|| ManagePaymentInfoServiceConstants.CANCEL_PYMNT_SCHED_SERVICE.equalsIgnoreCase(serviceName)
					|| ManagePaymentInfoServiceConstants.BATCH_PYMNT_SCHED_SERVICE.equalsIgnoreCase(serviceName)) {
				requestType = ManagePaymentInfoServiceConstants.SCS_REQUEST_TYPE;
				if (ManagePaymentInfoServiceConstants.SET_PYMNT_SCHED_SERVICE.equalsIgnoreCase(serviceName)) {
					activity = ManagePaymentInfoServiceConstants.SET_ACTIVITY_TYPE;
				} else if (ManagePaymentInfoServiceConstants.CANCEL_PYMNT_SCHED_SERVICE.equalsIgnoreCase(serviceName)) {
					activity = ManagePaymentInfoServiceConstants.CANCEL_ACTIVITY_TYPE;
				} else {
					activity = ManagePaymentInfoServiceConstants.BATCH_ACTIVITY_TYPE;
				}
			} 
			
			LOGGER.debug(transactionId + " - "+ METHOD_PROCESS +" - Request Type:"+requestType+", Activity:"+activity);
			//iterate paymentInformation object and obtain request data
			if (!ManagePaymentInfoServiceConstants.BATCH_ACTIVITY_TYPE.equalsIgnoreCase(activity) &&
					request.getRequestBody().getPaymentInformations() != null &&
					!request.getRequestBody().getPaymentInformations().getPaymentInformation().isEmpty()) {
				for(PaymentInformation paymentInformation:request.getRequestBody().getPaymentInformations().getPaymentInformation()) {
					String paymentData = "";
					String accountNumber = "";
					String subgroupId = "";
					String accountHolderName = "";
					String routingNumber = "";
					String bankAccountType = "";
					String accountNickName = "";
					String paymentFlag = "";				
					String restrictedStatus = "";					
					String paymentAmount = "";
					
					/*Checking if the input parameters are null*/
					
					if(null != paymentInformation.getSubgroupIdentifier())
						subgroupId = paymentInformation.getSubgroupIdentifier().trim();
					
					
					if(null != paymentInformation.getAccountNumber())
						accountNumber = paymentInformation.getAccountNumber().trim();
					
					
					if(null != paymentInformation.getAccountHolderName())
						accountHolderName =  paymentInformation.getAccountHolderName().trim();
					
					
					if(null != paymentInformation.getRoutingNumber())
						routingNumber =  paymentInformation.getRoutingNumber().trim();
					
					
					if(null != paymentInformation.getBankAccountType())
						bankAccountType =  paymentInformation.getBankAccountType().trim();
					
					
					if(null != paymentInformation.getAccountNickName())
						accountNickName = paymentInformation.getAccountNickName().trim();
					
					
					if(null != paymentInformation.getPaymentFlag())
						paymentFlag = paymentInformation.getPaymentFlag().trim();
					
					
					if(null != paymentInformation.getPaymentAmount())
						paymentAmount = paymentInformation.getPaymentAmount().trim();
					
					
					if(null != paymentInformation.getGroupIdentifier())
						groupId = paymentInformation.getGroupIdentifier().trim();
					
					
					if(null != paymentInformation.getRestrictedStatus())
						restrictedStatus = paymentInformation.getRestrictedStatus().trim();
					
					if(null != paymentInformation.getAutoPaymentEffectiveDate())
						autoPaymentEffectiveDate = paymentInformation.getAutoPaymentEffectiveDate();
					
					if (ManagePaymentInfoServiceConstants.SCS_REQUEST_TYPE.equalsIgnoreCase(requestType)) {
						if ((!subgroupId.equalsIgnoreCase("") || !groupId.equalsIgnoreCase(""))
								&& !accountNickName.equalsIgnoreCase("")) {
							paymentData = subgroupId + '|' + accountNumber + '|' + accountHolderName + '|'
									+ routingNumber + '|' + bankAccountType + '|' + accountNickName + '|' + paymentFlag;							
						}
					} 					
					payInfoArrayList.add(paymentData);
					
				}
			}
			//adding paymentInfolist data to payInfoArray
			if (null != payInfoArrayList && !payInfoArrayList.isEmpty()) {
				LOGGER.debug(transactionId + " - "+ METHOD_PROCESS +" - Payment Data List preparation is complete:"+ payInfoArrayList.size());
				String[] payInfoArray =  null;
				if (activity.equalsIgnoreCase("BATCH")) {
					payInfoArray =   new String[0];	
				} else {
					payInfoArray = payInfoArrayList.toArray(new String[payInfoArrayList.size()]);
				}
				Timestamp tssLastRunDate = null;				
				if (activity.equalsIgnoreCase("BATCH")) {
					
					SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
					Date dtLastRunDate = dateTimeFormat.parse(request.getRequestBody().getLastRunDate());
					tssLastRunDate = new Timestamp(dtLastRunDate.getTime());
					LOGGER.debug(transactionId + " - "+ METHOD_PROCESS +" - Last Run Date:"+ tssLastRunDate);
				}
			// Call stored procedure to sugroups payment set/cancel
			
			stmt = callSubgroupInfoSp(connection, payInfoArray, requestType, activity,tssLastRunDate, autoPaymentEffectiveDate, groupId);
			
			storedProcedureResponseCode = stmt.getInt(1);
			storedProcedureResponseDescription = stmt.getString(3);
			LOGGER.debug(
						transactionId + " - " + METHOD_PROCESS + " - SP Response Code:" + storedProcedureResponseCode
								+ " - SP Response Description:" + storedProcedureResponseDescription);
			if (storedProcedureResponseCode == 0) {
				response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.SUCCESS,
						ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE, response.getResponseHeader(), messages));
				exchange.setProperty(ManagePaymentInfoServiceConstants.IS_SCHEDULE_SERVICE_SUCCESS, ManagePaymentInfoServiceConstants.STRING_TRUE);
			} else if (storedProcedureResponseCode == 8) {
				ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_INVALID_REQUEST,
						ManagePaymentInfoServiceConstants.MSG_INVALID_REQUEST,
						storedProcedureResponseDescription);
			} else if (storedProcedureResponseCode == 16) {
				ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_INVALID_REQUEST,
						ManagePaymentInfoServiceConstants.MSG_FEASIBILITY_ERROR,
						storedProcedureResponseDescription);
				if (null != storedProcedureResponseDescription && (storedProcedureResponseDescription.startsWith("Warning"))) {
					exchange.setProperty(ManagePaymentInfoServiceConstants.IS_SCHEDULE_SERVICE_SUCCESS, ManagePaymentInfoServiceConstants.STRING_TRUE);
				}
			} else if (storedProcedureResponseCode == 4) {
				ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
						ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
						storedProcedureResponseDescription);
			} else {
				ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_INVALID_REQUEST,
						ManagePaymentInfoServiceConstants.MSG_INVALID_REQUEST,
						storedProcedureResponseDescription);
			}
			
			}
			
			
		}catch (Exception ex) {
			LOGGER.error(transactionId + " - "+ METHOD_PROCESS , ex);
			ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);
			
			//audit logging
			ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.GET_SCHEDULE_EVENT_FAILURE_CODE);
		}
		if (!messages.isEmpty()) {
			for (Message message: messages) {
				if (message.getCode().startsWith("6")){
					response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.WARNING,
							ManagePaymentInfoServiceConstants.WARNING_STATUS_CODE, response.getResponseHeader(), messages));
				} else {
					response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE,
							ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, response.getResponseHeader(), messages));
				}
			}			
			messages.clear();
		}
		
		
		//set the response to exchange object
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
		exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
		response.setResponseBody(null);
		exchange.getIn().setBody(response);
		
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_EXITING + METHOD_PROCESS);
	}
	/**
	 * This method calls facets stored procedure to obtain subgroup plan information.
	 *  
	 * @param connection Holds an instance of Connection
	 * @param payInfoArray
	 * @param requestType
	 * @param activity
	 * @param autoPaymentEffectiveDate
	 * @param groupId
	 * @return
	 * @throws SQLException
	 */
	private CallableStatement callSubgroupInfoSp(Connection connection, String[] payInfoArray, String requestType,
			String activity, Timestamp lastRunDate, String autoPaymentEffectiveDate, String groupId) throws SQLException, Exception {

		// Unwrap an instance of SQLConnection to obtain raw JDBC connection.
		// This is required for creating custom array object.
		final OracleConnection oracleConn = connection.unwrap(oracle.jdbc.OracleConnection.class);

		ArrayDescriptor arrDesc = ArrayDescriptor.createDescriptor(FACETS_DB_SCHEMA_NAME + ".BSCUDT_STRING_ARRAY",
				oracleConn);
		ARRAY payInfo = new ARRAY(arrDesc, oracleConn, payInfoArray);
		

		CallableStatement stmt = (CallableStatement) connection
				.prepareCall("{? = call " + FACETS_DB_SCHEMA_NAME + ".bscf_setcncl_schd_for_subgrp(?,?,?,?,?,?,?,?)}");
		
		stmt.registerOutParameter(1, OracleTypes.NUMBER);
		stmt.registerOutParameter(2, OracleTypes.NUMBER);
		stmt.registerOutParameter(3, OracleTypes.VARCHAR);
		stmt.setString(4, requestType);
		stmt.setString(5, activity);
		stmt.setArray(6, payInfo);
		stmt.setTimestamp(7, lastRunDate);
		stmt.setString(8, autoPaymentEffectiveDate);
		stmt.setString(9, groupId);		
		stmt.execute();
		return stmt;
	}
	
}
