/*
 * SetCancelBankAccInfoDataProcessor.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceDbUtil;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;

import oracle.jdbc.OracleTypes;

/**
 * <HTML> This processor is used for subgroups payment set/cancel. </HTML>.
 *
 * @author Cognizant Technology Solutions.
 * @version 1.0
 * 
 */

@Component()
public class SetCancelBankAccInfoDataProcessor implements Processor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LogManager.getLogger(SetCancelBankAccInfoDataProcessor.class);

	/**
	 * Holds the facets database schema name.
	 */
	private static String FACETS_DB_SCHEMA_NAME = ManagePaymentInfoServiceConstants.STRING_FACETS;

	/** The event logging. */
	@Resource(name = "eventLogging")
	private EventLogging eventLogging;

	@Resource
	private ManagePaymentInfoServiceDbUtil managePaymentInfoServiceDbUtil;

	@Value("${jndi.aisfacets.ro}")
	private String facetsLookUpName;

	/**
	 * Holds the method name.
	 */
	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";

	/*
	 * (non-Javadoc)
	 * 
	 * This method is used to populate the parameter name and its value to the
	 * response object.
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	@SuppressWarnings({ "unchecked" })
	public void process(Exchange exchange) throws Exception {

		// Obtain transaction id for logging purpose.
		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_ENTERING + METHOD_PROCESS);

		// Obtain the instance of service request
		SubgroupsSetCancelPaymentRequest request = (SubgroupsSetCancelPaymentRequest) exchange
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST);

		// Obtain an instance of response from exchange object.
		SubgroupsSetCancelPaymentResponse response = (SubgroupsSetCancelPaymentResponse) exchange
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);

		// Obtain an instance of audit list from exchange object.
		List<AuditEvent> auditEventList = (List<AuditEvent>) exchange
				.getProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST);
		
		// Create an instance of ArrayList to hold response messages.
		List<Message> messages = new ArrayList<Message>();

		// Holds an instance of data source.
		DataSource facetsDataSource = null;
		// Holds an instance of SQL Connection.
		Connection connection = null;
		// Holds an instance of CallableStatement to call stored procedure.
		CallableStatement stmt = null;
		// Holds an instance of ResultSet.
		ArrayList<String> payInfoArrayList = new ArrayList<String>();
		String activity = null;
		try {
			// Create an instance of InitialContext
			final Context context = new InitialContext();
			
			LOGGER.debug(transactionId + " - " + METHOD_PROCESS + " getting facets db connection");
			// Perform JNDI lookup to obtain an instance of data source.
			facetsDataSource = (DataSource) context.lookup(facetsLookUpName);
			// Obtain an instance of SQL connection from data source.
			connection = facetsDataSource.getConnection();

			// Holds the response code from stored procedure. This is used to
			// determine if the response from stored procedure is success or
			// failure.
			int storedProcedureResponseCode = 0;
			// Holds the response description from stored procedure.
			String storedProcedureResponseDescription = null;
			
			String serviceName = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME);
			// checking whether activity set or cancel
			if (serviceName
					.equals(ManagePaymentInfoServiceConstants.SUBGROUPS_BANK_ACCOUNT_INFO_SET_SERVICE) ||
					serviceName.equals(ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_SET_SERVICE)) {
				LOGGER.debug(transactionId + " - " + METHOD_PROCESS + "set activity");
				activity = ManagePaymentInfoServiceConstants.STRING_SET;
			} else if (serviceName
					.equals(ManagePaymentInfoServiceConstants.SUBGROUPS_BANK_ACCOUNT_INFO_CANCEL_SERVICE) ||
					serviceName.equals(ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_CANCEL_SERVICE)) {
				activity = ManagePaymentInfoServiceConstants.STRING_CANCEL;
				LOGGER.debug(transactionId + " - " + METHOD_PROCESS + "cancel activity");
			}
			
			if (serviceName
					.equals(ManagePaymentInfoServiceConstants.MANAGE_ONE_TIME_PYMT_SET)) {
				if(StringUtils.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_TRUE,
						(String)exchange.getProperty(ManagePaymentInfoServiceConstants.CANCEL_BANK_ACC))){
					activity = ManagePaymentInfoServiceConstants.STRING_CANCEL;
					LOGGER.debug(transactionId + " - " + METHOD_PROCESS + "cancel activity");
				} else{
				LOGGER.debug(transactionId + " - " + METHOD_PROCESS + "set activity");
				activity = ManagePaymentInfoServiceConstants.STRING_SET;
				}
				
			}
			
			
			// iterate paymentInformation object and obtain request data
			if (request.getRequestBody().getPaymentInformations() != null
					&& !request.getRequestBody().getPaymentInformations().getPaymentInformation().isEmpty()) {
				LOGGER.debug(transactionId + " - " + METHOD_PROCESS
						+ " obtain request data from payment information object");
				PaymentInformation paymentInformation = request.getRequestBody().getPaymentInformations()
						.getPaymentInformation().get(0);
				String accountNumber = "";
				String groupId = "";
				String accountHolderName = "";
				String routingNumber = "";
				String bankAccountType = "";
				String accountNickName = "";
				String restrictedStatus = "";
				String paymentData = "";

				if (null != paymentInformation.getAccountNumber()) {
					accountNumber = paymentInformation.getAccountNumber();
				}
				if (null != paymentInformation.getAccountHolderName()) {
					accountHolderName = paymentInformation.getAccountHolderName();
				}
				if (null != paymentInformation.getRoutingNumber()) {
					routingNumber = paymentInformation.getRoutingNumber();
				}
				if (null != paymentInformation.getBankAccountType()) {
					bankAccountType = paymentInformation.getBankAccountType();
				}
				if (null != paymentInformation.getAccountNickName()) {
					accountNickName = paymentInformation.getAccountNickName();
				}
				if (null != paymentInformation.getGroupIdentifier()) {
					groupId = paymentInformation.getGroupIdentifier();
				}
				if (null != paymentInformation.getAccountNickName()) {
					accountNickName = paymentInformation.getAccountNickName();
				}
				if (null != paymentInformation.getRestrictedStatus()) {
					restrictedStatus = paymentInformation.getRestrictedStatus();
				}

				if (restrictedStatus.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_TRUE)) {
					restrictedStatus = ManagePaymentInfoServiceConstants.STRING_YES;
				} else if (restrictedStatus.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_FALSE)) {
					restrictedStatus = ManagePaymentInfoServiceConstants.STRING_NO;
				}
				
				
				if(serviceName.equals(ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_SET_SERVICE)){
					restrictedStatus = ManagePaymentInfoServiceConstants.STRING_NO;
				}

				// checking account type valid or not
				boolean isValidAcctType = true;
				if (!bankAccountType.equalsIgnoreCase("")
						&& !bankAccountType.equalsIgnoreCase(ManagePaymentInfoServiceConstants.SAVINGS)
						&& !bankAccountType.equalsIgnoreCase(ManagePaymentInfoServiceConstants.CHECKING)) {
					LOGGER.debug(transactionId + " - " + METHOD_PROCESS + "validating bank account type ");
					isValidAcctType = false;
				}

				// checking service request for set or not
				if (activity.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_SET)) {
					if (isValidAcctType && !bankAccountType.equalsIgnoreCase("")) {
						if (restrictedStatus.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_YES)) {
							if (!accountNumber.equalsIgnoreCase("") && !accountHolderName.equalsIgnoreCase("")
									&& !routingNumber.equalsIgnoreCase("") && !groupId.equalsIgnoreCase("")) {
								paymentData = accountNumber + '|' + accountHolderName + '|' + routingNumber + '|'
										+ bankAccountType + '|' + accountNickName + '|' + groupId + '|'
										+ restrictedStatus;
								payInfoArrayList.add(paymentData);
							}
						} else if (restrictedStatus.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_NO)) {
							if (!accountNumber.equalsIgnoreCase("") && !accountHolderName.equalsIgnoreCase("")
									&& !routingNumber.equalsIgnoreCase("") && !groupId.equalsIgnoreCase("")
									&& !accountNickName.equalsIgnoreCase("")) {
								paymentData = accountNumber + '|' + accountHolderName + '|' + routingNumber + '|'
										+ bankAccountType + '|' + accountNickName + '|' + groupId + '|'
										+ restrictedStatus;
								payInfoArrayList.add(paymentData);
							}
						}
					}
				} else if (activity.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_CANCEL)) {

					if (!groupId.equalsIgnoreCase("") && !accountNickName.equalsIgnoreCase("") && isValidAcctType) {
						paymentData = accountNumber + '|' + accountHolderName + '|' + routingNumber + '|'
								+ bankAccountType + '|' + accountNickName + '|' + groupId + '|' + restrictedStatus;
						payInfoArrayList.add(paymentData);
					}
				}
				LOGGER.debug(transactionId + " - " + METHOD_PROCESS + " - Call Stored Procedure  ");
				// Call stored procedure to groups bank account info set/cancel
				stmt = callSubgroupsBankAccInfoSetCancelSp(connection, activity, groupId, accountNumber,
						accountHolderName, routingNumber, bankAccountType, accountNickName, restrictedStatus);

				storedProcedureResponseCode = stmt.getInt(1);
				LOGGER.debug(transactionId + " - " + METHOD_PROCESS + " Response code from stored procedure is: "
						+ storedProcedureResponseCode);
				storedProcedureResponseDescription = stmt.getString(3);
				LOGGER.debug(transactionId + " - " + METHOD_PROCESS + " Response Description from stored procedure is: "
						+ storedProcedureResponseDescription);

				if (storedProcedureResponseCode == 0) {
					response.setResponseHeader(
							ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.SUCCESS,
									ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE, response.getResponseHeader(),
									messages));
					exchange.setProperty(ManagePaymentInfoServiceConstants.SET_BANK_ACC_RESPONSE_SUCCESS,ManagePaymentInfoServiceConstants.STRING_TRUE);
				} else if (storedProcedureResponseCode == 8) {
					ManagePaymentInfoServiceUtil.addMessage(messages,
							ManagePaymentInfoServiceConstants.MSG_CODE_INVALID_REQUEST,
							ManagePaymentInfoServiceConstants.MSG_INVALID_REQUEST, storedProcedureResponseDescription);
				} else if (storedProcedureResponseCode == 4) {
					ManagePaymentInfoServiceUtil.addMessage(messages,
							ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
							ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
							ManagePaymentInfoServiceConstants.MSG_DESC_PAYMENT_SET_TECH_ERROR);
				}  else {
					ManagePaymentInfoServiceUtil.addMessage(messages,
							ManagePaymentInfoServiceConstants.MSG_CODE_INVALID_REQUEST,
							ManagePaymentInfoServiceConstants.MSG_FEASIBILITY_ERROR, storedProcedureResponseDescription);
				}

			}

		} catch (Exception ex) {
			LOGGER.error(transactionId + " - " + METHOD_PROCESS, ex);
			ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR, ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);
			LOGGER.debug(transactionId + " - " + METHOD_PROCESS + " audit logging");
			// audit logging
			ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,
					ManagePaymentInfoServiceConstants.GET_SCHEDULE_EVENT_FAILURE_CODE);
		}
		if (!messages.isEmpty()) {
			for (Message message : messages) {
				if (message.getCode().startsWith("6")) {
					response.setResponseHeader(
							ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.WARNING,
									ManagePaymentInfoServiceConstants.WARNING_STATUS_CODE, response.getResponseHeader(),
									messages));
				} else {
					response.setResponseHeader(
							ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE,
									ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, response.getResponseHeader(),
									messages));
				}
			}
			messages.clear();
		}

		// set the response to exchange object
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
		exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
		response.setResponseBody(null);
		exchange.getIn().setBody(response);

		LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_EXITING + METHOD_PROCESS);
	}

	/**
	 * This method calls facets stored procedure to obtain subgroup plan
	 * information.
	 * 
	 * @param connection
	 *            - Holds an instance of Connection
	 * @param payInfoArray
	 *            - Holds array of paymentInfo passed in request.
	 * @param requestType
	 *            - Holds the request type.
	 * @param activity
	 *            - Holds the activity.
	 * @return - Instance of CallableStatement with result from stored procedure
	 *         call.
	 * @throws SQLException
	 */
	private CallableStatement callSubgroupsBankAccInfoSetCancelSp(Connection connection, String activity,
			String groupId, String accountNumber, String accountHolderName, String routingNumber,
			String bankAccountType, String accountNickName, String restrictedStatus) throws SQLException {

		CallableStatement stmt = (CallableStatement) connection.prepareCall(
				"{? = call " + FACETS_DB_SCHEMA_NAME + ".bscf_setcncl_bank_for_subgrp(?,?,?,?,?,?,?,?,?,?)}");

		stmt.registerOutParameter(1, OracleTypes.NUMBER);
		stmt.registerOutParameter(2, OracleTypes.NUMBER);
		stmt.registerOutParameter(3, OracleTypes.VARCHAR);
		stmt.setString(4, activity);
		stmt.setString(5, groupId);
		stmt.setString(6, accountNumber);
		stmt.setString(7, accountHolderName);
		stmt.setString(8, routingNumber);
		stmt.setString(9, bankAccountType);
		stmt.setString(10, accountNickName);
		stmt.setString(11, restrictedStatus);

		stmt.execute();

		return stmt;
	}

}
