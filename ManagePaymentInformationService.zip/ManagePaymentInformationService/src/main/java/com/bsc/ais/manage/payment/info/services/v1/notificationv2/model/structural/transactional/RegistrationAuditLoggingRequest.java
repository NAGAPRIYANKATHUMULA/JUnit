package com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional;

import com.bsc.aip.core.model.common.composite.RequestHeader;

public class RegistrationAuditLoggingRequest {
	
	private RequestHeader requestHeader;
	
	private RegistrationAuditLoggingRequestBody requestBody;

	/**
	 * @return the requestHeader
	 */
	public RequestHeader getRequestHeader() {
		return requestHeader;
	}

	/**
	 * @param requestHeader the requestHeader to set
	 */
	public void setRequestHeader(RequestHeader requestHeader) {
		this.requestHeader = requestHeader;
	}

	/**
	 * @return the requestBody
	 */
	public RegistrationAuditLoggingRequestBody getRequestBody() {
		return requestBody;
	}

	/**
	 * @param requestBody the requestBody to set
	 */
	public void setRequestBody(RegistrationAuditLoggingRequestBody requestBody) {
		this.requestBody = requestBody;
	}
	

}
