/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.model.response.invoices;

import java.util.List;

/**
 * @author Cognizant
 *
 */
public class InvoiceInformations {
	
	private List<InvoiceInformation> invoiceInformation;
	private String totalCount;

	/**
	 * @return the invoiceInformation
	 */
	public List<InvoiceInformation> getInvoiceInformation() {
		return invoiceInformation;
	}

	/**
	 * @param invoiceInformation the invoiceInformation to set
	 */
	public void setInvoiceInformation(List<InvoiceInformation> invoiceInformation) {
		this.invoiceInformation = invoiceInformation;
	}

	/**
	 * @return the totalCount
	 */
	public String getTotalCount() {
		return totalCount;
	}

	/**
	 * @param totalCount the totalCount to set
	 */
	public void setTotalCount(String totalCount) {
		this.totalCount = totalCount;
	}

	

	

}
