/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceDBConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupIdentifier;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupSubgroup;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformations;
import com.bsc.ais.manage.payment.info.services.v1.model.response.RetrievePaymentInfoResponseBody;
import com.bsc.ais.manage.payment.info.services.v1.model.response.SubgroupsSetCancelPaymentResponseBody;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceDbUtil;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceWPRDbUtil;

/**
 * @author Cognizant
 *
 */
@Component("manageBankAccCancelDataProcessor")
public class ManageBankAccCancelDataProcessor implements Processor {

	private static final Logger LOGGER = LogManager.getLogger(ManageBankAccCancelDataProcessor.class);

	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";

	@Resource
	private ManagePaymentInfoServiceWPRDbUtil managePaymentInfoServiceWPRDbUtil;

	@Resource
	private ManagePaymentInfoServiceDbUtil managePaymentInfoServiceDbUtil;

	@Resource
	private EventLogging eventLogging;

	@Override
	public void process(Exchange exchange) throws Exception {

		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);

		LOGGER.debug(ManagePaymentInfoServiceConstants.METHOD_ENTERING, transactionId, METHOD_PROCESS);
		// Holds list of response messages
		List<Message> message = new ArrayList<Message>();

		// Obtain the instance of service request
		SubgroupsSetCancelPaymentRequest request = (SubgroupsSetCancelPaymentRequest) exchange
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST);
		// Obtain an instance of response from exchange object.
		SubgroupsSetCancelPaymentResponse response = (SubgroupsSetCancelPaymentResponse) exchange
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
		// Obtain an instance of audit list from exchange object.
		@SuppressWarnings("unchecked")
		List<AuditEvent> auditEventList = (List<AuditEvent>) exchange
				.getProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST);

		// Holds list of response messages
		List<Message> messages = new ArrayList<Message>();

		try {

			final List<Map<String, Object>> subgrpsRows = managePaymentInfoServiceWPRDbUtil.obtainAllSubgrps(
					(String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_GROUP_IDENTIIFER));
			List<PaymentInformation> paymentInformationList = new ArrayList<PaymentInformation>();
			if (null != subgrpsRows && subgrpsRows.size() > 0) {
				String groupId = null;
				String subGroupId = null;
				String subGroupIdentifier = null;
				List<String> sgsgIdList = new ArrayList<String>();
				List<String> subGroupIdentifierList = new ArrayList<String>();
				Map<String, List<String>> groupInfoMap = new HashMap<String, List<String>>();

				for (Map<String, Object> row : subgrpsRows) {
					groupId = ((String) row.get("GRP_BLG_UNIT_NUM")).substring(0, 8);
					subGroupId = ((String) row.get("GRP_BLG_UNIT_NUM")).substring(8, 12);
					if (groupInfoMap.containsKey(groupId)) {
						sgsgIdList = groupInfoMap.get(groupId);
						sgsgIdList.add(subGroupId);
					} else {
						sgsgIdList = new ArrayList<String>();
						sgsgIdList.add(subGroupId);
						groupInfoMap.put(groupId, sgsgIdList);
					}
					subGroupIdentifier = ((String) row.get("GRP_BLG_UNIT_NUM"));
					subGroupIdentifierList.add(subGroupIdentifier);
				}
		

				// get the count of valid SubGroupIdentifier present in FACETS
				// database
				int count = managePaymentInfoServiceDbUtil.validateSubGroupIdentifierCount(groupInfoMap);

				if (count > 0) {
					// get the payment information
					List<Map<String, Object>> paymentRows = managePaymentInfoServiceDbUtil
							.paymentInfoForGetSchedule(groupInfoMap);

					if (null != paymentRows && !paymentRows.isEmpty()) {
						// iterate and populate the payment Information List
						for (Map<String, Object> row : paymentRows) {

							// create a instance of PaymentInformation object
							PaymentInformation paymentInformation = new PaymentInformation();
							paymentInformation
									.setAccountNumber((String) row.get(ManagePaymentInfoServiceDBConstants.ACC_NUMBER));
							paymentInformation.setSubgroupIdentifier(
									(String) row.get(ManagePaymentInfoServiceDBConstants.SUB_GROUP_IDEN));
							paymentInformation.setSubgroupName(
									(String) row.get(ManagePaymentInfoServiceDBConstants.SUB_GROUP_NAME));
							// add to paymentInformationList only if
							// SubgroupIdentifier matches is valid and passed in
							// request
							if (subGroupIdentifierList.contains(paymentInformation.getSubgroupIdentifier())
									&& StringUtils.equalsIgnoreCase(
											request.getRequestBody().getPaymentInformations().getPaymentInformation()
													.get(0).getAccountNickName(),
											(String) row.get(ManagePaymentInfoServiceDBConstants.ACC_NICK_NAME))) {
								paymentInformationList.add(paymentInformation);
							}
						}
					} 

				} 
			}
				if (!paymentInformationList.isEmpty()) {
					List<PaymentInformation> autoPayInfo = new ArrayList<PaymentInformation>();
					@SuppressWarnings("unchecked")
					final List<Map<String, Object>> subGrpFeaturedRows = managePaymentInfoServiceWPRDbUtil
							.obtainSubgrpsFeatures(
									(String) exchange
											.getProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER),
									(String) exchange
											.getProperty(ManagePaymentInfoServiceConstants.EXC_GROUP_IDENTIIFER));
					for (PaymentInformation payment : paymentInformationList) {
						for (Map<String, Object> subgrp : subGrpFeaturedRows) {
							if (!(payment.getSubgroupIdentifier()
									.equals(subgrp.get(ManagePaymentInfoServiceDBConstants.GRP_BLG_UNIT_NUM)))) {

								PaymentInformation paymentInformation = new PaymentInformation();
								paymentInformation.setAccountNumber(payment.getAccountNumber());
								paymentInformation.setSubgroupIdentifier(payment.getSubgroupIdentifier());
								paymentInformation.setSubgroupName(payment.getSubgroupName());
								autoPayInfo.add(paymentInformation);
							}
						}
					}

					if (!autoPayInfo.isEmpty()) {
						ManagePaymentInfoServiceUtil.addMessage(messages,
								ManagePaymentInfoServiceConstants.MSG_CODE_ACCESS_INVALID,
								ManagePaymentInfoServiceConstants.MSG_DESC_SUBGROUP_ACCESS_INVALID,
								ManagePaymentInfoServiceConstants.MSG_DESC_SUBGROUP_ACCESS_INVALID);
					} else{
						List<PaymentInformation> respPaymentList = new ArrayList<PaymentInformation>();
						for (PaymentInformation payment : paymentInformationList) {
							PaymentInformation paymentInformation = new PaymentInformation();
							paymentInformation.setSubgroupIdentifier(payment.getSubgroupIdentifier());
							paymentInformation.setSubgroupName(payment.getSubgroupName());
							respPaymentList.add(paymentInformation);
						}
						PaymentInformations paymentInformations = new PaymentInformations();
						paymentInformations.setPaymentInformation(paymentInformationList);
						SubgroupsSetCancelPaymentResponseBody responseBody = new SubgroupsSetCancelPaymentResponseBody();
						responseBody.setPaymentInformations(paymentInformations);
						responseBody.setIsAutoPymntScheduled(ManagePaymentInfoServiceConstants.STRING_TRUE);
						response.setResponseBody(responseBody);
					}
					if (!messages.isEmpty()) {
						response.setResponseHeader(
								ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.WARNING,
										ManagePaymentInfoServiceConstants.WARNING_STATUS_CODE,
										response.getResponseHeader(), messages));
						messages.clear();
					}
                  exchange.setProperty(ManagePaymentInfoServiceConstants.IS_SCHEDULE_AVAIL, ManagePaymentInfoServiceConstants.STRING_TRUE);
				} else {
				  exchange.setProperty(ManagePaymentInfoServiceConstants.IS_SCHEDULE_AVAIL, ManagePaymentInfoServiceConstants.STRING_FALSE);
				}

			

		} catch (Exception ex) {

			ManagePaymentInfoServiceUtil.addMessage(message, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR, ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);
			LOGGER.error(transactionId + " - " + METHOD_PROCESS + ex);
			ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,
					ManagePaymentInfoServiceConstants.SET_BANK_ACC_EVENT_FAILURE_CODE);
		}
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
		exchange.getIn().setBody(response);

		LOGGER.debug(ManagePaymentInfoServiceConstants.METHOD_EXITING, transactionId, METHOD_PROCESS);
	}

}
