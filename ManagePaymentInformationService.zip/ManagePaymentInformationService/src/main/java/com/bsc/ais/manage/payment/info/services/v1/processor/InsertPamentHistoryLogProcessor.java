/*
 * GetScheduleDataProcessor.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceWPRDbUtil;




/**
 * <HTML> This processor is used to get the payment informations from FACETS database
 * </HTML>.
 *
 * @author Cognizant Technology Solutions.
 * @version 1.0
 * 
 */

@Component()
public class InsertPamentHistoryLogProcessor implements Processor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LogManager.getLogger(InsertPamentHistoryLogProcessor.class);

	/** The event logging. */
	@Resource(name = "eventLogging")
	private EventLogging eventLogging;
	
	@Resource
	ManagePaymentInfoServiceWPRDbUtil managePaymentInfoServiceWPRDbUtil;
	
	/**
	 * Holds the method name.
	 */
	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";
	

	/*
	 * (non-Javadoc)
	 * 
	 * This method is used to populate the  parameter name and its value to the response object.
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	public void process(Exchange exchange) throws Exception {
		
		// Obtain transaction id for logging purpose.
		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_ENTERING + METHOD_PROCESS);
		
		// Obtain the instance of service request
		SubgroupsSetCancelPaymentRequest request = (SubgroupsSetCancelPaymentRequest) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST);
		// Obtain the instance of service response
		SubgroupsSetCancelPaymentResponse response = (SubgroupsSetCancelPaymentResponse) exchange
					.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
				
		try {
			//fetching required data from requested data 
			String userId = null;
			String accountName = null;
			String accountNumber = null;
			String subgroupId = null;
			String accountNickName = null;
			userId = request.getRequestBody().getUserIdentifier();
			if (ManagePaymentInfoServiceConstants.CREATE_AUTOPAYMENT_SERVICENAME.equals((String)exchange.getProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME))) {
				accountName = "Create";
			} else {
				accountName = "Cancel";
			}
			if (null != request.getRequestBody().getPaymentInformations()
					&& !request.getRequestBody().getPaymentInformations().getPaymentInformation().isEmpty()) {
				for (PaymentInformation paymentInformation : request.getRequestBody().getPaymentInformations()
						.getPaymentInformation()) {
					subgroupId = paymentInformation.getSubgroupIdentifier();
					accountNickName = paymentInformation.getAccountNickName();
				}
			}
			LOGGER.debug(METHOD_PROCESS + " Inserting data in PAYMENT_HISTORY_LOG table "+ transactionId);
			managePaymentInfoServiceWPRDbUtil.insertIntoEmpGroupAdminUserHist(userId, accountName, accountNumber, subgroupId, accountNickName);
			
		}catch (Exception ex) {
			LOGGER.error(transactionId + " - "+ METHOD_PROCESS , ex);	
			LOGGER.debug(METHOD_PROCESS + " exception came while inserting data in PAYMENT_HISTORY_LOG table "+ transactionId);
		}
		
		//set the response to exchange object
		response.setResponseBody(null);
		exchange.getIn().setBody(response);
		
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_EXITING + METHOD_PROCESS);
	}
	
}
