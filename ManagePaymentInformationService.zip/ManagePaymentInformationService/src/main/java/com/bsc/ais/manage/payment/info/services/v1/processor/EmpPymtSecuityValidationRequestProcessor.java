package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.aip.core.model.common.composite.ResponseHeader;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.openidconnect.ManageOpenIdConnectEmployersRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.request.openidconnect.RequestBody;
import com.bsc.ais.manage.payment.info.services.v1.model.response.openidconnect.CommonResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsHistoryResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class EmpPymtSecuityValidationRequestProcessor implements Processor {
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LogManager.getLogger(EmpPymtSecuityValidationRequestProcessor.class);

	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";

	@Value("${managepayment.security.groupsubgroup.api.uri}")
	private String getGroupSubGroupUri;

	@Value("${managepayment.manageopenidconnect.aip.header.x-ibm-client-id}")
	private  String xClientId;

	@Value("${managepayment.manageopenidconnect.aip.header.x-ibm-client-secret}")
	private  String xClientSecret;

	private static RestTemplate restTemplate = new RestTemplate();

	@Override
	public void process(Exchange exchange) throws Exception {

		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_ENTERING +  METHOD_PROCESS);
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS, ManagePaymentInfoServiceConstants.STRING_FALSE);
		exchange.setProperty(ManagePaymentInfoServiceConstants.SECURITY_GROUP_VALIDATION, ManagePaymentInfoServiceConstants.STRING_FALSE);
		ResponseHeader responseHeader = (ResponseHeader) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESP_HEADER);
		String serviceName = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME);
		String autoPymtServiceName = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME);
		List<Message> messages = new ArrayList<Message>();
		try {
			RequestHeader requestHeader = (RequestHeader) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQ_HEADER);
			if (requestHeader.getCredentials() != null && StringUtils.equals(requestHeader.getCredentials().getType(), ManagePaymentInfoServiceConstants.ID_TOKEN)) {
				
				HttpHeaders httpHeaders = new HttpHeaders();
				httpHeaders.setContentType(MediaType.APPLICATION_JSON);
				httpHeaders.set(ManagePaymentInfoServiceConstants.XCLIENTID, xClientId);
				httpHeaders.set(ManagePaymentInfoServiceConstants.XCLIENTSECRET, xClientSecret);
				
				String accessToken = (String)exchange.getIn().getHeader(ManagePaymentInfoServiceConstants.XBSCAPIAUTH);
				ObjectMapper requestMapper = new ObjectMapper();
				ManageOpenIdConnectEmployersRequest requestIdToken = new ManageOpenIdConnectEmployersRequest();
				requestIdToken.setRequestHeader(requestHeader);
				requestIdToken.getRequestHeader().getConsumer().setId(ManagePaymentInfoServiceConstants.EMPLOYER_BUSSINESS_UNIT);
				requestIdToken.setRequestBody(new RequestBody());
				requestIdToken.getRequestBody().setAccess_token(accessToken);
				requestIdToken.getRequestBody().setRefresh_token((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_REFRESH_TOKEN));
				requestIdToken.getRequestBody().setId_token((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_ID_TOKEN));
				requestIdToken.getRequestBody().setUserIdentifier(((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER)).trim().toUpperCase());
				HttpEntity<String> requestEntity = new HttpEntity<String>(requestMapper.writeValueAsString(requestIdToken), httpHeaders);

				ResponseEntity<String> responseEntity = restTemplate.exchange(getGroupSubGroupUri, HttpMethod.POST,	requestEntity, String.class);
				if ((null != responseEntity) && (null != responseEntity.getBody())) {
					ObjectMapper responseMapper = new ObjectMapper();
					CommonResponse idTokenResponse = responseMapper.readValue(responseEntity.getBody(),	CommonResponse.class);
					if ((null != responseEntity.getStatusCode()) && (responseEntity.getStatusCode().is2xxSuccessful()) && (null != idTokenResponse.getResponseBody())) {
						exchange.setProperty(ManagePaymentInfoServiceConstants.OPENID_CONNECT_GROUP_RESPONSE, idTokenResponse.getResponseBody());
						exchange.setProperty(ManagePaymentInfoServiceConstants.SECURITY_GROUP_VALIDATION, ManagePaymentInfoServiceConstants.STRING_TRUE);
					} else {
						exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS, ManagePaymentInfoServiceConstants.STRING_FALSE);
						ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.WARNING_INVALID_TOKEN_ERROR_CODE,
								ManagePaymentInfoServiceConstants.MSG_SECURITY_VALID, ManagePaymentInfoServiceConstants.MSG_INVALID_TOKEN_ERROR);
						ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.WARNING,
								ManagePaymentInfoServiceConstants.WARNING_STATUS_CODE, responseHeader, messages);
					}
				}
			} else {
				exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS, ManagePaymentInfoServiceConstants.STRING_FALSE);
				ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_FORBIDDEN,
						ManagePaymentInfoServiceConstants.MSG_FORBIDDEN, ManagePaymentInfoServiceConstants.MSG_ID_TOKEN_ERROR);
				ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE,
						ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, responseHeader, messages);
			}
		} catch (Exception ex) {
			LOGGER.error(METHOD_PROCESS + ManagePaymentInfoServiceConstants.MSG_TECH_ERROR + transactionId + " - " ,ex);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS, ManagePaymentInfoServiceConstants.STRING_FALSE);
			ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR, ManagePaymentInfoServiceConstants.MSG_GROUPS_ERROR_SECURITY);
			ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE,
					ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, responseHeader, messages);
		}
		

		if(StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.GET_SCHEDULE_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.RETRIEVE_BANK_ACC_INFO_SERVICE)){
			RetrievePaymentInfoResponse response = (RetrievePaymentInfoResponse) exchange
					.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);	
		} else if(StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SET_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_CANCEL_SERVICE)||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.SET_PYMNT_SCHED_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.CANCEL_PYMNT_SCHED_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.BATCH_PYMNT_SCHED_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.SUBGROUPS_BANK_ACCOUNT_INFO_SET_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.SUBGROUPS_BANK_ACCOUNT_INFO_CANCEL_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_SET_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_CANCEL_SERVICE) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.MANAGE_ONE_TIME_PYMT_SET) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.MANAGE_ONE_TIME_PYMT_CANCEL) ||
				StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.ONE_TIME_PAYMENT_GET_SERVICE)){
			SubgroupsSetCancelPaymentResponse response = (SubgroupsSetCancelPaymentResponse) exchange
					.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);	
		} else if(StringUtils.equalsIgnoreCase(autoPymtServiceName, ManagePaymentInfoServiceConstants.CREATE_AUTOPAYMENT_SERVICENAME) ||
				StringUtils.equalsIgnoreCase(autoPymtServiceName, ManagePaymentInfoServiceConstants.CANCEL_AUTOPAYMENT_SERVICENAME)){
			SubgroupsSetCancelPaymentResponse response = (SubgroupsSetCancelPaymentResponse) exchange
					.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);	
		} else if(StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.RETRIEVE_AUTOPAYMENTS_GROUPS_SERVICE) ){
			RetrieveAutoPaymentsResponse response = (RetrieveAutoPaymentsResponse) exchange
					.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);	
		} else if(StringUtils.equalsIgnoreCase(serviceName, ManagePaymentInfoServiceConstants.RETRIEVE_AUTOPAYMENTS_HISTORY_SERVICE) ){
			RetrieveAutoPaymentsHistoryResponse response = (RetrieveAutoPaymentsHistoryResponse) exchange
					.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);	
		}
		
		
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_EXITING, METHOD_PROCESS);
	}

}
