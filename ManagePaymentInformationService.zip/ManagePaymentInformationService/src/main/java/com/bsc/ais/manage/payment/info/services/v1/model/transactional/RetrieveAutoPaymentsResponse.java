package com.bsc.ais.manage.payment.info.services.v1.model.transactional;

import com.bsc.aip.core.model.common.composite.ResponseHeader;
import com.bsc.ais.manage.payment.info.services.v1.model.response.RetrieveAutoPaymentsResponseBody;

/**
 * This is the Retrieve Census Reports Service Response Pojo
 * @author Cognizant Technology Solutions
 *
 */
public class RetrieveAutoPaymentsResponse {

	protected ResponseHeader responseHeader;

	private RetrieveAutoPaymentsResponseBody responseBody = new RetrieveAutoPaymentsResponseBody();

	/**
	 * 
	 * @return responseHeader
	 */
	public ResponseHeader getResponseHeader() {
		return responseHeader;
	}

	/**
	 * responseHeader to set
	 * @param responseHeader
	 */
	public void setResponseHeader(ResponseHeader responseHeader) {
		this.responseHeader = responseHeader;
	}

	/**
	 * @return the responseBody
	 */
	public RetrieveAutoPaymentsResponseBody getResponseBody() {
		return responseBody;
	}

	/**
	 * @param responseBody the responseBody to set
	 */
	public void setResponseBody(RetrieveAutoPaymentsResponseBody responseBody) {
		this.responseBody = responseBody;
	}

}
