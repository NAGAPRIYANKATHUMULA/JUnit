package com.bsc.ais.manage.payment.info.services.v1.model.response.invoices;

import com.bsc.aip.core.model.common.composite.ResponseHeader;

/**
 * This is the Retrieve Census Reports Service Response Pojo
 * 
 * @author Cognizant Technology Solutions
 *
 */
public class RetrieveInvoiceInformationResponse {

	protected ResponseHeader responseHeader;

	private RetrieveInvoiceInformationResponseBody responseBody = new RetrieveInvoiceInformationResponseBody();

	/**
	 * 
	 * @return responseHeader
	 */
	public ResponseHeader getResponseHeader() {
		return responseHeader;
	}

	/**
	 * responseHeader to set
	 * 
	 * @param responseHeader
	 */
	public void setResponseHeader(ResponseHeader responseHeader) {
		this.responseHeader = responseHeader;
	}

	/**
	 * @return the responseBody
	 */
	public RetrieveInvoiceInformationResponseBody getResponseBody() {
		return responseBody;
	}

	/**
	 * @param responseBody the responseBody to set
	 */
	public void setResponseBody(RetrieveInvoiceInformationResponseBody responseBody) {
		this.responseBody = responseBody;
	}

	

}
