package com.bsc.ais.manage.payment.info.services.v1.model.request;

import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformations;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SubgroupsSetCancelPaymentRequestBody {

	private String  userIdentifier;
	private String lastRunDate;
	private String batchActivity;
	private String isAutoPaymntCnclCnfrm;
	private EmailInformation emailInformation;
	private GroupIdentifiers groupIdentifiers;
	private PaymentInformations paymentInformations;
	
	

	public String getUserIdentifier() {
		return userIdentifier;
	}

	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}

	/**
	 * @return the paymentInformations
	 */
	public PaymentInformations getPaymentInformations() {
		return paymentInformations;
	}

	/**
	 * @param paymentInformations the paymentInformations to set
	 */
	public void setPaymentInformations(PaymentInformations paymentInformations) {
		this.paymentInformations = paymentInformations;
	}

	/** 
	 * @return the lastRunDate
	 */
	public String getLastRunDate() {
		return lastRunDate;
	}

	/**
	 * @param lastRunDate the lastRunDate to set
	 */
	public void setLastRunDate(String lastRunDate) {
		this.lastRunDate = lastRunDate;
	}

	/**
	 * @return the batchActivity
	 */
	public String getBatchActivity() {
		return batchActivity;
	}

	/**
	 * @param batchActivity the batchActivity to set
	 */
	public void setBatchActivity(String batchActivity) {
		this.batchActivity = batchActivity;
	}

	public EmailInformation getEmailInformation() {
		return emailInformation;
	}

	public void setEmailInformation(EmailInformation emailInformation) {
		this.emailInformation = emailInformation;
	}

	public GroupIdentifiers getGroupIdentifiers() {
		return groupIdentifiers;
	}

	public void setGroupIdentifiers(GroupIdentifiers groupIdentifiers) {
		this.groupIdentifiers = groupIdentifiers;
	}

	public String getIsAutoPaymntCnclCnfrm() {
		return isAutoPaymntCnclCnfrm;
	}

	public void setIsAutoPaymntCnclCnfrm(String isAutoPaymntCnclCnfrm) {
		this.isAutoPaymntCnclCnfrm = isAutoPaymntCnclCnfrm;
	}
}
