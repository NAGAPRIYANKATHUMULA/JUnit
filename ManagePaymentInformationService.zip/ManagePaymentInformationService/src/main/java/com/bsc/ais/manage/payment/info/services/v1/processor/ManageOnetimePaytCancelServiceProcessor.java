package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceDBConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional.EmailBody;
import com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional.EmailInput;
import com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional.SendNotificationServiceRequest;
import com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional.SendNotificationServiceRequestBody;
import com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional.SendNotificationServiceResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceWPRDbUtil;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component("manageOnetimePaytCancelServiceProcessor")
public class ManageOnetimePaytCancelServiceProcessor implements Processor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LogManager.getLogger(ManageOnetimePaytCancelServiceProcessor.class);

	@Value("${manage.subgroups.autopayment.notification.email.fromaddressindicator}")
	private String activationEmailFromaddressindicator;

	@Value("${manage.subgroups.autopayment.notification.email.attachmentneeded}")
	private String activationEmailAttachmentneeded;

	@Value("${manage.subgroups.autopayment.notificationservicev2.service.url}")
	private String notificationv2Uri;

	@Value("${manage.subgroups.autopayment.notificationservicev2.service.jwt.token}")
	private String notificationv2AuthenticationToken;
	
	@Value("${manage.subgroups.onetimepayment.notification.email.applogin.url}")
	private String oneTimePaytEmailappLogInUrl;

	/**
	 * Create an instance of Rest template.
	 */
	private RestTemplate RestTemplate = new RestTemplate();

	@Resource
	private ManagePaymentInfoServiceWPRDbUtil managePaymentInfoServiceWPRDbUtil;

	/** The event logging. */
	@Resource(name = "eventLogging")
	private EventLogging eventLogging;


	/**
	 * Holds the method name.
	 */
	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";


	/*
	 * (non-Javadoc)
	 * 
	 * This method is used to populate the  parameter name and its value to the response object.
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	@SuppressWarnings({ "unchecked" })
	public void process(Exchange exchange) throws Exception {

		// Obtain transaction id for logging purpose.
		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_ENTERING + METHOD_PROCESS);

		// Obtain the instance of service request
		SubgroupsSetCancelPaymentRequest request = (SubgroupsSetCancelPaymentRequest) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST);

		// Obtain an instance of response from exchange object.
		SubgroupsSetCancelPaymentResponse response = (SubgroupsSetCancelPaymentResponse) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);

		// Obtain an instance of audit list from exchange object.
		List<AuditEvent> auditEventList = (List<AuditEvent>) exchange.getProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST);

		

			// Create an instance of ArrayList to hold response messages.
			List<Message> message = new ArrayList<Message>();
			try {
				if(response.getResponseHeader().getTransactionNotification().getStatusCode().equals(ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE)) {
				final List<Map<String, Object>> rows = managePaymentInfoServiceWPRDbUtil.fetchEmailInfo((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER));
				if (rows != null && rows.size() > 0 && !rows.isEmpty() &&
						StringUtils.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_YES, (String)rows.get(0).get(ManagePaymentInfoServiceDBConstants.PMT_NOTFY_IND))) {
					HttpHeaders httpHeaders = new HttpHeaders();
					httpHeaders.setContentType(MediaType.APPLICATION_JSON);
					ObjectMapper requestMapper = new ObjectMapper();
					RequestHeader requestHeader = new RequestHeader();
					HttpEntity<String> requestEntity;

					requestHeader = ManagePaymentInfoServiceUtil.processRequestHeader(requestHeader,
							notificationv2AuthenticationToken);
					String templateTypeCode = (String)rows.get(0).get("EMAIL_TYP_CD");
					int templateTypeCd = 0;
					if(null != templateTypeCode){
						templateTypeCd = Integer.parseInt(templateTypeCode);
					}
					String lastName = (String)rows.get(0).get(ManagePaymentInfoServiceDBConstants.ALS_LST_NM);
					String firstName = (String)rows.get(0).get(ManagePaymentInfoServiceDBConstants.ALS_FRST_NM);
					String emailAddrTxt = (String)rows.get(0).get(ManagePaymentInfoServiceDBConstants.EMAIL_ADDR_TXT);
					String name = firstName + " " + lastName;
					SendNotificationServiceRequest notifyRequest = setMemberEmailBody(requestHeader,request ,templateTypeCd, emailAddrTxt, name, exchange);

					requestEntity = new HttpEntity<String>(requestMapper.writeValueAsString(notifyRequest), httpHeaders);
					sendEmail(response, message, transactionId, requestEntity);
				} else {
					LOGGER.debug(METHOD_PROCESS + ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE
							+ " email request data not found in database "+ transactionId);
				}
			}
			} catch (Exception ex) {

				ManagePaymentInfoServiceUtil.addMessage(message,
						ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
						ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
						ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);
				LOGGER.error(transactionId + " - " + METHOD_PROCESS 
						+ ex);
				ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.SET_BANK_ACC_EVENT_FAILURE_CODE);
			}

			if (!message.isEmpty()) {
				//audit logging
				ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.SET_BANK_ACC_EVENT_FAILURE_CODE);
			}

			LOGGER.debug(ManagePaymentInfoServiceConstants.METHOD_EXITING, transactionId, METHOD_PROCESS);

		

	}

	/**
	 * @param request
	 * @param exchange
	 * @param notifyRequest
	 * @param notifyRequestBody
	 */
	private SendNotificationServiceRequest setMemberEmailBody(RequestHeader requestHeader , SubgroupsSetCancelPaymentRequest request,
			int templateTypeCd, String emailAddrTxt, String name, Exchange exchange) {

		SendNotificationServiceRequest notifyRequest = new SendNotificationServiceRequest();
		SendNotificationServiceRequestBody notifyRequestBody = new SendNotificationServiceRequestBody();
		notifyRequest.setRequestHeader(requestHeader);
		EmailInput emailInput = new EmailInput();
		List<String> toEmailList = new ArrayList<String>();
		toEmailList.add(emailAddrTxt);
		emailInput.setToAddress(toEmailList);
		emailInput.setFromAddressIndicator(activationEmailFromaddressindicator);
		emailInput.setSubject(ManagePaymentInfoServiceConstants.ONE_TIME_PYMT_CANCEL_EMAIL_SUBJECT);

		if(templateTypeCd == 0){
			emailInput.setTemplateType("text/plain");
			emailInput.setTemplateIndicator("empOneTimePaymentCancelledText");
		} else {
			emailInput.setTemplateIndicator("empOneTimePaymentCancelledHTML");
		}
		emailInput.setAttachmentNeeded(activationEmailAttachmentneeded);
		
		EmailBody emailBody = new EmailBody();
		emailBody.setFirstName(name);
		String subGroupIdentifier = (String)request.getRequestBody().getGroupIdentifiers().getGroupIdentifier().get(0).getGroupSubgroups().getGroupSubgroup().get(0).getGroupSubgroupIdentifier();
		emailBody.setGroupId(subGroupIdentifier.substring(0, 8));
		emailBody.setSubgroupId(subGroupIdentifier.substring(8, 12));
		emailBody.setAppLoginUrl(oneTimePaytEmailappLogInUrl);
		emailInput.setEmailBody(emailBody);
		
		notifyRequestBody.setEmailInput(emailInput);
		notifyRequest.setRequestBody(notifyRequestBody);
		return notifyRequest;
	}

	/**
	 * @param response
	 * @param message
	 * @param transactionId
	 * @param requestEntity
	 * @throws IOException
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 */
	private void sendEmail(SubgroupsSetCancelPaymentResponse response, List<Message> message,
			String transactionId, HttpEntity<String> requestEntity)
					throws IOException, JsonParseException, JsonMappingException {

		ResponseEntity<String> notifyServiceResponse;
		// Call notificationv2 service service to send the email.
		notifyServiceResponse = RestTemplate.exchange(notificationv2Uri, HttpMethod.POST, requestEntity, String.class);

		// Response objects
		SendNotificationServiceResponse notifyResponse = null;
		if (notifyServiceResponse != null) {

			ObjectMapper responseMapper = new ObjectMapper();
			String notifyResponseString = ManagePaymentInfoServiceUtil.processSyncResponse(notifyServiceResponse,
					ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE);

			if (notifyResponseString != null && !StringUtils.isBlank(notifyResponseString)) {
				notifyResponse = responseMapper.readValue(
						ManagePaymentInfoServiceUtil.processSyncResponse(notifyServiceResponse,
								ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE),
						SendNotificationServiceResponse.class);
				if (StringUtils.equalsIgnoreCase(
						notifyResponse.getResponseHeader().getTransactionNotification().getStatusCode(),
						ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE)) {
					if (notifyResponse.getResponseBody() != null) {

						response.getResponseHeader().getTransactionNotification()
						.setStatusCode(ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE);
						response.getResponseHeader().getTransactionNotification()
						.setStatus(ManagePaymentInfoServiceConstants.SUCCESS);

					}
				} else {

					ManagePaymentInfoServiceUtil.addMessage(message,
							ManagePaymentInfoServiceConstants.MSG_CODE_EMAIL_SENDING_FAILURE,
							ManagePaymentInfoServiceConstants.MSG_DESC_EMAIL_SENDING_FAILURE,
							ManagePaymentInfoServiceConstants.MSG_DESC_EMAIL_SENDING_FAILURE);
				}

			} else {

				ManagePaymentInfoServiceUtil.addMessage(message,
						ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
						ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
						ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);

				LOGGER.error(transactionId + " - " + METHOD_PROCESS + ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE);
			}
		}
	}

}
