/**
 * SubgroupIdentifier.java
 */
package com.bsc.ais.manage.payment.info.services.v1.model.request.invoices;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Cognizant Technology Solutions
 *
 */
@JsonIgnoreProperties (ignoreUnknown = true)
public class SubgroupIdentifier {

	private String subgroupIdentifier;

	/**
	 * @return the subGroupIdentifier
	 */
	public String getSubgroupIdentifier() {
		return subgroupIdentifier;
	}

	/**
	 * @param subGroupIdentifier the subGroupIdentifier to set
	 */
	public void setSubgroupIdentifier(String subgroupIdentifier) {
		this.subgroupIdentifier = subgroupIdentifier;
	}


	
}
