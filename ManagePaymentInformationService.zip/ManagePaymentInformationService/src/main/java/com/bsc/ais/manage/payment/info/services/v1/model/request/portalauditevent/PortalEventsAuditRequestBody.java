package com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PortalEventsAuditRequestBody {
	
	private AuditEvents auditEvents;

	public AuditEvents getAuditEvents() {
		return auditEvents;
	}

	public void setAuditEvents(AuditEvents auditEvents) {
		this.auditEvents = auditEvents;
	}
	
	
}
