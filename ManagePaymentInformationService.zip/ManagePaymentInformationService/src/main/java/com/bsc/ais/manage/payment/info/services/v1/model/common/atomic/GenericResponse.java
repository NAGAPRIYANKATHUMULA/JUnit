package com.bsc.ais.manage.payment.info.services.v1.model.common.atomic;

import com.bsc.aip.core.model.common.composite.ResponseHeader;

public class GenericResponse {
	
	private ResponseHeader responseHeader;

	public ResponseHeader getResponseHeader() {
		return responseHeader;
	}

	public void setResponseHeader(ResponseHeader responseHeader) {
		this.responseHeader = responseHeader;
	}
	
	

}
