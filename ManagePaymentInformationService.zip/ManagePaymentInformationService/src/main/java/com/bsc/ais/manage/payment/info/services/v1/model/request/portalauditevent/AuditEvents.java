package com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AuditEvents {
	
	private List<AuditEvent> auditEvent;

	public List<AuditEvent> getAuditEvent() {
		return auditEvent;
	}

	public void setAuditEvent(List<AuditEvent> auditEvent) {
		this.auditEvent = auditEvent;
	}
	
}
