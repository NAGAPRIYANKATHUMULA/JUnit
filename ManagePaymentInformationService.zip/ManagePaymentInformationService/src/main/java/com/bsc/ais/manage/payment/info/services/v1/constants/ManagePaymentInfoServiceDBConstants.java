package com.bsc.ais.manage.payment.info.services.v1.constants;

/**
 * <HTML> This class contains the database Constants required for the Fep Integration Service </HTML>.
 * 
 * @author Cognizant Technology Solutions
 * @version 1.0
 *
 */
public class ManagePaymentInfoServiceDBConstants {
	
	public static final String ACC_NICK_NAME = "ACC_NICK_NAME";
	public static final String ACC_HOLDER_NAME = "ACC_HOLDER_NAME";
	public static final String ACC_NUMBER = "ACC_NUMBER";
	public static final String ROUTING_NUMBER = "ROUTING_NUMBER";
	public static final String ACC_TYPE = "ACC_TYPE";
	public static final String MCBD_ID = "MCBD_ID";
	public static final String ACC_NAME = "ACC_NAME";
	public static final String PAYMENT_FLAG = "PAYMENT_FLAG";
	public static final String SUB_GROUP_IDEN = "SUB_GROUP_IDEN";
	public static final String SUB_GROUP_NAME = "SUB_GROUP_NAME";
	public static final String GRGR_ID = "GRGR_ID" ;
	public static final String GRGR_TERM_DT = "GRGR_TERM_DT" ;
	public static final String SUB_GRP_IDS = "lSubgrpIdActArray";
	public static final String  SGSG_ID = "SGSG_ID";
	public static final String  BLEI_CK = "lBleiCk";
	public static final String EMAIL_ADDR_TXT = "EMAIL_ADDR_TXT";
	public static final String EMAIL_FMT_TYP_CD = "EMAIL_FMT_TYP_CD";
	public static final String ALS_FRST_NM = "ALS_FRST_NM";
	public static final String ALS_LST_NM = "ALS_LST_NM";
	public static final String SCHED_NOTFY_IND = "SCHED_NOTFY_IND";
	public static final String GRP_BLG_UNIT_NUM = "GRP_BLG_UNIT_NUM";
	public static final String MAINT_PERMISSION = "isMaintPermission";
	public static final String ACT_NM = "ACT_NM";
	public static final String PMT_ACT_DT = "PMT_ACT_DT";
	public static final String USR_NM = "USR_NM";
	public static final String GRP_SUB_GRP_NBR = "GRP_SUB_GRP_NBR";
	public static final String BNK_ACCT_NCKNM = "BNK_ACCT_NCKNM";
	public static final String PMT_NOTFY_IND = "PMT_NOTFY_IND";
	public static final String GRGR_STS ="GRGR_STS";

	
}
