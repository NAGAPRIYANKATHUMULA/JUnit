package com.bsc.ais.manage.payment.info.services.v1.model.response;

public class UserInformation {

	private String groupSubGroupIdentifier;
	private String maintPermission;
	/**
	 * @return the groupSubGroupIdentifier
	 */
	public String getGroupSubGroupIdentifier() {
		return groupSubGroupIdentifier;
	}
	/**
	 * @param groupSubGroupIdentifier the groupSubGroupIdentifier to set
	 */
	public void setGroupSubGroupIdentifier(String groupSubGroupIdentifier) {
		this.groupSubGroupIdentifier = groupSubGroupIdentifier;
	}
	/**
	 * @return the maintPermission
	 */
	public String getMaintPermission() {
		return maintPermission;
	}
	/**
	 * @param maintPermission the maintPermission to set
	 */
	public void setMaintPermission(String maintPermission) {
		this.maintPermission = maintPermission;
	}
	
	
}
