/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceDBConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional.EmailBody;
import com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional.EmailInput;
import com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional.SendNotificationServiceRequest;
import com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional.SendNotificationServiceRequestBody;
import com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional.SendNotificationServiceResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceWPRDbUtil;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Cognizant
 *
 */
@Component("manageOneTimePymtSendMailProcessor")
public class ManageOneTimePymtSendMailProcessor implements Processor {

	private static final Logger LOGGER = LogManager.getLogger(ManageOneTimePymtSendMailProcessor.class);

	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";

	@Value("${manage.subgroups.autopayment.notification.email.fromaddressindicator}")
	private String activationEmailFromaddressindicator;

	@Value("${manage.subgroups.autopayment.notification.email.attachmentneeded}")
	private String activationEmailAttachmentneeded;

	@Value("${manage.subgroups.autopayment.notificationservicev2.service.url}")
	private String notificationv2Uri;

	@Value("${manage.subgroups.autopayment.notificationservicev2.service.jwt.token}")
	private String notificationv2AuthenticationToken;

	@Value("${manage.subgroups.onetimepayment.notification.email.applogin.url}")
	private String appLogInUrl;

	/**
	 * Create an instance of Rest template.
	 */
	private RestTemplate RestTemplate = new RestTemplate();

	@Resource
	private ManagePaymentInfoServiceWPRDbUtil managePaymentInfoServiceWPRDbUtil;

	@Resource
	private EventLogging eventLogging;

	@Override
	public void process(Exchange exchange) throws Exception {

		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);

		LOGGER.debug(ManagePaymentInfoServiceConstants.METHOD_ENTERING, transactionId, METHOD_PROCESS);
		// Holds list of response messages
		List<Message> message = new ArrayList<Message>();

		// Obtain the instance of service request
		SubgroupsSetCancelPaymentRequest request = (SubgroupsSetCancelPaymentRequest) exchange
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST);
		// Obtain an instance of response from exchange object.
		SubgroupsSetCancelPaymentResponse response = (SubgroupsSetCancelPaymentResponse) exchange
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
		// Obtain an instance of audit list from exchange object.
		@SuppressWarnings("unchecked")
		List<AuditEvent> auditEventList = (List<AuditEvent>) exchange
				.getProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST);

		String serviceName = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME);
		try {

			String setServiceSuccess = null;
			String setMailSentSuccess = ManagePaymentInfoServiceConstants.STRING_FALSE;
			exchange.setProperty(ManagePaymentInfoServiceConstants.CANCEL_BANK_ACC,
					ManagePaymentInfoServiceConstants.STRING_FALSE);
			
			if (serviceName.equals(ManagePaymentInfoServiceConstants.MANAGE_ONE_TIME_PYMT_SET)) {
				if (StringUtils.equalsIgnoreCase(
						response.getResponseHeader().getTransactionNotification().getStatusCode(),
						ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE)
						|| (!response.getResponseHeader().getTransactionNotification().getRemarks().getMessages()
								.isEmpty()
								&& StringUtils.isNotBlank(response.getResponseHeader().getTransactionNotification()
										.getRemarks().getMessages().get(0).getMessage())
								&& StringUtils.equalsIgnoreCase(
										response.getResponseHeader().getTransactionNotification().getRemarks()
												.getMessages().get(0).getMessage(),
										ManagePaymentInfoServiceConstants.MSG_FEASIBILITY_ERROR))) {
					setServiceSuccess = ManagePaymentInfoServiceConstants.STRING_TRUE;
				}
			} else {
				setServiceSuccess = ManagePaymentInfoServiceConstants.STRING_FALSE;
				if (StringUtils.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_TRUE,
						(String) exchange.getProperty(ManagePaymentInfoServiceConstants.BANK_ACC_SET_CALL_SUCCESS))) {
					exchange.setProperty(ManagePaymentInfoServiceConstants.CANCEL_BANK_ACC,
							ManagePaymentInfoServiceConstants.STRING_TRUE);
				} else {
					exchange.setProperty(ManagePaymentInfoServiceConstants.CANCEL_BANK_ACC,
							ManagePaymentInfoServiceConstants.STRING_FALSE);
				}
			}
			if (StringUtils.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_TRUE, setServiceSuccess)) {

				@SuppressWarnings("unchecked")
				final List<Map<String, Object>> rows = managePaymentInfoServiceWPRDbUtil.fetchEmailInfo(
						(String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER));
				if (rows != null && rows.size() > 0 && !rows.isEmpty()) {
					HttpHeaders httpHeaders = new HttpHeaders();
					httpHeaders.setContentType(MediaType.APPLICATION_JSON);
					ObjectMapper requestMapper = new ObjectMapper();
					RequestHeader requestHeader = new RequestHeader();
					HttpEntity<String> requestEntity;

					requestHeader = ManagePaymentInfoServiceUtil.processRequestHeader(requestHeader,
							notificationv2AuthenticationToken);
					String templateTypeCode = (String) rows.get(0).get("EMAIL_TYP_CD");
					int templateTypeCd = 0;
					if (null != templateTypeCode) {
						templateTypeCd = Integer.parseInt(templateTypeCode);
					}
					

					if (StringUtils.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_TRUE,
							(String) exchange.getProperty(ManagePaymentInfoServiceConstants.BANK_ACC_SET_CALL_SUCCESS))
							&& StringUtils.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_FALSE,
									setMailSentSuccess) &&
							 StringUtils.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_YES, (String)rows.get(0).get("BNK_UPDT_NOTFY_IND"))) {
						SendNotificationServiceRequest notifyRequest = setMemberEmailBody(requestHeader, request,
								templateTypeCd, exchange, setMailSentSuccess, rows);

						requestEntity = new HttpEntity<String>(requestMapper.writeValueAsString(notifyRequest),
								httpHeaders);
						sendEmail(response, message, transactionId, requestEntity);
						setMailSentSuccess = ManagePaymentInfoServiceConstants.STRING_TRUE;
					}
					if (StringUtils.equalsIgnoreCase(
							(String) exchange.getProperty(ManagePaymentInfoServiceConstants.EMAIL_INFO_EXISTS),
							ManagePaymentInfoServiceConstants.STRING_TRUE)){
						SendNotificationServiceRequest notifyRequest = setMemberEmailBody(requestHeader, request,
								templateTypeCd, exchange, setMailSentSuccess, rows);

						requestEntity = new HttpEntity<String>(requestMapper.writeValueAsString(notifyRequest),
								httpHeaders);
						sendEmail(response, message, transactionId, requestEntity);
					}
				} else {
					LOGGER.debug(METHOD_PROCESS + ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE
							+ " email request data not found in database " + transactionId);
				}
			}
		} catch (Exception ex) {

			ManagePaymentInfoServiceUtil.addMessage(message, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR, ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);
			LOGGER.error(transactionId + " - " + METHOD_PROCESS + ex);
			ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,
					ManagePaymentInfoServiceConstants.SET_BANK_ACC_EVENT_FAILURE_CODE);
		}

		if (!message.isEmpty()) {
			// audit logging
			ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,
					ManagePaymentInfoServiceConstants.SET_BANK_ACC_EVENT_FAILURE_CODE);
		}

		LOGGER.debug(ManagePaymentInfoServiceConstants.METHOD_EXITING, transactionId, METHOD_PROCESS);
	}

	/**
	 * @param request
	 * @param exchange
	 * @param notifyRequest
	 * @param notifyRequestBody
	 */
	private SendNotificationServiceRequest setMemberEmailBody(RequestHeader requestHeader,
			SubgroupsSetCancelPaymentRequest request, int templateTypeCd, Exchange exchange, String setMailSentSuccess,
			List<Map<String, Object>> emailRows) {

		SendNotificationServiceRequest notifyRequest = new SendNotificationServiceRequest();
		SendNotificationServiceRequestBody notifyRequestBody = new SendNotificationServiceRequestBody();
		String serviceName = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME);
		notifyRequest.setRequestHeader(requestHeader);
		EmailInput emailInput = new EmailInput();
		List<String> toEmailList = new ArrayList<String>();
		emailInput.setAttachmentNeeded(activationEmailAttachmentneeded);
		emailInput.setFromAddressIndicator(activationEmailFromaddressindicator);
		EmailBody emailBody = new EmailBody();
		if (StringUtils.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_TRUE,
				(String) exchange.getProperty(ManagePaymentInfoServiceConstants.BANK_ACC_SET_CALL_SUCCESS))
				&& StringUtils.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_FALSE, setMailSentSuccess)) {

			toEmailList.add((String) emailRows.get(0).get(ManagePaymentInfoServiceDBConstants.EMAIL_ADDR_TXT));
			emailInput.setToAddress(toEmailList);
			
			emailInput.setSubject(ManagePaymentInfoServiceConstants.BANK_ACC_SET_EMAIL_SUBJECT);
			if (templateTypeCd == 2) {
				emailInput.setTemplateIndicator("empAddBankAccntHTML");
			} else {
				emailInput.setTemplateType("text/plain");
				emailInput.setTemplateIndicator("empAddBankAccntText");
			}

			String accountNumber = (String) request.getRequestBody().getPaymentInformations().getPaymentInformation()
					.get(0).getAccountNumber();
			String maskedAccNo = StringUtils.replace(accountNumber,
					accountNumber.substring(0, accountNumber.length() - 4),
					StringUtils.repeat("*", accountNumber.length() - 4));

			emailBody.setFirstName((String) emailRows.get(0).get(ManagePaymentInfoServiceDBConstants.ALS_FRST_NM) + " " +
					(String) emailRows.get(0).get(ManagePaymentInfoServiceDBConstants.ALS_LST_NM));
			emailBody.setAccountNumber(maskedAccNo);
			emailBody.setGroupId((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_SUB_GRP_ID)
					.toString().substring(0, 8));

		} else {
			toEmailList.add((String) request.getRequestBody().getEmailInformation().getEmailAddress());
			if (StringUtils.isNotBlank(request.getRequestBody().getEmailInformation().getAdditionalEmailAddress())) {
				toEmailList.add(request.getRequestBody().getEmailInformation().getAdditionalEmailAddress());
			}
			emailInput.setToAddress(toEmailList);

			if (serviceName.equals(ManagePaymentInfoServiceConstants.MANAGE_ONE_TIME_PYMT_SET)) {
				emailInput.setSubject(ManagePaymentInfoServiceConstants.ONE_TIME_PYMT_SET_SUB);
				if (templateTypeCd == 2) {

					emailInput.setTemplateIndicator("empOneTimePaymentSubmittedHTML");
				} else {
					emailInput.setTemplateType("text/plain");
					emailInput.setTemplateIndicator("empOneTimePaymentSubmittedText");
				}
			}
			emailBody.setFirstName((String) request.getRequestBody().getEmailInformation().getName());
			emailBody.setGroupId((String) request.getRequestBody().getEmailInformation().getGroupIdentifier());
			emailBody.setSubgroupId((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_SUB_GRP_ID));
			emailBody.setAppLoginUrl(appLogInUrl);
		}
		emailInput.setEmailBody(emailBody);
		notifyRequestBody.setEmailInput(emailInput);
		notifyRequest.setRequestBody(notifyRequestBody);
		return notifyRequest;
	}

	/**
	 * @param response
	 * @param message
	 * @param transactionId
	 * @param requestEntity
	 * @throws IOException
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 */
	private void sendEmail(SubgroupsSetCancelPaymentResponse response, List<Message> message, String transactionId,
			HttpEntity<String> requestEntity) throws IOException, JsonParseException, JsonMappingException {

		ResponseEntity<String> notifyServiceResponse;
		// Call notificationv2 service service to send the email.
		notifyServiceResponse = RestTemplate.exchange(notificationv2Uri, HttpMethod.POST, requestEntity, String.class);

		// Response objects
		SendNotificationServiceResponse notifyResponse = null;
		if (notifyServiceResponse != null) {

			ObjectMapper responseMapper = new ObjectMapper();
			String notifyResponseString = ManagePaymentInfoServiceUtil.processSyncResponse(notifyServiceResponse,
					ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE);

			if (notifyResponseString != null && !StringUtils.isBlank(notifyResponseString)) {
				notifyResponse = responseMapper.readValue(
						ManagePaymentInfoServiceUtil.processSyncResponse(notifyServiceResponse,
								ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE),
						SendNotificationServiceResponse.class);
				if (StringUtils.equalsIgnoreCase(
						notifyResponse.getResponseHeader().getTransactionNotification().getStatusCode(),
						ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE)) {
					if (notifyResponse.getResponseBody() != null) {

						response.getResponseHeader().getTransactionNotification()
								.setStatusCode(ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE);
						response.getResponseHeader().getTransactionNotification()
								.setStatus(ManagePaymentInfoServiceConstants.SUCCESS);

					}
				} else {

					ManagePaymentInfoServiceUtil.addMessage(message,
							ManagePaymentInfoServiceConstants.MSG_CODE_EMAIL_SENDING_FAILURE,
							ManagePaymentInfoServiceConstants.MSG_DESC_EMAIL_SENDING_FAILURE,
							ManagePaymentInfoServiceConstants.MSG_DESC_EMAIL_SENDING_FAILURE);
				}

			} else {

				ManagePaymentInfoServiceUtil.addMessage(message, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
						ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
						ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);

				LOGGER.error(
						transactionId + " - " + METHOD_PROCESS + ManagePaymentInfoServiceConstants.SEND_EMAIL_SERVICE);
			}
		}
	}

}
