/*
 * RetrieveAutoPaymentsDataProcessor.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceDBConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.response.UserInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceWPRDbUtil;





/**
 * <HTML> This processor is used to retrieve data about auto payments from WPR database 
 * </HTML>.
 *
 * @author Cognizant Technology Solutions.
 * @version 1.0
 * 
 */

@Component("retrieveAutoPaymentsDataProcessor")
public class RetrieveAutoPaymentsDataProcessor implements Processor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LogManager.getLogger(RetrieveAutoPaymentsDataProcessor.class);

	/** The event logging. */
	@Resource(name = "eventLogging")
	private EventLogging eventLogging;
	
	/**
	 * Holds the method name.
	 */
	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";
	
	@Resource
	private ManagePaymentInfoServiceWPRDbUtil managePaymentInfoServiceWPRDbUtil;

	/*
	 * (non-Javadoc)
	 * 
	 * This method is used to populate the  parameter name and its value to the response object.
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	@SuppressWarnings("unchecked")
	public void process(Exchange exchange) throws Exception {
		
		// Obtain transaction id for logging purpose.
		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_ENTERING + METHOD_PROCESS);
		
		// Obtain an instance of response from exchange object.
		RetrieveAutoPaymentsResponse response = (RetrieveAutoPaymentsResponse) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
		
		// Obtain an instance of audit list from exchange object.
		List<AuditEvent> auditEventList = (List<AuditEvent>) exchange.getProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST);
		
		// Create an instance of ArrayList to hold response messages.
		List<Message> messages = new ArrayList<Message>();
		
		try {
		
		//Get all the values from exchange object and use it for census retrieval	
		String userIdentifier = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER);
		String groupIdentifier = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_IDENTIFIER);
		
		exchange.setProperty(ManagePaymentInfoServiceConstants.IS_USERINFO_PRESENT, ManagePaymentInfoServiceConstants.STRING_FALSE);
		
		//Execute WPR database query to obtain SubGroupList for the userIdentifier and groupIdentifier passed in the request
		List<Map<String, Object>> userInfoRows = managePaymentInfoServiceWPRDbUtil.retrieveUserInformation(userIdentifier, groupIdentifier);
		
		if(null != userInfoRows && !userInfoRows.isEmpty()){
			LOGGER.debug(transactionId + " - "+ "userInfo present in WPR Database.");
			Map<String,String> userInfoMap =new HashMap<String,String>();
			Map<String, List<String>> groupInfoMap = new HashMap<String, List<String>>();
			List<String> subGroupIdList = new ArrayList<String>();
			List<String> sgsgIdList = new ArrayList<String>();
			for(Map<String, Object> row:userInfoRows){
				UserInformation userInfo = new UserInformation();
				String subgroupId = (String)row.get(ManagePaymentInfoServiceDBConstants.GRP_BLG_UNIT_NUM);
				String maintPermission = (String)row.get(ManagePaymentInfoServiceDBConstants.MAINT_PERMISSION);
				userInfo.setGroupSubGroupIdentifier(subgroupId);
				userInfo.setMaintPermission(maintPermission);
				//userInfoList.add(userInfo);
				userInfoMap.put(subgroupId, maintPermission);
				subGroupIdList.add(subgroupId);
				sgsgIdList.add(subgroupId.substring(8, 12));
			}
			groupInfoMap.put(groupIdentifier, sgsgIdList);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_MAP, groupInfoMap);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUBGROUP_IDENTIFIER_LIST, subGroupIdList);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USERINFO_MAP, userInfoMap);
			exchange.setProperty(ManagePaymentInfoServiceConstants.IS_USERINFO_PRESENT, ManagePaymentInfoServiceConstants.STRING_TRUE);
			
			//Execute WPR database query to obtain schedule notify indicator value
			String scheduleNotifyInd = managePaymentInfoServiceWPRDbUtil.retrieveScheduleNotifyIndInformation(userIdentifier);
			
			if(null != scheduleNotifyInd){
				exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SCHEDULE_NOTIFY_IND, scheduleNotifyInd);
				LOGGER.debug(transactionId + " - "+ "schedule Notify Indicator present in WPR Database.");
			}else{
				LOGGER.debug(transactionId + " - "+ "schedule Notify Indicator is not available in WPR Database.");
				ManagePaymentInfoServiceUtil.addMessage(messages,
						ManagePaymentInfoServiceConstants.MSG_CODE_USER_DATA_NOT_FOUND,
						ManagePaymentInfoServiceConstants.MSG_USER_DATA_NOT_FOUND,
						ManagePaymentInfoServiceConstants.MSG_DESC_USER_DATA_FOUND);
				//audit logging
				ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.RETRIEVE_AUTOPAYMENTS_EVENT_FAILURE_CODE);
			}
		}else{
			LOGGER.debug(transactionId + " - "+ "userInfo is not present in WPR Database.");
			ManagePaymentInfoServiceUtil.addMessage(messages,
					ManagePaymentInfoServiceConstants.MSG_CODE_USER_DATA_NOT_FOUND,
					ManagePaymentInfoServiceConstants.MSG_USER_DATA_NOT_FOUND,
					ManagePaymentInfoServiceConstants.MSG_DESC_USER_DATA_FOUND);
			//audit logging
			ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.RETRIEVE_AUTOPAYMENTS_EVENT_FAILURE_CODE);
		}
		
		if (!messages.isEmpty()) {
			response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.WARNING,
					ManagePaymentInfoServiceConstants.WARNING_STATUS_CODE, response.getResponseHeader(), messages));
			messages.clear();
		}
		
		
		}catch (Exception ex) {
			LOGGER.error(transactionId + " - "+ METHOD_PROCESS , ex);
			ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);
			
			//audit logging
			ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.RETRIEVE_AUTOPAYMENTS_EVENT_FAILURE_CODE);
		}
		
		if (!messages.isEmpty()) {
			response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE,
					ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, response.getResponseHeader(), messages));
		}
		
		//set the response to exchange object
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
		exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
		response.setResponseBody(null);
		exchange.getIn().setBody(response);
		
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_EXITING + METHOD_PROCESS);
	}
	
}
