/*
 * ManagePaymentInfoServicesErrorProcessor.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

/**
 * <HTML> This processor handles the exceptions occurred in the Manage Payment Info Services
 *
 * @author Cognizant Technology Solutions.
 * @version 1.0
 * 
 */

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.bsc.aip.core.camel.template.BscCamelTemplate;
import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsHistoryRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsHistoryResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;


@Component("managePaymentInfoServicesErrorProcessor")
public class ManagePaymentInfoServicesErrorProcessor implements Processor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LogManager.getLogger(ManagePaymentInfoServicesErrorProcessor.class);

	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";

	/** The event logging. */
	@Resource
	private EventLogging eventLogging;
	
	@Resource(name = "bscCamelTemplate")
	private BscCamelTemplate bscCamelTemplate;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	public void process(Exchange exchange) throws Exception {

		LOGGER.debug(ManagePaymentInfoServiceConstants.METHOD_ENTERING, METHOD_PROCESS);
		
		List<Message> message = new ArrayList<Message>();
		Object response = null;
		Exception cause = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
		String transactionId = "";
		
		try {
			RequestHeader requestHeader = null;
			transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
			if (exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST) != null) {
				if (StringUtils.equalsIgnoreCase((String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME),
						ManagePaymentInfoServiceConstants.GET_SCHEDULE_SERVICE) ||
						StringUtils.equalsIgnoreCase((String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME),
								ManagePaymentInfoServiceConstants.RETRIEVE_BANK_ACC_INFO_SERVICE)) {
					requestHeader = ((RetrievePaymentInfoRequest)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST)).getRequestHeader();
					response = new RetrievePaymentInfoResponse();
					((RetrievePaymentInfoResponse) response).setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE, ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, 
							null, message));
					ManagePaymentInfoServiceUtil.addMessage(message,
							ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
							ManagePaymentInfoServiceConstants.TECHNICAL_EXCEPTION,
							ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);
					exchange.getIn().setBody((RetrievePaymentInfoResponse) response);
					
					LOGGER.error(requestHeader.getTransactionId(), cause); 
					
					if (requestHeader != null && requestHeader.getConsumer() != null) {
						
						bscCamelTemplate.getProducerTemplate().asyncSend("direct:managePaymentInfoPortalAuditLoggingProcessorCall", exchange);
					}
					eventLogging.logEvent(requestHeader, ((RetrievePaymentInfoResponse) response).getResponseHeader(),
							ManagePaymentInfoServiceConstants.EXIT, null, null,
							ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
							ManagePaymentInfoServiceConstants.CRITICAL,
							cause != null ? cause.getMessage() : ManagePaymentInfoServiceConstants.UNKNOWN_EXCEPTION,
							(String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME));
				}else if (StringUtils.equalsIgnoreCase((String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME),
						ManagePaymentInfoServiceConstants.RETRIEVE_AUTOPAYMENTS_HISTORY_SERVICE)) {
					requestHeader = ((RetrieveAutoPaymentsHistoryRequest)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST)).getRequestHeader();
					response = new RetrieveAutoPaymentsHistoryResponse();
					((RetrieveAutoPaymentsHistoryResponse) response).setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE, ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, 
							null, message));
					ManagePaymentInfoServiceUtil.addMessage(message,
							ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
							ManagePaymentInfoServiceConstants.TECHNICAL_EXCEPTION,
							ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);
					exchange.getIn().setBody((RetrieveAutoPaymentsHistoryResponse) response);
					
					LOGGER.error(requestHeader.getTransactionId(), cause); 
					
					if (requestHeader != null && requestHeader.getConsumer() != null) {
						
						bscCamelTemplate.getProducerTemplate().asyncSend("direct:managePaymentInfoPortalAuditLoggingProcessorCall", exchange);
					}
					eventLogging.logEvent(requestHeader, ((RetrieveAutoPaymentsHistoryResponse) response).getResponseHeader(),
							ManagePaymentInfoServiceConstants.EXIT, null, null,
							ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
							ManagePaymentInfoServiceConstants.CRITICAL,
							cause != null ? cause.getMessage() : ManagePaymentInfoServiceConstants.UNKNOWN_EXCEPTION,
							(String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME));
				}else if (StringUtils.equalsIgnoreCase((String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME),
						ManagePaymentInfoServiceConstants.RETRIEVE_AUTOPAYMENTS_GROUPS_SERVICE)) {
					requestHeader = ((RetrieveAutoPaymentsRequest)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST)).getRequestHeader();
					response = new RetrieveAutoPaymentsResponse();
					((RetrieveAutoPaymentsResponse) response).setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE, ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, 
							null, message));
					ManagePaymentInfoServiceUtil.addMessage(message,
							ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
							ManagePaymentInfoServiceConstants.TECHNICAL_EXCEPTION,
							ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);
					exchange.getIn().setBody((RetrieveAutoPaymentsResponse) response);
					
					LOGGER.error(requestHeader.getTransactionId(), cause); 
					
					if (requestHeader != null && requestHeader.getConsumer() != null) {
						
						bscCamelTemplate.getProducerTemplate().asyncSend("direct:managePaymentInfoPortalAuditLoggingProcessorCall", exchange);
					}
					eventLogging.logEvent(requestHeader, ((RetrieveAutoPaymentsResponse) response).getResponseHeader(),
							ManagePaymentInfoServiceConstants.EXIT, null, null,
							ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
							ManagePaymentInfoServiceConstants.CRITICAL,
							cause != null ? cause.getMessage() : ManagePaymentInfoServiceConstants.UNKNOWN_EXCEPTION,
							(String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME));
				}
			} else {
				
				eventLogging.logEvent(requestHeader, null,
						ManagePaymentInfoServiceConstants.EXIT, null, null,
						ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
						ManagePaymentInfoServiceConstants.CRITICAL,
						cause != null ? cause.getMessage() : ManagePaymentInfoServiceConstants.UNKNOWN_EXCEPTION,
						(String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME));
			}

			LOGGER.error(requestHeader.getTransactionId(), cause); 
		} catch (Exception ex) {
			
			LOGGER.error("Unknown Exception: - " + transactionId , ex);
			eventLogging.logEvent(null, null, ManagePaymentInfoServiceConstants.EXIT, null,
					null, ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
					ManagePaymentInfoServiceConstants.CRITICAL,
					cause != null ? cause.getMessage() : ManagePaymentInfoServiceConstants.UNKNOWN_EXCEPTION,
					(String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME));
		}

		LOGGER.debug(ManagePaymentInfoServiceConstants.METHOD_EXITING, METHOD_PROCESS);
		
	}


}
