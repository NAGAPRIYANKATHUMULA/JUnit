/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.model.response;

/**
 * @author Cognizant Technology Solutions
 *
 */
public class AutoPaymentInformation {

	private String subgroupName;
	private String subgroupIdentifier;
	private String lastPaidDate;
	private String lastPaidAmount;
	private String invoiceDue;
	private String accountNickName;
	private String accountNumber;
	private String paymentFlag;
	private String isMaintPermission;
	/**
	 * @return the subgroupName
	 */
	public String getSubgroupName() {
		return subgroupName;
	}
	/**
	 * @param subgroupName the subgroupName to set
	 */
	public void setSubgroupName(String subgroupName) {
		this.subgroupName = subgroupName;
	}
	
	/**
	 * @return the subgroupIdentifier
	 */
	public String getSubgroupIdentifier() {
		return subgroupIdentifier;
	}
	/**
	 * @param subgroupIdentifier the subgroupIdentifier to set
	 */
	public void setSubgroupIdentifier(String subgroupIdentifier) {
		this.subgroupIdentifier = subgroupIdentifier;
	}
	/**
	 * @return the lastPaidDate
	 */
	public String getLastPaidDate() {
		return lastPaidDate;
	}
	/**
	 * @param lastPaidDate the lastPaidDate to set
	 */
	public void setLastPaidDate(String lastPaidDate) {
		this.lastPaidDate = lastPaidDate;
	}
	/**
	 * @return the lastPaidAmount
	 */
	public String getLastPaidAmount() {
		return lastPaidAmount;
	}
	/**
	 * @param lastPaidAmount the lastPaidAmount to set
	 */
	public void setLastPaidAmount(String lastPaidAmount) {
		this.lastPaidAmount = lastPaidAmount;
	}
	/**
	 * @return the invoiceDue
	 */
	public String getInvoiceDue() {
		return invoiceDue;
	}
	/**
	 * @param invoiceDue the invoiceDue to set
	 */
	public void setInvoiceDue(String invoiceDue) {
		this.invoiceDue = invoiceDue;
	}
	/**
	 * @return the accountNickName
	 */
	public String getAccountNickName() {
		return accountNickName;
	}
	/**
	 * @param accountNickName the accountNickName to set
	 */
	public void setAccountNickName(String accountNickName) {
		this.accountNickName = accountNickName;
	}
	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}
	/**
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	/**
	 * @return the paymentFlag
	 */
	public String getPaymentFlag() {
		return paymentFlag;
	}
	/**
	 * @param paymentFlag the paymentFlag to set
	 */
	public void setPaymentFlag(String paymentFlag) {
		this.paymentFlag = paymentFlag;
	}
	/**
	 * @return the isMaintPermission
	 */
	public String getIsMaintPermission() {
		return isMaintPermission;
	}
	/**
	 * @param isMaintPermission the isMaintPermission to set
	 */
	public void setIsMaintPermission(String isMaintPermission) {
		this.isMaintPermission = isMaintPermission;
	}
	
}
