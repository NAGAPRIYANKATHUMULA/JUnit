package com.bsc.ais.manage.payment.info.services.v1.util;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.UUID;



import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.bsc.aip.core.model.common.atomic.Consumer;
import com.bsc.aip.core.model.common.atomic.Credentials;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.aip.core.model.common.composite.Remarks;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.aip.core.model.common.composite.ResponseHeader;
import com.bsc.aip.core.model.common.composite.TransactionNotification;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * <HTML> This class contains utility methods used in the Fep Integration Service</HTML>.
 *
 * @author Cognizant Technology Solutions
 * @version 1.0
 * 
 */
public class ManagePaymentInfoServiceUtil {
	
	private static final Logger LOGGER = LogManager.getLogger(ManagePaymentInfoServiceUtil.class);

	/**
	 * Returns the ResponseHeader object
	 * @param status
	 * @param statusCode
	 * @param transactionId
	 * @return
	 */
	public static ResponseHeader getResponseHeader(String status, String statusCode, String transactionId) {

		ResponseHeader responseHeader = new ResponseHeader();

		responseHeader.setTransactionNotification(new TransactionNotification());

		responseHeader.getTransactionNotification().setRemarks(new Remarks());

		responseHeader.getTransactionNotification().getRemarks().setMessages(new ArrayList<Message>());

		responseHeader.getTransactionNotification().setStatus(status);

		responseHeader.getTransactionNotification().setStatusCode(statusCode);

		responseHeader.getTransactionNotification().setTransactionId(transactionId);

		responseHeader.getTransactionNotification().setResponseDateTime(new Date());

		return responseHeader;
	}
	
	/**
	 * Populate RequestHeader for an external service call and set the token
	 * 
	 * @param RequestHeader	requestHeader
	 * @param String	token
	 * @return RequestHeader
	 */
	public static RequestHeader processRequestHeader(RequestHeader requestHeader, String token) {

		RequestHeader header = requestHeader;
		if (StringUtils.isEmpty(header.getTransactionId()))
			header.setTransactionId(UUID.randomUUID().toString());
		
		if (header.getConsumer() == null) {
			Consumer consumer = new Consumer();
			header.setConsumer(consumer);
		}
		if (header.getCredentials() == null) {
			Credentials credentials = new Credentials();
			header.setCredentials(credentials);
		}
		header.getConsumer().setName(ManagePaymentInfoServiceConstants.MANAGE_PAYMENT_INFO_SERVICE);
		header.getConsumer().setId(ManagePaymentInfoServiceConstants.CONSUMER_ID);
		header.getConsumer().setBusinessUnit(ManagePaymentInfoServiceConstants.CONSUMER_BUSINESS_UNIT);
		header.getConsumer().setType(ManagePaymentInfoServiceConstants.CONSUMER_TYPE);
		header.getConsumer().setClientVersion(ManagePaymentInfoServiceConstants.CONSUMER_VERSION);
		header.getConsumer().setHostName(ManagePaymentInfoServiceUtil.getServiceHost());
		header.getConsumer().setBusinessTransactionType(ManagePaymentInfoServiceConstants.CONSUMER_BUSINESS_TRANSACTION_TYPE);
		
		header.getCredentials().setType(ManagePaymentInfoServiceConstants.JWT);
		header.getCredentials().setToken(token);

		return header;
	}
	
	/**
	 * Method to build service response header
	 *
	 * @param String	status
	 * @param String	statusCode
	 * @param ResponseHeader	responseHeader
	 * @param List<Message>	message
	 * @return ResponseHeader
	 */
	public static ResponseHeader buildResponse(String status, String statusCode, ResponseHeader responseHeader,
			List<Message> message) {

		if (responseHeader != null) {
			responseHeader.getTransactionNotification().setStatus(status);
			responseHeader.getTransactionNotification().setStatusCode(statusCode);
			responseHeader.getTransactionNotification().setResponseDateTime(new Date());
			responseHeader.getTransactionNotification().getRemarks().getMessages().addAll(message);
		} else {
			responseHeader = new ResponseHeader();
			TransactionNotification transactionNotification = new TransactionNotification();
			transactionNotification.setStatus(status);
			transactionNotification.setStatusCode(statusCode);
			transactionNotification.setResponseDateTime(new Date());
			if (message != null) {
				Remarks remarks = new Remarks();
				remarks.setMessages(message);
				transactionNotification.setRemarks(remarks);
			}
			responseHeader.setTransactionNotification(transactionNotification);
		}
		return responseHeader;
	}
	
	
	/**
	 * Method to process the response of service consumed
	 * @param serviceResponse
	 * @param serviceCalled
	 * @return
	 */
	public static String processSyncResponse(ResponseEntity<String> serviceResponse, String serviceCalled) {

		String responseString = "";
		
		try {

			if (serviceResponse.getStatusCode() != null && serviceResponse.getStatusCode().is2xxSuccessful()) {
				responseString = serviceResponse.getBody();
			}
		} catch (Exception ex) {
			responseString = "";
		}
		return responseString;
	}

	/**
	 * Returns Message object
	 * @param code
	 * @param desc
	 * @param message
	 * @return
	 */
	public static Message getMessage(String code, String desc, String message) {

		Message messageObj = new Message();

		messageObj.setCode(code);

		messageObj.setDescription(desc);

		messageObj.setMessage(message);

		return messageObj;

	}
	
	
	/**
	 * @param value
	 * @return
	 */
	public static String sqlString(String value) {

		if (isNotEmptyOrNull(value)) {
			// check if string is already in SQL format
			if (value.startsWith("'") && value.endsWith("'")) {
				return value;
			}
			value = value.replaceAll("\\P{Print}", "''");
			if (value.contains("&")) {
				value = value.replaceAll("&", "&'||'");
			} else if (value.contains("'")) {
				value = value.replaceAll("'", "''");

			}

		}
		return isNotEmptyOrNull(value) ? "'" + value + "'" : "''";
	}
	
	/**
	 * This method will check an object and if its not empty or null it will
	 * return true.
	 * 
	 * @param obj
	 * @return
	 */
	public static boolean isNotEmptyOrNull(Object obj) {
		boolean isNotEmptyOrNull = false;
		if (obj != null) {
			if (obj instanceof String) {
				if (((String) obj).length() > 0) {
					isNotEmptyOrNull = true;
				}
			} else if (obj instanceof List<?>) {
				if (((List<?>) obj).size() > 0) {
					isNotEmptyOrNull = true;
				}
			} else {
				isNotEmptyOrNull = true;
			}
		}
		return isNotEmptyOrNull;
	}
	/**
	 * <HTML>Method to convert Date to a String format</HTML>
	 * 
	 * @param Date	date
	 * @param String	format
	 * @return String
	 */
	public static String convertDateToString(Date date, String format) {

		String formattedDate = "";

		if (date != null && StringUtils.isNotBlank(format)) {
			try {
				SimpleDateFormat formatter = new SimpleDateFormat(format);
				formattedDate = formatter.format(date);
			} catch (Exception e) {
				// error
			}
		}

		return formattedDate;

	}
	
	/**
	 * <HTML>Method to validate the Date in the specified format</HTML> .
	 *
	 * @param date
	 *            the date
	 * @param format
	 *            the format
	 * @return the string
	 */
	public static boolean isValidDate(String date, String format) {
		if (convertToDate(date, format) != null)
			return true;

		return false;
	}

	/**
	 * Method to convert String to Date based on input format
	 *
	 * @param date
	 * @param format
	 * @return Date
	 */
	public static Date convertToDate(String date, String format) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);

		Date convertedDate = null;
		try {
			convertedDate = dateFormat.parse(date);
		} catch (ParseException e) {
			convertedDate = null;
		}
		return convertedDate;
	}
	
	/**
	 * Converts obj to String
	 * @param obj
	 * @return
	 */
	public static String toJson(Object obj) {
		String jsonString = null;
		if (obj != null) {
			ObjectMapper mapper = new ObjectMapper();
			try {
				return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(obj);
			} catch (JsonProcessingException e) {
				LOGGER.error("Exception occured in toJson() util method" + e.getMessage());
			}
		}
		return jsonString;
	}
	
	/**
	 * Method to get System's Hostname
	 * This method is used to get the system's hostname if it is NULL
	 * 
	 * @param none
	 * @return String
	 */
	public static String getServiceHost() {

		String hostName = null;

		try {
			hostName = InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException ex) {

		}

		return hostName;
	}
	

	/**
	 * Method to create Message.
	 *
	 * @param messages
	 *            the messages
	 * @param code
	 *            the code
	 * @param message
	 *            the message
	 * @param desc
	 *            the desc
	 * @return Message
	 */
	public static void addMessage(List<Message> messages, String code, String message, String desc) {

		Message msg = new Message();
		msg.setCode(code);
		msg.setDescription(desc);
		msg.setMessage(message);
		messages.add(msg);
	}
	
	/**
	 * This method reads resource file based on fileName
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	public static String readResourceFile(String fileName) throws IOException {

		StringBuilder fileContent = new StringBuilder();

		InputStream fileInputStream = null;

		Scanner scanner = null;

		try {

			if (StringUtils.isNotBlank(fileName)) {

				ClassLoader classLoader = ManagePaymentInfoServiceUtil.class.getClassLoader();

				fileInputStream = classLoader.getResourceAsStream(fileName);

				scanner = new Scanner(fileInputStream);

				while (scanner.hasNextLine()) {

					String line = scanner.nextLine();

					fileContent.append(line).append("\n");
				}

				scanner.close();

			}
		} finally {

			if (fileInputStream != null) {
				fileInputStream.close();
			}

			if (scanner != null) {
				scanner.close();
			}

		}

		return fileContent.toString();
	}
	 
	
	public static Date datesAddCalculation(Date startDate, Integer interval) {
		Calendar c1 = Calendar.getInstance();
		c1.setTime(startDate);
		c1.add(Calendar.DATE, interval);

		 c1.set(Calendar.HOUR_OF_DAY, 0);
		 c1.set(Calendar.MINUTE, 0);
		    c1.set(Calendar.SECOND, 0);
	        c1.set(Calendar.MILLISECOND, 0);
		return c1.getTime();
	}
	
	
	/**This method truncate the date part alone and change timestamp in
	 * 00:00:00 format
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public static Date setDateTimestamp(Date startDate) {
		Calendar c1 = Calendar.getInstance();
		c1.setTime(startDate);
        c1.set(Calendar.HOUR_OF_DAY, 0);
	    c1.set(Calendar.MINUTE, 0);
	    c1.set(Calendar.SECOND, 0);
        c1.set(Calendar.MILLISECOND, 0);
		return c1.getTime();
	}
	
	
	/**This method truncate the date part alone and change timestamp in
	 * 00:00:00 format
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public static Date setDateWithTimestamp(Date startDate) {
		Calendar c1 = Calendar.getInstance();
		c1.setTime(startDate);
        c1.set(Calendar.HOUR_OF_DAY, 17);
	    c1.set(Calendar.MINUTE, 30);
	    c1.set(Calendar.SECOND, 0);
        c1.set(Calendar.MILLISECOND, 0);
		return c1.getTime();
	}
	
	/**
	 * This method is used to set the HTTP headers
	 * @param exchange
	 * @param xClientId
	 * @param xClientSecret
	 * @return
	 */
	public static HttpHeaders obtainHttpHeadersInfo(Exchange exchange, String xClientId,String xClientSecret) {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		
		String relayHeader = (String)exchange.getIn().getHeader(ManagePaymentInfoServiceConstants.XBSCAPIAUTH);
		String clientId = (String)exchange.getIn().getHeader(ManagePaymentInfoServiceConstants.XBSCCLIENTID); // request_http_headers.2.authorization	********sanitized********
		String clientSecret = (String)exchange.getIn().getHeader(ManagePaymentInfoServiceConstants.XBSCCLIENTSECRET);
		
		httpHeaders.set(ManagePaymentInfoServiceConstants.AUTHORIZATION, relayHeader); 
		httpHeaders.set(ManagePaymentInfoServiceConstants.XBSCAPIAUTH, relayHeader);
		if(null != clientId){
			httpHeaders.set(ManagePaymentInfoServiceConstants.XCLIENTID, clientId);
			httpHeaders.set(ManagePaymentInfoServiceConstants.XBSCCLIENTID, clientId);
		}else{
			httpHeaders.set(ManagePaymentInfoServiceConstants.XCLIENTID, xClientId);
			httpHeaders.set(ManagePaymentInfoServiceConstants.XBSCCLIENTID, xClientId);
		}
		if(null != clientSecret){
			httpHeaders.set(ManagePaymentInfoServiceConstants.XCLIENTSECRET, clientSecret);
			httpHeaders.set(ManagePaymentInfoServiceConstants.XBSCCLIENTSECRET, clientSecret);
		}else{
			httpHeaders.set(ManagePaymentInfoServiceConstants.XCLIENTSECRET, xClientSecret);
			httpHeaders.set(ManagePaymentInfoServiceConstants.XBSCCLIENTSECRET, xClientSecret);
		}
		return httpHeaders;
	}
	
	/**
	 * This method is used to create the audit event list for audit logging
	 * @param exchange
	 * @param request
	 * @param auditEventList
	 */
	public static void setAuditLogging(Exchange exchange, List<AuditEvent> auditEventList, String eventCode) {
		AuditEvent auditEvent = new AuditEvent();
		auditEvent.setUserIpAddress((String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IP_ADDRESS));
		auditEvent.setSessionId((String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SESSION_ID));
		if ( !(exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME).equals(ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_SET_SERVICE) || 
			exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME).equals(ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_CANCEL_SERVICE))){
		@SuppressWarnings("unchecked")
		List<String> subGroupList = (List<String>)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST);
		if(null != subGroupList && !subGroupList.isEmpty()){
			auditEvent.setGroupSubgroupIdentifier(subGroupList.get(0));
		}
		} else{
		auditEvent.setUserIdentifier((String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER));
	    auditEvent.setGroupIdentifier((String)exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_GROUP_IDENTIIFER));
		}
		auditEvent.setEventCode(eventCode);
		auditEvent.setEventDate(ManagePaymentInfoServiceUtil.convertDateToString(new Date(), ManagePaymentInfoServiceConstants.PORTAL_EVENT_DATE_FORMAT));
		auditEvent.setEventTime(ManagePaymentInfoServiceUtil.convertDateToString(new Date(), ManagePaymentInfoServiceConstants.DATE_TIME_FORMAT));
		auditEventList.add(auditEvent);
	}
	
}