package com.bsc.ais.manage.payment.info.services.v1.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceDBConstants;



@Component("managePaymentInfoServiceDbUtil")
@EnableAsync
public class ManagePaymentInfoServiceDbUtil extends NamedParameterJdbcDaoSupport {
	
	private static final Logger LOGGER = LogManager.getLogger(ManagePaymentInfoServiceDbUtil.class);
	
	private static String VALIDATE_SUB_GROUP_ID_COUNT = null;
	private static String OBTAIN_GET_SCHEDULE_PAYMENT_INFO = null;
	private static String OBTAIN_DISTC_GRP_ID = null;
	private static String OBTAIN_ACTIVE_SUB_GRP = null;
	private static String OBTAIN_EXIST_BANK_ACC_SUB_GRP = null;
	private static String VALID_BILL_INFO_COUNT = null;
	private static String OBTAIN_BILL_INFO = null;
	private static String OBTAIN_BANK_DETAILS = null;
	private static String RETRIEVE_BANK_ACC_INFO = null;
	private static String OBTAIN_GRP_SUB_GRP = null;
	
	static {
		try {
			VALIDATE_SUB_GROUP_ID_COUNT = ManagePaymentInfoServiceUtil.readResourceFile("sql/validateSubGroupIdCount.sql");
			OBTAIN_GET_SCHEDULE_PAYMENT_INFO = ManagePaymentInfoServiceUtil.readResourceFile("sql/getSchedulePaymentInfo.sql");
			OBTAIN_DISTC_GRP_ID = ManagePaymentInfoServiceUtil.readResourceFile("sql/ObtainGroupSubGrpInfo.sql");
			OBTAIN_ACTIVE_SUB_GRP = ManagePaymentInfoServiceUtil.readResourceFile("sql/obtainActiveSubGrp.sql");
			OBTAIN_EXIST_BANK_ACC_SUB_GRP =  ManagePaymentInfoServiceUtil.readResourceFile("sql/obtainExistBankAccSubGrps.sql");
			VALID_BILL_INFO_COUNT =  ManagePaymentInfoServiceUtil.readResourceFile("sql/validateBillingInfoCount.sql");
			OBTAIN_BILL_INFO =  ManagePaymentInfoServiceUtil.readResourceFile("sql/obtainBillingInfoCount.sql");
			OBTAIN_BANK_DETAILS =  ManagePaymentInfoServiceUtil.readResourceFile("sql/obtainBankDetails.sql");
			RETRIEVE_BANK_ACC_INFO =  ManagePaymentInfoServiceUtil.readResourceFile("sql/obtainBankAccountInfo.sql");
			OBTAIN_GRP_SUB_GRP = ManagePaymentInfoServiceUtil.readResourceFile("sql/ObtainGrpSubGrpInfo.sql");
		} catch (IOException ex) {
			LOGGER.error("Exception occured while reading the SQL file.",ex);
		}
	}
	
	
	
	/**
	 * @param groupIdList
	 * @param subGroupIdList
	 * @return
	 */
	@SuppressWarnings("unused")
	public Integer validateSubGroupIdentifierCount(Map<String, List<String>> grpInfoMap) {
       
		String query = VALIDATE_SUB_GROUP_ID_COUNT;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		
		StringBuilder dynamicBuilder = new StringBuilder();
		List<String> subGrpList = new ArrayList<String>();
		
		int count = 0;
		int i = 0;
		for (String groupinfo : grpInfoMap.keySet()) {
			if(count > 0){
				dynamicBuilder.append("  OR ");
			}
			dynamicBuilder.append(" (GRGR.GRGR_ID =:").append(ManagePaymentInfoServiceConstants.GROUP_ID+i);
			paramMap.put(ManagePaymentInfoServiceConstants.GROUP_ID+i, groupinfo);
			
			if( null != grpInfoMap.get(groupinfo)){
				subGrpList = (List<String>) grpInfoMap.get(groupinfo);
				
				int j = 0;
				int maxCount = 1000;
				if (null != subGrpList && !subGrpList.isEmpty()) {
					dynamicBuilder.append(" AND (");
					if (subGrpList.size() > maxCount) {
						int pos1 = 0;
						int pos2 = maxCount;
						int groupIdLstCnt = subGrpList.size();	
						for(String subGrpId: subGrpList){
							if(pos2 == 0){
								break;
							}
							dynamicBuilder.append(" SGSG.SGSG_ID in (:").append(ManagePaymentInfoServiceConstants.SGID_LIST + j);
							dynamicBuilder.append(")");
							if(subGrpList.size() != pos2)
								dynamicBuilder.append(" OR ");
							paramMap.put(ManagePaymentInfoServiceConstants.SGID_LIST+ j, subGrpList.subList(pos1, pos2));
							pos1 = pos2;
							if((groupIdLstCnt -  pos2) >= maxCount){
								pos2 = pos1+ maxCount;
							} else if(groupIdLstCnt -  pos2 > 0 ){
								pos2 = pos1 + (groupIdLstCnt -  pos2);
							} else {
								pos2 = 0;
							}
							j++;
						}
						dynamicBuilder.append(" ))");
					} else {
						dynamicBuilder.append(" SGSG.SGSG_ID IN (:").append(ManagePaymentInfoServiceConstants.SGID_LIST + i);
						paramMap.put(ManagePaymentInfoServiceConstants.SGID_LIST + i, subGrpList);
						dynamicBuilder.append(" )))");
					}
				}
			} 
		   count++;
		   i++;
		}
		dynamicBuilder.append( " )");
		
		query = StringUtils.replace(query, ManagePaymentInfoServiceConstants.DYNAMIC_CONDITIONS, dynamicBuilder.toString());
		
		return getNamedParameterJdbcTemplate().queryForObject(query, paramMap, Integer.class);
	}
	
	/**
	 * @param groupIdList
	 * @param subGroupIdList
	 * @return
	 */
	@SuppressWarnings("unused")
	public List<Map<String, Object>> paymentInfoForGetSchedule(Map<String, List<String>> grpInfoMap) {
       
		String query = OBTAIN_GET_SCHEDULE_PAYMENT_INFO;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		StringBuilder dynamicBuilder = new StringBuilder();
		List<String> subGrpList = new ArrayList<String>();
		
		int count = 0;
		int i = 0;
		for (String groupinfo : grpInfoMap.keySet()) {
			if(count > 0){
				dynamicBuilder.append("  OR ");
			}
			dynamicBuilder.append(" (GRGR.GRGR_ID =:").append(ManagePaymentInfoServiceConstants.GROUP_ID+i);
			paramMap.put(ManagePaymentInfoServiceConstants.GROUP_ID+i, groupinfo);
			
			if( null != grpInfoMap.get(groupinfo)){
				subGrpList = (List<String>) grpInfoMap.get(groupinfo);
				
				int j = 0;
				int maxCount = 1000;
				if (null != subGrpList && !subGrpList.isEmpty()) {
					dynamicBuilder.append(" AND (");
					if (subGrpList.size() > maxCount) {
						int pos1 = 0;
						int pos2 = maxCount;
						int groupIdLstCnt = subGrpList.size();	
						for(String subGrpId: subGrpList){
							if(pos2 == 0){
								break;
							}
							dynamicBuilder.append(" SGSG.SGSG_ID in (:").append(ManagePaymentInfoServiceConstants.SGID_LIST + j);
							dynamicBuilder.append(")");
							if(subGrpList.size() != pos2)
								dynamicBuilder.append(" OR ");
							paramMap.put(ManagePaymentInfoServiceConstants.SGID_LIST+ j, subGrpList.subList(pos1, pos2));
							pos1 = pos2;
							if((groupIdLstCnt -  pos2) >= maxCount){
								pos2 = pos1+ maxCount;
							} else if(groupIdLstCnt -  pos2 > 0 ){
								pos2 = pos1 + (groupIdLstCnt -  pos2);
							} else {
								pos2 = 0;
							}
							j++;
						}
						dynamicBuilder.append(" ))");
					} else {
						dynamicBuilder.append(" SGSG.SGSG_ID IN (:").append(ManagePaymentInfoServiceConstants.SGID_LIST + i);
						paramMap.put(ManagePaymentInfoServiceConstants.SGID_LIST + i, subGrpList);
						dynamicBuilder.append(" )))");
					}
				}
			} 
		   count++;
		   i++;
		}
		dynamicBuilder.append( " )");
		
		query = StringUtils.replace(query, ManagePaymentInfoServiceConstants.DYNAMIC_CONDITIONS, dynamicBuilder.toString());
		
		return getNamedParameterJdbcTemplate().queryForList(query, paramMap);
	}
	
	/**
	 * @param groupIdList
	 * @param subGroupIdList
	 * @return
	 */
	public List<Map<String, Object>> obtainDistGrpId(Map<String, List<String>> grpInfoMap) {
       
		String query = OBTAIN_DISTC_GRP_ID;
     LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		
     StringBuilder dynamicBuilder = new StringBuilder();
		List<String> subGrpList = new ArrayList<String>();
		
		int count = 0;
		int i = 0;
		for (String groupinfo : grpInfoMap.keySet()) {
			if(count > 0){
				dynamicBuilder.append("  OR ");
			}
			dynamicBuilder.append(" (GRGR.GRGR_ID =:").append(ManagePaymentInfoServiceConstants.GROUP_ID+i);
			paramMap.put(ManagePaymentInfoServiceConstants.GROUP_ID+i, groupinfo);
			
			if( null != grpInfoMap.get(groupinfo)){
				subGrpList = (List<String>) grpInfoMap.get(groupinfo);
				
				int j = 0;
				int maxCount = 1000;
				if (null != subGrpList && !subGrpList.isEmpty()) {
					HashSet<String> set = new HashSet<String>();
					set.addAll(subGrpList);
					subGrpList.clear();
					subGrpList.addAll(set);
					dynamicBuilder.append(" AND (");
					if (subGrpList.size() > maxCount) {
						int pos1 = 0;
						int pos2 = maxCount;
						int groupIdLstCnt = subGrpList.size();	
						for(String subGrpId: subGrpList){
							if(pos2 == 0){
								break;
							}
							dynamicBuilder.append(" SGSG.SGSG_ID in (:").append(ManagePaymentInfoServiceConstants.SGID_LIST + j);
							dynamicBuilder.append(")");
							if(subGrpList.size() != pos2)
								dynamicBuilder.append(" OR ");
							paramMap.put(ManagePaymentInfoServiceConstants.SGID_LIST+ j, subGrpList.subList(pos1, pos2));
							pos1 = pos2;
							if((groupIdLstCnt -  pos2) >= maxCount){
								pos2 = pos1+ maxCount;
							} else if(groupIdLstCnt -  pos2 > 0 ){
								pos2 = pos1 + (groupIdLstCnt -  pos2);
							} else {
								pos2 = 0;
							}
							j++;
						}
						dynamicBuilder.append(" ))");
					} else {
						dynamicBuilder.append(" SGSG.SGSG_ID IN (:").append(ManagePaymentInfoServiceConstants.SGID_LIST + i);
						paramMap.put(ManagePaymentInfoServiceConstants.SGID_LIST + i, subGrpList);
						dynamicBuilder.append(" )))");
					}
				}
			} 
		   count++;
		   i++;
		}
		dynamicBuilder.append( " )");
		
		query = StringUtils.replace(query, ManagePaymentInfoServiceConstants.DYNAMIC_CONDITIONS, dynamicBuilder.toString());

		return getNamedParameterJdbcTemplate().queryForList(query, paramMap);
	}
	

	

	/**
	 * @param groupIdList
	 * @param subGroupIdList
	 * @return
	 */
	public List<Map<String, Object>> obtainActSubGrp(String grgrId) {
       
		String query = OBTAIN_ACTIVE_SUB_GRP;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		
		paramMap.put(ManagePaymentInfoServiceConstants.DIST_GRP_ID, grgrId);
		
		return getNamedParameterJdbcTemplate().queryForList(query, paramMap);
	}
	
	
	
	/**
	 * @param groupIdList
	 * @param subGroupIdList
	 * @return
	 */
	public List<Map<String, Object>> obtainGrpSubGrpInfo(String groupId) {
       
		String query = OBTAIN_GRP_SUB_GRP;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		
		paramMap.put(ManagePaymentInfoServiceConstants.EXC_GROUP_IDENTIIFER, groupId);
		
		return getNamedParameterJdbcTemplate().queryForList(query, paramMap);
	}
	
	
	/**
	 * @param groupIdList
	 * @param subGroupIdList
	 * @return
	 */
	public List<Map<String, Object>> validateBankInfoActSubGrp(String grgrId ,  List<String> sgsgIdList) {
       
		String query = OBTAIN_EXIST_BANK_ACC_SUB_GRP;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		
		paramMap.put(ManagePaymentInfoServiceConstants.DIST_GRP_ID, grgrId);
		StringBuilder dynamicBuilder = new StringBuilder();
		int i = 0;
		int maxCount = 1000;
		if (null != sgsgIdList && !sgsgIdList.isEmpty()) {
			if (sgsgIdList.size() > maxCount) {
				dynamicBuilder.append(" (");
				int pos1 = 0;
				int pos2 = maxCount;
				int groupIdLstCnt = sgsgIdList.size();	
				for(String grpId: sgsgIdList){
					if(pos2 == 0){
						break;
					}
					dynamicBuilder.append("  SGSG.SGSG_ID IN (:").append("groupsgIDList" + i);
					dynamicBuilder.append(")");
					if(sgsgIdList.size() != pos2)
						dynamicBuilder.append(" OR ");
					paramMap.put("groupsgIDList" + i, sgsgIdList.subList(pos1, pos2));
					pos1 = pos2;
					if((groupIdLstCnt -  pos2) >= maxCount){
						pos2 = pos1+ maxCount;
					} else if(groupIdLstCnt -  pos2 > 0 ){
						pos2 = pos1 + (groupIdLstCnt -  pos2);
					} else {
						pos2 = 0;
					}
					i++;
				}
				dynamicBuilder.append(" )");
			} else {
				dynamicBuilder.append(" SGSG.SGSG_ID IN (:").append("groupsgIDList");
				paramMap.put("groupsgIDList", sgsgIdList);
				dynamicBuilder.append(" )");
			}
		}
		query = StringUtils.replace(query, ManagePaymentInfoServiceConstants.DYNAMIC_CONDITIONS, dynamicBuilder.toString());
		
		return getNamedParameterJdbcTemplate().queryForList(query, paramMap);
	}
	
	/**
	 * @param groupIdList
	 * @param subGroupIdList
	 * @return
	 */
	public Integer validateBillInfoCount(String grgrId , String sgsgId) {
       
		String query = VALID_BILL_INFO_COUNT;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		
		paramMap.put(ManagePaymentInfoServiceConstants.DIST_GRP_ID, grgrId);
		paramMap.put(ManagePaymentInfoServiceConstants.SGSG_ID, sgsgId);
		
		return getNamedParameterJdbcTemplate().queryForObject(query, paramMap, Integer.class);
	}
	
	/**
	 * @param groupIdList
	 * @param subGroupIdList
	 * @return
	 */
	public String obtainBillInfo(String grgrId , String sgsgId) {
       
		String query = OBTAIN_BILL_INFO;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		
		paramMap.put(ManagePaymentInfoServiceConstants.DIST_GRP_ID, grgrId);
		
		
		paramMap.put(ManagePaymentInfoServiceConstants.SGSG_ID, sgsgId);
		
		return (String) getNamedParameterJdbcTemplate().queryForObject(query, paramMap , String.class);
	}
	
	
	public  int insertQueriesForPayment(List<String> insertStatements) throws Exception {
		int insertCount = 0;
		try {
			String[] sqlArray = insertStatements.toArray(new String[0]);
			int count[] = getJdbcTemplate().batchUpdate(sqlArray);
			insertCount = count.length;
		} catch (Exception ex) {
			LOGGER.error("Exception occured while executing batch update " + ex.getMessage());
			throw new Exception(ex);
		}
		return insertCount;
	}
	/**
	 * @param groupIdList
	 * @param subGroupIdList
	 * @return
	 */
	public List<Map<String, Object>> obtainBankDetails(String grgrId , String sgsgId) {
       
		String query = OBTAIN_BANK_DETAILS;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		
		paramMap.put(ManagePaymentInfoServiceConstants.DIST_GRP_ID, grgrId);
		paramMap.put(ManagePaymentInfoServiceConstants.SGSG_ID, sgsgId);
		
		return getNamedParameterJdbcTemplate().queryForList(query, paramMap);
	}
	
	
	/**
	 * @param groupIdList
	 * @param subGroupIdList
	 * @return
	 */
	public List<Map<String, Object>> paymentInfoForBankAcc(String grgrId, List<String> sgsgIdList) {
       
		String query = RETRIEVE_BANK_ACC_INFO;
		LinkedHashMap<String, Object> paramMap = new LinkedHashMap<String, Object>();
		
		paramMap.put(ManagePaymentInfoServiceConstants.DIST_GRP_ID, grgrId);
		
		StringBuilder dynamicBuilder = new StringBuilder();
		int i = 0;
		int maxCount = 1000;
		if (null != sgsgIdList && !sgsgIdList.isEmpty()) {
			if (sgsgIdList.size() > maxCount) {
				dynamicBuilder.append(" (");
				int pos1 = 0;
				int pos2 = maxCount;
				int groupIdLstCnt = sgsgIdList.size();	
				for(String grpId: sgsgIdList){
					if(pos2 == 0){
						break;
					}
					dynamicBuilder.append("  SGSG.SGSG_ID IN (:").append("groupsgIDList" + i);
					dynamicBuilder.append(")");
					if(sgsgIdList.size() != pos2)
						dynamicBuilder.append(" OR ");
					paramMap.put("groupsgIDList" + i, sgsgIdList.subList(pos1, pos2));
					pos1 = pos2;
					if((groupIdLstCnt -  pos2) >= maxCount){
						pos2 = pos1+ maxCount;
					} else if(groupIdLstCnt -  pos2 > 0 ){
						pos2 = pos1 + (groupIdLstCnt -  pos2);
					} else {
						pos2 = 0;
					}
					i++;
				}
				dynamicBuilder.append(" )");
			} else {
				dynamicBuilder.append(" SGSG.SGSG_ID IN (:").append("groupsgIDList");
				paramMap.put("groupsgIDList", sgsgIdList);
				dynamicBuilder.append(" )");
			}
		}
		query = StringUtils.replace(query, ManagePaymentInfoServiceConstants.DYNAMIC_CONDITIONS, dynamicBuilder.toString());
       
		return getNamedParameterJdbcTemplate().queryForList(query, paramMap);
	}
	
	/**
	 * this method is used to insert new user details into into employer_group_admin_user_hist and employer_group_admin_user table for PRI_CONTC flow
	 * 
	 *
	 */
	public List<String> insertPayment(String bleiCk, List<Map<String, Object>> bankInfoRows) throws Exception {
		List<String> insertStatements = new ArrayList<String>();
		int cnt = 0;
		try {
				
				for(Map<String, Object> bankInfo : bankInfoRows){
				StringBuilder sql = new StringBuilder(ManagePaymentInfoServiceConstants.EMPTY_STR);
				sql.append(ManagePaymentInfoServiceConstants.INSERT).append(ManagePaymentInfoServiceConstants.INTO)
						.append(ManagePaymentInfoServiceConstants.FC_CMC_BLEP_ELEC_PYMT)
						.append(ManagePaymentInfoServiceConstants.VALUES)
						.append(ManagePaymentInfoServiceConstants.OPEN_PARENTHESIS)
						.append(ManagePaymentInfoServiceUtil.sqlString(bleiCk)) // acss_eff_dt
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append("TO_TIMESTAMP(TO_CHAR(TO_DATE('01-JAN-1800') + "+cnt+", 'DD-MON-YYYY') || ' 12.00.00.000000000 AM', 'DD-MON-YYYY HH.MI.SS.FF AM')") // acss_end_dt
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append("TO_TIMESTAMP(TO_CHAR(TO_DATE('01-JAN-1800') + "+cnt+", 'DD-MON-YYYY') || ' 12.00.00.000000000 AM', 'DD-MON-YYYY HH.MI.SS.FF AM')") // usr_role_typ_cd
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString("B")) //grp_blg_unit_num
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString((String) bankInfo.get(ManagePaymentInfoServiceDBConstants.MCBD_ID))) //grp_nbr
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString((String) bankInfo.get(ManagePaymentInfoServiceDBConstants.ACC_NUMBER))) //delgt_usr_id
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString((String) bankInfo.get(ManagePaymentInfoServiceDBConstants.ACC_NAME))) // delgtr_usr_id
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString((String) bankInfo.get(ManagePaymentInfoServiceDBConstants.ACC_TYPE))) // updt_dt
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString("N")) // insrt_usr_id
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceConstants.SYSTIMESTAMP) //insrt_dt
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString("N")) // delgtr_admin_usr_typ_cd
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString("NICK")) // usr_acss_id
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceConstants.TIME_VAL) // actv_btch_log_id
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceConstants.TIME_VAL) // mbr_ss_cd
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString("1")) 
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceConstants.TIME_VAL) 
						.append(ManagePaymentInfoServiceConstants.COLUMN_SEPARATOR)
						.append(ManagePaymentInfoServiceUtil.sqlString(null))
						.append(ManagePaymentInfoServiceConstants.CLOSE_PARENTHESIS);
				cnt++;
				insertStatements.add(sql.toString());
			}
				
			
		}catch (Exception ex) {
			LOGGER.error("Exception occured while executing batch update "+ ex);
			throw new Exception(ex);
		}
		return insertStatements;
	}
	
}
