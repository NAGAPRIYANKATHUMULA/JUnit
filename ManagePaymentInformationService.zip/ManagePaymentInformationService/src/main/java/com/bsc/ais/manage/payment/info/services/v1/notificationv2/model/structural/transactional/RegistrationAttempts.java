/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional;

import java.util.ArrayList;

/**
 * @author Cognizant
 *
 */
public class RegistrationAttempts {
	
	private ArrayList<RegistrationAttempt> registrationAttempt;

	/**
	 * @return the registrationAttempt
	 */
	public ArrayList<RegistrationAttempt> getRegistrationAttempt() {
		return registrationAttempt;
	}

	/**
	 * @param registrationAttempt the registrationAttempt to set
	 */
	public void setRegistrationAttempt(ArrayList<RegistrationAttempt> registrationAttempt) {
		this.registrationAttempt = registrationAttempt;
	}
	
	

}
