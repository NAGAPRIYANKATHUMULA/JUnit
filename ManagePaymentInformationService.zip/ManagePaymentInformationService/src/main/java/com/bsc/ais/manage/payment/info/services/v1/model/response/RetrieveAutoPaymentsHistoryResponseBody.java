package com.bsc.ais.manage.payment.info.services.v1.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class RetrieveAutoPaymentsHistoryResponseBody {

	/** The totalRecordHistoryCount. */
	private String totalRecordHistoryCount;

	/** The Payment History Informations object . */
	private AutoPaymentHistoryInformations autoPaymentHistoryInformations;

	/**
	 * @return the totalRecordHistoryCount
	 */
	public String getTotalRecordHistoryCount() {
		return totalRecordHistoryCount;
	}

	/**
	 * @param totalRecordHistoryCount the totalRecordHistoryCount to set
	 */
	public void setTotalRecordHistoryCount(String totalRecordHistoryCount) {
		this.totalRecordHistoryCount = totalRecordHistoryCount;
	}

	/**
	 * @return the autoPaymentHistoryInformations
	 */
	public AutoPaymentHistoryInformations getAutoPaymentHistoryInformations() {
		return autoPaymentHistoryInformations;
	}

	/**
	 * @param autoPaymentHistoryInformations the autoPaymentHistoryInformations to set
	 */
	public void setAutoPaymentHistoryInformations(AutoPaymentHistoryInformations autoPaymentHistoryInformations) {
		this.autoPaymentHistoryInformations = autoPaymentHistoryInformations;
	}
	
}
