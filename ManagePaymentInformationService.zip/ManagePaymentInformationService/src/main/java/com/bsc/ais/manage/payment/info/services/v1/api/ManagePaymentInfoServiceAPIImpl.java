/*
 * ManagePaymentInfoServiceAPIImpl.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.api;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bsc.aip.core.framewrok.config.AbstractRouteBuilder;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.processor.RetrieveAutoPaymentsServiceAggregationStrategy;
import com.bsc.ais.manage.payment.info.services.v1.rules.ManagePaymentInfoServiceRules;
/**
 * <HTML> This class implements the methods and routes
 * used in the Manage Payment Service </HTML>
 *
 * @author Cognizant Technology Solutions
 * @version 1.0
 *
 */

@Component 
public class ManagePaymentInfoServiceAPIImpl extends AbstractRouteBuilder{ 
 

	@Value("${manage.payment.getschedule.service.api.processor}")
	private String getScheduleServiceRequestProcessor;
	
	@Value("${manage.payment.retrievebankaccountinfo.service.api.processor}")
	private String retrieveBankAccInfoServiceRequestProcessor;
	
	@Value("${manage.subgroups.payment.set.service.api.processor}")
	private String subgroupsPaymentSetServiceRequestProcessor;
	
	@Value("${manage.subgroups.payment.cancel.service.api.processor}")
	private String subgroupsPaymentCancelServiceRequestProcessor;
	
	@Value("${manage.subgroups.set.payment.schedule.service.api.processor}")
	private String subgroupsSetPaymentScheduleRequestProcessor;
	
	@Value("${manage.subgroups.cancel.payment.schedule.service.api.processor}")
	private String subgroupsCancelPaymentScheduleRequestProcessor;	
	
	@Value("${manage.subgroups.batch.payment.schedule.service.api.processor}")
	private String subgroupsBatchPaymentScheduleRequestProcessor;
	
	@Value("${manage.subgroups.bankaccountinfo.set.service.api.processor}")
	private String subgroupsBankAccInfoSetServiceRequestProcessor;
	
	@Value("${manage.subgroups.autopayment.set.service.api.processor}")
	private String subgroupsAutoPaymentSetServiceRequestProcessor;
	
	@Value("${manage.subgroups.autopayment.cancel.service.api.processor}")
	private String subgroupsAutoPaymentCancelServiceRequestProcessor;
	
	@Value("${manage.subgroups.bankaccountinfo.cancel.service.api.processor}")
	private String subgroupsBankAccInfoCancelServiceRequestProcessor;
	
	@Value("${manage.bank.accounts.set.service.api.processor}")
	private String manageBankAccSetServiceRequestProcessor;

	// Retrieve AutoPayments for Groups Service
	@Value("${employers.retrieve.autopayments.service.api.processor}")
	private String retrieveAutoPaymentsServiceRequestProcessor;

	@Value("${manage.bank.accounts.cancel.service.api.processor}")
	private String manageBankAccCancelServiceRequestProcessor;
	
	// Retrieve AutoPayments History Service
	@Value("${employers.retrieve.autopayments.history.service.api.processor}")
	private String retrieveAutoPaymentsHistoryServiceRequestProcessor; 
	
	@Value("${manage.onetime.payment.set.service.api.processor}")
	private String manageOneTimePymtSetServiceRequestProcessor;
	
	@Value("${manage.onetime.payment.cancel.service.api.processor}")
	private String manageOneTimePymtRequestProcessor;
	
	@Value("${manage.onetimepayment.get.service.api.processor}")
	private String manageOnetimePaymentGetServiceRequestProcessor;	

	@Override
	public void configure() throws Exception {
 
		super.configure();
 

		onException(Throwable.class).handled(true)
				.process(ManagePaymentInfoServiceRules.MANAGE_PAYMENT_INFO_SERVICE_ERROR_PROCESSOR);

		// Audit Logging Route
		from("direct:managePaymentInfoPortalAuditLoggingProcessorCall")
				.process(ManagePaymentInfoServiceRules.MANAGE_PAYMENT_INFO_AUDIT_LOGGING_SERVICE_PROCESSOR).end();

		// get schedule service
		from(getScheduleServiceRequestProcessor)
				.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
						simple(ManagePaymentInfoServiceConstants.GET_SCHEDULE_SERVICE))
				.process(ManagePaymentInfoServiceRules.RETRIEVE_PMNT_SERVICE_REQUEST_PROCESSOR)
				.choice()
				.when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
				.process(ManagePaymentInfoServiceRules.GET_SCHEDULE_SERVICE_DATA_PROCESSOR).end()
				.process(ManagePaymentInfoServiceRules.RETRIEVE_PMNT_SERVICE_RESPONSE_PROCESSOR).end();

		// retrieve bank account info
		from(retrieveBankAccInfoServiceRequestProcessor)
				.transacted(ManagePaymentInfoServiceConstants.PROPAGATION_REQUIRES_NEW)
				.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
						simple(ManagePaymentInfoServiceConstants.RETRIEVE_BANK_ACC_INFO_SERVICE))
				.process(ManagePaymentInfoServiceRules.RETRIEVE_PMNT_SERVICE_REQUEST_PROCESSOR)
				.choice()
				.when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
				.process(ManagePaymentInfoServiceRules.RET_BANK_ACC_INFO_SERVICE_DATA_PROCESSOR).choice()
				.when(simple(ManagePaymentInfoServiceRules.UPDATE_DB_FAILED)).markRollbackOnly().end().end()
				.process(ManagePaymentInfoServiceRules.RETRIEVE_PMNT_SERVICE_RESPONSE_PROCESSOR).end();

		// subgroups payment set service
		from(subgroupsPaymentSetServiceRequestProcessor)
				.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
						constant(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SET_SERVICE))
				.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SET_CANCEL_SERVICE_REQUEST_PROCESSOR)
				.choice().when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
				.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SET_CANCEL_SERVICE_PROCESSOR).end()
				.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SET_CANCEL_SERVICE_RESPONSE_PROCESSOR)
				.end();
 
		// subgroups payment cancel service
		from(subgroupsPaymentCancelServiceRequestProcessor)
				.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
						constant(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_CANCEL_SERVICE))
				.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SET_CANCEL_SERVICE_REQUEST_PROCESSOR)
				.choice().when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
				.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SET_CANCEL_SERVICE_PROCESSOR).end()
				.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SET_CANCEL_SERVICE_RESPONSE_PROCESSOR)
				.end();

		from(subgroupsSetPaymentScheduleRequestProcessor)
				.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
						constant(ManagePaymentInfoServiceConstants.SET_PYMNT_SCHED_SERVICE))
				.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SCHEDULE_SERVICE_REQUEST_PROCESSOR)
				.choice().when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
				.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SCHEDULE_SERVICE_PROCESSOR).end()
				.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SCHEDULE__SERVICE_RESPONSE_PROCESSOR)
				.end();

		//schedule auto payment service
		from(subgroupsAutoPaymentSetServiceRequestProcessor)
		.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME, constant(ManagePaymentInfoServiceConstants.CREATE_AUTOPAYMENT_SERVICENAME))
		.process(ManagePaymentInfoServiceConstants.SUBGROUPS_AUTO_PAYMENT_SERVICE_REQUEST_PROCESSOR)
		.choice()
 			.when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
 				.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SCHEDULE_SERVICE_PROCESSOR)
 				.choice().when(simple(ManagePaymentInfoServiceRules.IS_PAYMENT_SCHEDULE_SERVICE_SUCCESS))
					.process(ManagePaymentInfoServiceConstants.AUTOPAYMENT_SEND_EMAIL_SERVICE_PROCESSOR)
					.process(ManagePaymentInfoServiceConstants.INSERT_PAYMENT_HISTORY_LOG_PROCESSOR)
				.end()
 		.end()
		.process(ManagePaymentInfoServiceConstants.SUBGROUPS_AUTO_PAYMENT_SERVICE_RESPONSE_PROCESSOR)
		.end();
		//cancel auto payment service
		from(subgroupsAutoPaymentCancelServiceRequestProcessor)
		.setProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENT_SERVICE_NAME, constant(ManagePaymentInfoServiceConstants.CANCEL_AUTOPAYMENT_SERVICENAME))
		.process(ManagePaymentInfoServiceConstants.SUBGROUPS_AUTO_PAYMENT_SERVICE_REQUEST_PROCESSOR)
		.choice()
 			.when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
 				.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SCHEDULE_SERVICE_PROCESSOR)
 				.choice().when(simple(ManagePaymentInfoServiceRules.IS_PAYMENT_SCHEDULE_SERVICE_SUCCESS))
 					.process(ManagePaymentInfoServiceConstants.AUTOPAYMENT_SEND_EMAIL_SERVICE_PROCESSOR)
 					.process(ManagePaymentInfoServiceConstants.INSERT_PAYMENT_HISTORY_LOG_PROCESSOR)
 				.end()
 		.end()
		.process(ManagePaymentInfoServiceConstants.SUBGROUPS_AUTO_PAYMENT_SERVICE_RESPONSE_PROCESSOR)
		.end();
		

		from(subgroupsCancelPaymentScheduleRequestProcessor)
				.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
						constant(ManagePaymentInfoServiceConstants.CANCEL_PYMNT_SCHED_SERVICE))
				.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SCHEDULE_SERVICE_REQUEST_PROCESSOR)
				.choice().when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
				.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SCHEDULE_SERVICE_PROCESSOR).end()
				.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SCHEDULE__SERVICE_RESPONSE_PROCESSOR)
				.end();


		from(subgroupsBatchPaymentScheduleRequestProcessor)
				.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
						constant(ManagePaymentInfoServiceConstants.BATCH_PYMNT_SCHED_SERVICE))
				.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SCHEDULE_SERVICE_REQUEST_PROCESSOR)
				.choice().when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
				.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SCHEDULE_SERVICE_PROCESSOR).end()
				.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SCHEDULE__SERVICE_RESPONSE_PROCESSOR)
				.end();

		// subgroups bank account info set service
		from(subgroupsBankAccInfoSetServiceRequestProcessor)
				.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
						constant(ManagePaymentInfoServiceConstants.SUBGROUPS_BANK_ACCOUNT_INFO_SET_SERVICE))
				.process(ManagePaymentInfoServiceConstants.BANK_ACCOUNT_INFO_SET_CANCEL_SERVICE_REQUEST_PROCESSOR)
				.choice().when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
				.process(ManagePaymentInfoServiceConstants.BANK_ACCOUNT_INFO_SET_CANCEL_DATA_PROCESSOR).end()
				.process(ManagePaymentInfoServiceConstants.BANK_ACCOUNT_INFO_SET_CANCEL_SERVICE_RESPONSE_PROCESSOR)
				.end();

		// subgroups bank account info cancel service
		from(subgroupsBankAccInfoCancelServiceRequestProcessor)
				.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
						constant(ManagePaymentInfoServiceConstants.SUBGROUPS_BANK_ACCOUNT_INFO_CANCEL_SERVICE))
				.process(ManagePaymentInfoServiceConstants.BANK_ACCOUNT_INFO_SET_CANCEL_SERVICE_REQUEST_PROCESSOR)
				.choice().when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
				.process(ManagePaymentInfoServiceConstants.BANK_ACCOUNT_INFO_SET_CANCEL_DATA_PROCESSOR).end()
				.process(ManagePaymentInfoServiceConstants.BANK_ACCOUNT_INFO_SET_CANCEL_SERVICE_RESPONSE_PROCESSOR)
				.end();

	
		// MANAGE BANK ACCOUNT SET SERVICE
		from(manageBankAccSetServiceRequestProcessor)
				.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
						constant(ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_SET_SERVICE))
				.process(ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_SERVICE_REQUEST_PROCESSOR)
				.choice()
				.when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
				.process(ManagePaymentInfoServiceConstants.BANK_ACCOUNT_INFO_SET_CANCEL_DATA_PROCESSOR)
				.process(ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_SEND_MAIL_PROCESSSOR)
				.end()
				.process(ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_SERVICE_RESPONSE_PROCESSOR).end();
		
		// MANAGE BANK ACCOUNT CANCEL SERVICE
		from(manageBankAccCancelServiceRequestProcessor)
		.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
				constant(ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_CANCEL_SERVICE))
		.process(ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_SERVICE_REQUEST_PROCESSOR)
		.choice()
		.when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
		  .choice()
               .when(simple(ManagePaymentInfoServiceRules.AUTO_CANCEL_CNFRM_SUCCESS))
		          .to("direct:CancelBankAccInfoProcessor")
               .otherwise()
                  .process(ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_CANCEL_DATA_PROCESSOR)
                     .choice()
                     .when(simple(ManagePaymentInfoServiceRules.AUTO_SCHEDULE_AVAIL))
                        .to("direct:CancelBankAccInfoProcessor")
                     .end()
		  .end()
		.end()
		.process(ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_SERVICE_RESPONSE_PROCESSOR).end();
		
		
		// Audit Logging Route
		from("direct:CancelBankAccInfoProcessor")
		.process(ManagePaymentInfoServiceConstants.BANK_ACCOUNT_INFO_SET_CANCEL_DATA_PROCESSOR)
        .process(ManagePaymentInfoServiceConstants.MANAGE_BANK_ACC_SEND_MAIL_PROCESSSOR)
		.end();
		
		//retrieve auto payments for groups service
			from(retrieveAutoPaymentsServiceRequestProcessor)
			.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, simple(ManagePaymentInfoServiceConstants.RETRIEVE_AUTOPAYMENTS_GROUPS_SERVICE))
			.process(ManagePaymentInfoServiceRules.RETRIEVE_AUTOPAYMENTS_SERVICE_REQUEST_PROCESSOR)
			.choice()
		 		.when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
					.process(ManagePaymentInfoServiceRules.RETRIEVE_AUTOPAYMENTS_SERVICE_DATA_PROCESSOR)
					.choice()
						.when(simple(ManagePaymentInfoServiceRules.IS_USERINFO_PRESENT))
							.process(ManagePaymentInfoServiceRules.RETRIEVE_AUTOPAYMENTS_GET_SCHEDULE_PROCESSOR)
							.choice()
								.when(simple(ManagePaymentInfoServiceRules.SCHEDULE_INFO_PRESENT))
									.to("direct:retrieveReceiptsInvoicesDirectRoute")
								.end()	
						.end()
			.process(ManagePaymentInfoServiceRules.RETRIEVE_AUTOPAYMENTS_SERVICE_RESPONSE_PROCESSOR)
			.end();
			
			//route to get retrieve schedule, receipts and invoices info
			from("direct:retrieveReceiptsInvoicesDirectRoute")
			.multicast()
				.aggregationStrategy(new RetrieveAutoPaymentsServiceAggregationStrategy())
				.parallelProcessing()
				.stopOnException()
				.to("direct:retrieveReceipts","direct:retrieveInvoices")
			.end();
			
			from("direct:retrieveReceipts")
				.process(ManagePaymentInfoServiceRules.RETRIEVE_RECEIPTS_FOR_SUBGROUP_PROCESSOR)
			.end();
		
			from("direct:retrieveInvoices")
				.process(ManagePaymentInfoServiceRules.RETRIEVE_INVOICES_FOR_SUBGROUPV2_PROCESSOR)
			.end();
			
			//retrieve auto payments history service
			from(retrieveAutoPaymentsHistoryServiceRequestProcessor)
			.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME, simple(ManagePaymentInfoServiceConstants.RETRIEVE_AUTOPAYMENTS_HISTORY_SERVICE))
			.process(ManagePaymentInfoServiceRules.RETRIEVE_AUTOPAYMENTS_HISTORY_SERVICE_REQUEST_PROCESSOR)
			.choice()
		 		.when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
					.process(ManagePaymentInfoServiceRules.RETRIEVE_AUTOPAYMENTS_HISTORY_SERVICE_DATA_PROCESSOR)
					.choice()
						.when(simple(ManagePaymentInfoServiceRules.IS_HISTORYINFO_PRESENT))
							.process(ManagePaymentInfoServiceRules.RETRIEVE_AUTOPAYMENTS_HISTORY_BANK_ACCOUNT_INFO_PROCESSOR)
						.end()
			.process(ManagePaymentInfoServiceRules.RETRIEVE_AUTOPAYMENTS_HISTORY_SERVICE_RESPONSE_PROCESSOR)
			.end();
			
			
			//manage one time payment set
			from(manageOneTimePymtSetServiceRequestProcessor)
			.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
					constant(ManagePaymentInfoServiceConstants.MANAGE_ONE_TIME_PYMT_SET))
			.process(ManagePaymentInfoServiceConstants.ONE_TIME_PYMT_REQUEST_PROCESSOR)
			.choice()
			.when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
			  .choice()
	               .when(simple(ManagePaymentInfoServiceRules.BANK_ACC_SET_CALL_SUCCESS))
	                  .process(ManagePaymentInfoServiceConstants.BANK_ACCOUNT_INFO_SET_CANCEL_DATA_PROCESSOR)
	                      .choice()
					         .when(simple(ManagePaymentInfoServiceRules.BANK_ACC_SET_RESP_SUCCESS))
	                           .process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SET_CANCEL_SERVICE_PROCESSOR)
	                           .process(ManagePaymentInfoServiceConstants.ONE_TIME_PYMT_MAIL_PROCESSOR)
	                              .choice()
						            .when(simple(ManagePaymentInfoServiceRules.BANK_ACC_CANCEL_CALL))
	                                   .process(ManagePaymentInfoServiceConstants.BANK_ACCOUNT_INFO_SET_CANCEL_DATA_PROCESSOR)
	                             .endChoice()
	                        .endChoice()
	               .otherwise()
	                  .process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SET_CANCEL_SERVICE_PROCESSOR)
	                  .process(ManagePaymentInfoServiceConstants.ONE_TIME_PYMT_MAIL_PROCESSOR)
			  .end()
			.end()
			.process(ManagePaymentInfoServiceConstants.ONE_TIME_PYMT_RESPONSE_PROCESSOR).end();
			
			
			// manage one time payment cancel service
			from(manageOneTimePymtRequestProcessor)
					.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
							constant(ManagePaymentInfoServiceConstants.MANAGE_ONE_TIME_PYMT_CANCEL))
					.process(ManagePaymentInfoServiceConstants.ONE_TIME_PYMT_REQUEST_PROCESSOR)
					.choice()
						.when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
						.process(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SET_CANCEL_SERVICE_PROCESSOR)
						.process(ManagePaymentInfoServiceConstants.ONE_TIME_PYMT_CANCEL_SERVICE_PROCESSOR).end()
					.process(ManagePaymentInfoServiceConstants.ONE_TIME_PYMT_RESPONSE_PROCESSOR)
					.end();
			
			from(manageOnetimePaymentGetServiceRequestProcessor)
			.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,constant(ManagePaymentInfoServiceConstants.ONE_TIME_PAYMENT_GET_SERVICE))
			.process(ManagePaymentInfoServiceConstants.ONE_TIME_PYMT_REQUEST_PROCESSOR)
			.choice()
				.when(simple(ManagePaymentInfoServiceRules.IS_VALIDATION_SUCCESS))
				.process(ManagePaymentInfoServiceConstants.GET_ONE_TIME_PYMT_DATA_PROCESSOR)
				   .choice()
				      .when(simple(ManagePaymentInfoServiceRules.INVOICE_CALL))
				       .process(ManagePaymentInfoServiceConstants.GET_ONE_TIME_PYMT_SERVICE_PROCESSOR)
				   .end()
			.end()
			.process(ManagePaymentInfoServiceConstants.ONE_TIME_PYMT_RESPONSE_PROCESSOR)
		.end();
			
			
			// Security Validation call
		from("direct:empPymtSecurityValidationProcessorCall")
				.process(ManagePaymentInfoServiceRules.EMPLOYERS_SECUITY_VALIDATION_REQUEST_PROCESSOR)
				.choice()
				.when(simple(ManagePaymentInfoServiceRules.IS_CALL_SECURITY_GROUP_VALIDATION))
				.process(ManagePaymentInfoServiceRules.EMPLOYERS_SECUITY_GROUPS_VALIDATION_PROCESSOR)
				.endChoice()
		.end();
			
	}

}