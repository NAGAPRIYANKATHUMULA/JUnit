package com.bsc.ais.manage.payment.info.services.v1.model.transactional;

import com.bsc.aip.core.model.common.composite.ResponseHeader;
import com.bsc.ais.manage.payment.info.services.v1.model.response.RetrievePaymentInfoResponseBody;

/**
 * This is the Patient Accumulator Service Response Pojo
 * @author Cognizant Technology Solutions
 *
 */
public class RetrievePaymentInfoResponse {

	protected ResponseHeader responseHeader;

	private RetrievePaymentInfoResponseBody responseBody = new RetrievePaymentInfoResponseBody();

	/**
	 * 
	 * @return responseHeader
	 */
	public ResponseHeader getResponseHeader() {
		return responseHeader;
	}

	/**
	 * responseHeader to set
	 * @param responseHeader
	 */
	public void setResponseHeader(ResponseHeader responseHeader) {
		this.responseHeader = responseHeader;
	}

	/**
	 * @return the responseBody
	 */
	public RetrievePaymentInfoResponseBody getResponseBody() {
		return responseBody;
	}

	/**
	 * @param responseBody the responseBody to set
	 */
	public void setResponseBody(RetrievePaymentInfoResponseBody responseBody) {
		this.responseBody = responseBody;
	}

}
