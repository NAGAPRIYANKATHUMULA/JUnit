package com.bsc.ais.manage.payment.info.services.v1.rules;


/**
 * <HTML> This class contains the Fep Integration Service rules</HTML>.
 *
 * @author Cognizant Technology Solutions.
 * @version 1.0
 * 
 */
public class ManagePaymentInfoServiceRules {
	
	public static final String MANAGE_PAYMENT_INFO_SERVICE_ERROR_PROCESSOR = "managePaymentInfoServicesErrorProcessor";
	public static final String MANAGE_PAYMENT_INFO_AUDIT_LOGGING_SERVICE_PROCESSOR = "managePaymentInfoPortalAuditLoggingProcessor";
	
	public static final String RETRIEVE_PMNT_SERVICE_REQUEST_PROCESSOR = "retrievePaymentInfoRequestProcessor";
	public static final String GET_SCHEDULE_SERVICE_DATA_PROCESSOR = "getScheduleDataProcessor";
	public static final String RET_BANK_ACC_INFO_SERVICE_DATA_PROCESSOR = "retrieveBankAccInfoDataProcessor";
	public static final String RETRIEVE_PMNT_SERVICE_RESPONSE_PROCESSOR = "retrievePaymentInfoResponseProcessor";
	
	public static final String RETRIEVE_AUTOPAYMENTS_SERVICE_REQUEST_PROCESSOR = "retrieveAutoPaymentsRequestProcessor";
	public static final String RETRIEVE_AUTOPAYMENTS_SERVICE_RESPONSE_PROCESSOR = "retrieveAutoPaymentsResponseProcessor";
	public static final String RETRIEVE_AUTOPAYMENTS_SERVICE_DATA_PROCESSOR = "retrieveAutoPaymentsDataProcessor";
	public static final String RETRIEVE_AUTOPAYMENTS_GET_SCHEDULE_PROCESSOR = "retrieveAutoPaymentsGetScheduleProcessor";
	public static final String RETRIEVE_RECEIPTS_FOR_SUBGROUP_PROCESSOR = "retrieveReceiptsForSubGroupServiceProcessor";
	public static final String RETRIEVE_INVOICES_FOR_SUBGROUPV2_PROCESSOR = "retrieveInvoicesForSubGroupV2ServiceProcessor";
	public static final String IS_USERINFO_PRESENT="${property.isUserInfoPresent} == 'true'";
	public static final String SCHEDULE_INFO_PRESENT ="${property.isGetScheduleServiceSuccess} == 'true'";
	
	public static final String RETRIEVE_AUTOPAYMENTS_HISTORY_SERVICE_REQUEST_PROCESSOR = "retrieveAutoPaymentsHistoryRequestProcessor";
	public static final String RETRIEVE_AUTOPAYMENTS_HISTORY_SERVICE_RESPONSE_PROCESSOR = "retrieveAutoPaymentsHistoryResponseProcessor";
	public static final String RETRIEVE_AUTOPAYMENTS_HISTORY_SERVICE_DATA_PROCESSOR = "retrieveAutoPaymentsHistoryDataProcessor";
	public static final String RETRIEVE_AUTOPAYMENTS_HISTORY_BANK_ACCOUNT_INFO_PROCESSOR = "retrieveAutoPaymentsBankAccountInfoServiceProcessor";
	public static final String IS_HISTORYINFO_PRESENT="${property.isHistoryInfoPresent} == 'true'";
	
	public static final String IS_VALIDATION_SUCCESS = "${property.isValidationSuccess} == 'true'";
	public static final String AUTO_CANCEL_CNFRM_SUCCESS = "${property.excAutoCancel}  == 'true'";
	public static final String AUTO_SCHEDULE_AVAIL = "${property.scheduleAvail}  == 'false'";
	public static final String UPDATE_DB_FAILED = "${property.facetsException} == 'true'";
	public static final String IS_PAYMENT_SCHEDULE_SERVICE_SUCCESS = "${property.isScheduleServiceSuccess} == 'true'";
	
	public static final String BANK_ACC_SET_CALL_SUCCESS = "${property.setBankAccCallSuccess} == 'true'";
	public static final String BANK_ACC_CANCEL_CALL = "${property.cancelBankAccCall} == 'true'";
	public static final String BANK_ACC_SET_RESP_SUCCESS = "${property.setBankSuccessResp} == 'true'";
	public static final String INVOICE_CALL = "${property.invoiceCall} == 'true'";
	
	//security validation changes
    public static final String IS_CALL_SECURITY_VALIDATION = "${property.isCallSecurityValidation} == 'true'";
	
	public static final String EMPLOYERS_SECUITY_VALIDATION_REQUEST_PROCESSOR = "empPymtSecuityValidationRequestProcessor";
	
	public static final String IS_CALL_SECURITY_GROUP_VALIDATION = "${property.isCallSecurityGroupValidation} == 'true'";
	
	public static final String EMPLOYERS_SECUITY_GROUPS_VALIDATION_PROCESSOR = "empPymtSecuityGroupsValidationProcessor";
}
