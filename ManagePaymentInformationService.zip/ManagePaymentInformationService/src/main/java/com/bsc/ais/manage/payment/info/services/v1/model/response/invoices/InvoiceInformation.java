/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.model.response.invoices;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author Cognizant
 *
 */
@JsonInclude(Include.NON_NULL)
public class InvoiceInformation {
	
	private String subgroupIdentifier;
	private String subgroupName;
	private String invoiceID;
	private String invoiceBilledAmount;
	private String invoicePaidAmount;
	private String invoiceDueDate;
	private String invoiceGenerationDate;
	private String invoicePeriodStartDate;
	private String invoicePeriodEndDate;
	private String status;
	private String rebillIndicator;
	private String totalDueAmount;
	private String balance;
	private String previousAmountDue;
	private String netCreditsDebits;
	private String retroactiveAdjustments;
	private String suspenseAmount;
	private String currentCharge;
	private String lastPaidAmmount;
	
	/**
	 * @return the subgroupIdentifier
	 */
	public String getSubgroupIdentifier() {
		return subgroupIdentifier;
	}
	/**
	 * @param subgroupIdentifier the subgroupIdentifier to set
	 */
	public void setSubgroupIdentifier(String subgroupIdentifier) {
		this.subgroupIdentifier = subgroupIdentifier;
	}
	/**
	 * @return the subgroupName
	 */
	public String getSubgroupName() {
		return subgroupName;
	}
	/**
	 * @param subgroupName the subgroupName to set
	 */
	public void setSubgroupName(String subgroupName) {
		this.subgroupName = subgroupName;
	}
	/**
	 * @return the invoiceID
	 */
	public String getInvoiceID() {
		return invoiceID;
	}
	/**
	 * @param invoiceID the invoiceID to set
	 */
	public void setInvoiceID(String invoiceID) {
		this.invoiceID = invoiceID;
	}
	/**
	 * @return the invoiceBilledAmount
	 */
	public String getInvoiceBilledAmount() {
		return invoiceBilledAmount;
	}
	/**
	 * @param invoiceBilledAmount the invoiceBilledAmount to set
	 */
	public void setInvoiceBilledAmount(String invoiceBilledAmount) {
		this.invoiceBilledAmount = invoiceBilledAmount;
	}
	/**
	 * @return the invoicePaidAmount
	 */
	public String getInvoicePaidAmount() {
		return invoicePaidAmount;
	}
	/**
	 * @param invoicePaidAmount the invoicePaidAmount to set
	 */
	public void setInvoicePaidAmount(String invoicePaidAmount) {
		this.invoicePaidAmount = invoicePaidAmount;
	}
	/**
	 * @return the invoiceDueDate
	 */
	public String getInvoiceDueDate() {
		return invoiceDueDate;
	}
	/**
	 * @param invoiceDueDate the invoiceDueDate to set
	 */
	public void setInvoiceDueDate(String invoiceDueDate) {
		this.invoiceDueDate = invoiceDueDate;
	}
	/**
	 * @return the invoiceGenerationDate
	 */
	public String getInvoiceGenerationDate() {
		return invoiceGenerationDate;
	}
	/**
	 * @param invoiceGenerationDate the invoiceGenerationDate to set
	 */
	public void setInvoiceGenerationDate(String invoiceGenerationDate) {
		this.invoiceGenerationDate = invoiceGenerationDate;
	}
	/**
	 * @return the invoicePeriodStartDate
	 */
	public String getInvoicePeriodStartDate() {
		return invoicePeriodStartDate;
	}
	/**
	 * @param invoicePeriodStartDate the invoicePeriodStartDate to set
	 */
	public void setInvoicePeriodStartDate(String invoicePeriodStartDate) {
		this.invoicePeriodStartDate = invoicePeriodStartDate;
	}
	/**
	 * @return the invoicePeriodEndDate
	 */
	public String getInvoicePeriodEndDate() {
		return invoicePeriodEndDate;
	}
	/**
	 * @param invoicePeriodEndDate the invoicePeriodEndDate to set
	 */
	public void setInvoicePeriodEndDate(String invoicePeriodEndDate) {
		this.invoicePeriodEndDate = invoicePeriodEndDate;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the rebillIndicator
	 */
	public String getRebillIndicator() {
		return rebillIndicator;
	}
	/**
	 * @param rebillIndicator the rebillIndicator to set
	 */
	public void setRebillIndicator(String rebillIndicator) {
		this.rebillIndicator = rebillIndicator;
	}
	/**
	 * @return the totalDueAmount
	 */
	public String getTotalDueAmount() {
		return totalDueAmount;
	}
	/**
	 * @param totalDueAmount the totalDueAmount to set
	 */
	public void setTotalDueAmount(String totalDueAmount) {
		this.totalDueAmount = totalDueAmount;
	}
	/**
	 * @return the balance
	 */
	public String getBalance() {
		return balance;
	}
	/**
	 * @param balance the balance to set
	 */
	public void setBalance(String balance) {
		this.balance = balance;
	}
	/**
	 * @return the previousAmountDue
	 */
	public String getPreviousAmountDue() {
		return previousAmountDue;
	}
	/**
	 * @param previousAmountDue the previousAmountDue to set
	 */
	public void setPreviousAmountDue(String previousAmountDue) {
		this.previousAmountDue = previousAmountDue;
	}
	/**
	 * @return the netCreditsDebits
	 */
	public String getNetCreditsDebits() {
		return netCreditsDebits;
	}
	/**
	 * @param netCreditsDebits the netCreditsDebits to set
	 */
	public void setNetCreditsDebits(String netCreditsDebits) {
		this.netCreditsDebits = netCreditsDebits;
	}
	/**
	 * @return the retroactiveAdjustments
	 */
	public String getRetroactiveAdjustments() {
		return retroactiveAdjustments;
	}
	/**
	 * @param retroactiveAdjustments the retroactiveAdjustments to set
	 */
	public void setRetroactiveAdjustments(String retroactiveAdjustments) {
		this.retroactiveAdjustments = retroactiveAdjustments;
	}
	/**
	 * @return the suspenseAmount
	 */
	public String getSuspenseAmount() {
		return suspenseAmount;
	}
	/**
	 * @param suspenseAmount the suspenseAmount to set
	 */
	public void setSuspenseAmount(String suspenseAmount) {
		this.suspenseAmount = suspenseAmount;
	}
	/**
	 * @return the currentCharge
	 */
	public String getCurrentCharge() {
		return currentCharge;
	}
	/**
	 * @param currentCharge the currentCharge to set
	 */
	public void setCurrentCharge(String currentCharge) {
		this.currentCharge = currentCharge;
	}
	/**
	 * @return the lastPaidAmmount
	 */
	public String getLastPaidAmmount() {
		return lastPaidAmmount;
	}
	/**
	 * @param lastPaidAmmount the lastPaidAmmount to set
	 */
	public void setLastPaidAmmount(String lastPaidAmmount) {
		this.lastPaidAmmount = lastPaidAmmount;
	}
}
