/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent;

import com.bsc.aip.core.model.common.composite.RequestHeader;


public class PortalEventsAuditServiceRequest {
	
	private RequestHeader requestHeader;
	
	private PortalEventsAuditRequestBody requestBody;

	public RequestHeader getRequestHeader() {
		return requestHeader;
	}

	public void setRequestHeader(RequestHeader requestHeader) {
		this.requestHeader = requestHeader;
	}

	public PortalEventsAuditRequestBody getRequestBody() {
		return requestBody;
	}

	public void setRequestBody(PortalEventsAuditRequestBody requestBody) {
		this.requestBody = requestBody;
	}
}
