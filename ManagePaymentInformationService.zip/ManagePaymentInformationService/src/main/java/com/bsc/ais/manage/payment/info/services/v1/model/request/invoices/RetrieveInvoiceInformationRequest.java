package com.bsc.ais.manage.payment.info.services.v1.model.request.invoices;

import com.bsc.aip.core.model.common.composite.RequestHeader;

/**
 * This is the Manage Bills and Invoices Service Request Pojo
 * 
 * @author Cognizant Technology Solutions
 *
 */
public class RetrieveInvoiceInformationRequest {

	private RequestHeader requestHeader;

	private RetrieveInvoiceInformationRequestBody requestBody;

	/**
	 * 
	 * @return 
	 */
	public RequestHeader getRequestHeader() {
		return requestHeader;
	}

	/**
	 * requestHeader to set
	 * @param requestHeader
	 */
	public void setRequestHeader(RequestHeader requestHeader) {
		this.requestHeader = requestHeader;
	}

	/**
	 * @return the requestBody
	 */
	public RetrieveInvoiceInformationRequestBody getRequestBody() {
		return requestBody;
	}

	/**
	 * @param requestBody the requestBody to set
	 */
	public void setRequestBody(RetrieveInvoiceInformationRequestBody requestBody) {
		this.requestBody = requestBody;
	}

	

}
