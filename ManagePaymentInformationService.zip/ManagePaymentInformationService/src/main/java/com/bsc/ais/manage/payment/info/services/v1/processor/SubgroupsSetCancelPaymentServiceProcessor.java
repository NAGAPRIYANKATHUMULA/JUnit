/*
 * SubgroupsSetCancelPaymentServiceProcessor.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceDbUtil;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;




/**
 * <HTML> This processor is used for subgroups payment set/cancel.
 * </HTML>.
 *
 * @author Cognizant Technology Solutions.
 * @version 1.0
 * 
 */

@Component()
public class SubgroupsSetCancelPaymentServiceProcessor implements Processor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LogManager.getLogger(SubgroupsSetCancelPaymentServiceProcessor.class);

	/**
	 * Holds the facets database schema name.
	 */
	private static String FACETS_DB_SCHEMA_NAME = ManagePaymentInfoServiceConstants.STRING_FACETS;
	
	/** The event logging. */
	@Resource(name = "eventLogging")
	private EventLogging eventLogging;
	
	@Resource
	private ManagePaymentInfoServiceDbUtil managePaymentInfoServiceDbUtil;
	
	@Value("${jndi.aisfacets.ro}")
	private String facetsLookUpName;
	
	/**
	 * Holds the method name.
	 */
	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";
	

	/*
	 * (non-Javadoc)
	 * 
	 * This method is used to populate the  parameter name and its value to the response object.
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	@SuppressWarnings({ "unchecked", "null" })
	public void process(Exchange exchange) throws Exception {
		
		// Obtain transaction id for logging purpose.
		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_ENTERING + METHOD_PROCESS);
		
		// Obtain the instance of service request
		SubgroupsSetCancelPaymentRequest request = (SubgroupsSetCancelPaymentRequest) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST);
		
		// Obtain an instance of response from exchange object.
		SubgroupsSetCancelPaymentResponse response = (SubgroupsSetCancelPaymentResponse) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
		
		// Obtain an instance of audit list from exchange object.
		List<AuditEvent> auditEventList = (List<AuditEvent>) exchange.getProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST);
		
		// Create an instance of ArrayList to hold response messages. 
		List<Message> messages = new ArrayList<Message>();
		
		// Holds an instance of data source. 
		DataSource facetsDataSource = null;
		// Holds an instance of SQL Connection.
		Connection connection = null;
		// Holds an instance of CallableStatement to call stored procedure.
		CallableStatement stmt = null;
		// Holds an instance of ResultSet.
		ArrayList<String> payInfoArrayList = new ArrayList<String>();		
		String requestType = ManagePaymentInfoServiceConstants.STRING_SCP;
		String activity = null;
		try {
			// Create an instance of InitialContext 
			final Context context = new InitialContext();
			// Perform JNDI lookup to obtain an instance of data source.
			facetsDataSource = (DataSource) context.lookup(facetsLookUpName);
			// Obtain an instance of SQL connection from data source.
	        connection = facetsDataSource.getConnection();
	        
	        // Holds the response code from stored procedure. This is used to determine if the response from stored procedure is success or failure.
			int storedProcedureResponseCode = 0;
			// Holds the response description from stored procedure.
			String storedProcedureResponseDescription = null;
			// checking whether activity set or cancel
			if (exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME).equals(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SET_SERVICE) ||
					exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME).equals(ManagePaymentInfoServiceConstants.MANAGE_ONE_TIME_PYMT_SET)) {
				activity = ManagePaymentInfoServiceConstants.STRING_SET;
			} else {
				activity = ManagePaymentInfoServiceConstants.STRING_CANCEL;
			}
			//iterate paymentInformation object and obtain request data
			if (request.getRequestBody().getPaymentInformations() != null &&
					!request.getRequestBody().getPaymentInformations().getPaymentInformation().isEmpty()) {
				LOGGER.debug(transactionId + " - "+ "iterating paymentInformation object for obtain request data");
				for(PaymentInformation paymentInformation:request.getRequestBody().getPaymentInformations().getPaymentInformation()) {
					String accountNumber = "";
					String subgroupId = "";
					String accountHolderName = "";
					String routingNumber = "";
					String bankAccountType = "";
					String accountNickName = "";
					String paymentAmount = "";
					String paymentData = "";
					
					if (null != paymentInformation.getBankAccountType()) {
						bankAccountType = paymentInformation.getBankAccountType();
					}
					if (null != paymentInformation.getPaymentAmount()) {
						paymentAmount = paymentInformation.getPaymentAmount();
					}
					if (null != paymentInformation.getSubgroupIdentifier()) {
						subgroupId = paymentInformation.getSubgroupIdentifier();
					}
					if (null != paymentInformation.getAccountNickName()) {
						accountNickName = paymentInformation.getAccountNickName();
					}
					// checking account type valid or not
					LOGGER.debug(transactionId + " - "+ "checking whether account type valid or not");
					boolean isValidAcctType = true;
					if(!bankAccountType.equalsIgnoreCase("") && !bankAccountType.equalsIgnoreCase("SAVINGS")&& !bankAccountType.equalsIgnoreCase("CHECKING")) {
						isValidAcctType = false;
					}
					LOGGER.debug(transactionId + " - "+ "isValidAcctType ----"+isValidAcctType);
					
					//checking payment amount value number or not
					LOGGER.debug(transactionId + " - "+ "checking whether payment amount value number or not");
					boolean payAmtCheck = StringUtils.isNumeric(StringUtils.replace(paymentAmount, ".", ""));
					LOGGER.debug(transactionId + " - "+ "isValidPaymentAmount ----"+payAmtCheck);
					//checking service request for set or not
					if (exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME).equals(ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SET_SERVICE) ||
						exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME).equals(ManagePaymentInfoServiceConstants.MANAGE_ONE_TIME_PYMT_SET)) {
						if(payAmtCheck && isValidAcctType) { /*payment amount is a valid number*/
							paymentData = subgroupId  + '|' + paymentAmount + '|' + accountNumber + '|' + accountHolderName + '|' + routingNumber + '|' + bankAccountType + '|' + accountNickName; 
							payInfoArrayList.add(paymentData);							
						}
					} else {
						if((payAmtCheck||paymentAmount.equalsIgnoreCase("")) && isValidAcctType) {
							paymentData = subgroupId + '|' + paymentAmount + '|' + accountNumber + '|' + accountHolderName + '|' + routingNumber + '|' + bankAccountType + '|' + accountNickName; 
							payInfoArrayList.add(paymentData);
						}
					}
					
				}
			}
			//adding paymentInfolist data to payInfoArray
			if (null != payInfoArrayList && !payInfoArrayList.isEmpty()) {
				String[] payInfoArray = new String[payInfoArrayList.size()];;
				for(int i=0; i<payInfoArrayList.size(); i++){
					payInfoArray[i] = payInfoArrayList.get(i);
				}	
			
			// Call stored procedure to sugroups payment set/cancel
			LOGGER.debug(transactionId + " - "+ "call stored procedure - starting");
			stmt = callSubgroupsPaymentSetCancelSp(connection, payInfoArray, requestType, activity);
			LOGGER.debug(transactionId + " - "+ "call stored procedure - ended");
			storedProcedureResponseCode = stmt.getInt(1);
			storedProcedureResponseDescription = stmt.getString(3);
			
			if (storedProcedureResponseCode == 0) {
				LOGGER.debug(transactionId + " - "+ "call stored procedure status - SUCCESS : " + storedProcedureResponseDescription);
				response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.SUCCESS,
						ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE, response.getResponseHeader(), messages));
			} else if (storedProcedureResponseCode == 8) {
				LOGGER.debug(transactionId + " - "+ "call stored procedure status - INVALID REQUEST :" +storedProcedureResponseDescription);
				ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_INVALID_REQUEST,
						ManagePaymentInfoServiceConstants.MSG_INVALID_REQUEST,
						storedProcedureResponseDescription);
			} else if (storedProcedureResponseCode == 4) {
				LOGGER.debug(transactionId + " - "+ "call stored procedure status - TECHNICAL ERROR :" + storedProcedureResponseDescription);
				ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
						ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
						storedProcedureResponseDescription);
			} else {
				LOGGER.debug(transactionId + " - "+ "call stored procedure status - FEASIBILITY ERROR :" + storedProcedureResponseDescription);
				ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_INVALID_REQUEST,
						ManagePaymentInfoServiceConstants.MSG_FEASIBILITY_ERROR,
						storedProcedureResponseDescription);
			}
			
			} else {
				LOGGER.debug(transactionId + " - "+ "payInfoArrayList size is empty");
				ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_INVALID_REQUEST,
						ManagePaymentInfoServiceConstants.MSG_INVALID_REQUEST,
						ManagePaymentInfoServiceConstants.MSG_INVALID_REQUEST);
			}
			
			
			
		}catch (Exception ex) {
			LOGGER.error(transactionId + " - "+ METHOD_PROCESS , ex);
			ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);
			
			//audit logging
			ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.GET_SCHEDULE_EVENT_FAILURE_CODE);
		}
		if (!messages.isEmpty()) {
			for (Message message: messages) {
				if (message.getCode().startsWith("6")){
					response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.WARNING,
							ManagePaymentInfoServiceConstants.WARNING_STATUS_CODE, response.getResponseHeader(), messages));
					LOGGER.debug(transactionId + " - "+ "setting warning message");
				} else {
					response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE,
							ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, response.getResponseHeader(), messages));
				}
			}			
			messages.clear();
		}
		
		
		//set the response to exchange object
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
		exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
		response.setResponseBody(null);
		exchange.getIn().setBody(response);
		
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_EXITING + METHOD_PROCESS);
	}
	/**
	 * This method calls facets stored procedure to obtain subgroup plan information.
	 * @param connection - Holds an instance of Connection
	 * @param payInfoArray - Holds array of paymentInfo passed in request.
	 * @param requestType - Holds the request type.
	 * @param activity - Holds the activity.	 
	 * @return - Instance of CallableStatement with result from stored procedure call.
	 * @throws SQLException
	 */
	private CallableStatement callSubgroupsPaymentSetCancelSp(Connection connection, String[] payInfoArray, String requestType, String activity)
			throws SQLException {
		
		// Unwrap an instance of SQLConnection to obtain raw JDBC connection. This is required for creating custom array object.
        final OracleConnection oracleConn = connection.unwrap(oracle.jdbc.OracleConnection.class);
        
		ArrayDescriptor arrDesc = ArrayDescriptor.createDescriptor(FACETS_DB_SCHEMA_NAME + ".BSCUDT_STRING_ARRAY", oracleConn); 
		ARRAY payInfo = new ARRAY (arrDesc, oracleConn, payInfoArray);;

		CallableStatement stmt = (CallableStatement) connection.prepareCall("{? = call "
			+ FACETS_DB_SCHEMA_NAME + ".bscf_setcncl_pymt_for_subgrp(?,?,?,?,?)}");
		
		stmt.registerOutParameter(1, OracleTypes.NUMBER);
		stmt.registerOutParameter(2, OracleTypes.NUMBER);
		stmt.registerOutParameter(3, OracleTypes.VARCHAR);
		stmt.setString(4, requestType);
		stmt.setString(5,activity);
		stmt.setArray(6,payInfo);
		
		stmt.execute();
		return stmt;
	}
	
}
