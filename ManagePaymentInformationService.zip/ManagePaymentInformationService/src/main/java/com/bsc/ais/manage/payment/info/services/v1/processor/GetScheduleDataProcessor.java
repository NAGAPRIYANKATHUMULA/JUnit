/*
 * GetScheduleDataProcessor.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceDBConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceDbUtil;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;




/**
 * <HTML> This processor is used to get the payment informations from FACETS database
 * </HTML>.
 *
 * @author Cognizant Technology Solutions.
 * @version 1.0
 * 
 */

@Component("getScheduleDataProcessor")
public class GetScheduleDataProcessor implements Processor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LogManager.getLogger(GetScheduleDataProcessor.class);

	/** The event logging. */
	@Resource(name = "eventLogging")
	private EventLogging eventLogging;
	
	@Resource
	private ManagePaymentInfoServiceDbUtil managePaymentInfoServiceDbUtil;
	
	/**
	 * Holds the method name.
	 */
	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";
	

	/*
	 * (non-Javadoc)
	 * 
	 * This method is used to populate the  parameter name and its value to the response object.
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	@SuppressWarnings("unchecked")
	public void process(Exchange exchange) throws Exception {
		
		// Obtain transaction id for logging purpose.
		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_ENTERING + METHOD_PROCESS);
		
		// Obtain an instance of response from exchange object.
		RetrievePaymentInfoResponse response = (RetrievePaymentInfoResponse) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
		
		// Obtain an instance of audit list from exchange object.
		List<AuditEvent> auditEventList = (List<AuditEvent>) exchange.getProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST);
		
		// Create an instance of ArrayList to hold response messages.
		List<Message> messages = new ArrayList<Message>();
		
		Map<String, List<String>> groupInfoMap = (Map<String, List<String>>) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_MAP);
		List<String> subGroupIdentifierList = (List<String>) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST);
		List<PaymentInformation> paymentInformationList = new ArrayList<PaymentInformation>();
		
		try {
			
			//get the count of valid SubGroupIdentifier present in FACETS database
			int count = managePaymentInfoServiceDbUtil.validateSubGroupIdentifierCount(groupInfoMap);
			
			if(count > 0){
				//get the payment information
				List<Map<String, Object>> paymentRows = managePaymentInfoServiceDbUtil.paymentInfoForGetSchedule(groupInfoMap);
				
				if(null != paymentRows && !paymentRows.isEmpty()){
					//iterate and populate the payment Information List
					for(Map<String, Object> row:paymentRows){
						
						//create a instance of PaymentInformation object
						PaymentInformation paymentInformation = new PaymentInformation();
						paymentInformation.setAccountNickName((String)row.get(ManagePaymentInfoServiceDBConstants.ACC_NICK_NAME));
						paymentInformation.setAccountHolderName((String)row.get(ManagePaymentInfoServiceDBConstants.ACC_HOLDER_NAME));
						paymentInformation.setAccountNumber((String)row.get(ManagePaymentInfoServiceDBConstants.ACC_NUMBER));
						paymentInformation.setRoutingNumber((String)row.get(ManagePaymentInfoServiceDBConstants.ROUTING_NUMBER));
						paymentInformation.setBankAccountType((String)row.get(ManagePaymentInfoServiceDBConstants.ACC_TYPE));
						paymentInformation.setPaymentFlag((String)row.get(ManagePaymentInfoServiceDBConstants.PAYMENT_FLAG));
						paymentInformation.setSubgroupIdentifier((String)row.get(ManagePaymentInfoServiceDBConstants.SUB_GROUP_IDEN));
						paymentInformation.setSubgroupName((String)row.get(ManagePaymentInfoServiceDBConstants.SUB_GROUP_NAME));
						//add to paymentInformationList only if SubgroupIdentifier matches is valid and passed in request
						if(subGroupIdentifierList.contains(paymentInformation.getSubgroupIdentifier())){
							paymentInformationList.add(paymentInformation);
						}
					}
				}else{ //no data returned from database
					ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_NO_DATA_FOUND,
							ManagePaymentInfoServiceConstants.MSG_DATA_NOT_FOUND,
							ManagePaymentInfoServiceConstants.MSG_DESC_NO_DATA_FOUND);
					
					LOGGER.debug(transactionId + " - "+ "No matching payment data present for the given list of subGroupIdentifiers");
				}
				
			}else{ //if valid subGroupIdentifier count is not > 0
				ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_SUBGROUP_INVALID,
						ManagePaymentInfoServiceConstants.MSG_DESC_SUBGROUP_INVALID,
						ManagePaymentInfoServiceConstants.MSG_DESC_SUBGROUP_INVALID);
				
				LOGGER.debug(transactionId + " - "+ "Invalid list of subGroupIdentifiers");
				
			}
			
			if (!messages.isEmpty()) {
				response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.WARNING,
						ManagePaymentInfoServiceConstants.WARNING_STATUS_CODE, response.getResponseHeader(), messages));
				messages.clear();
			}
			
		}catch (Exception ex) {
			LOGGER.error(transactionId + " - "+ METHOD_PROCESS , ex);
			ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);
			
			//audit logging
			ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.GET_SCHEDULE_EVENT_FAILURE_CODE);
		}
		
		if (!messages.isEmpty()) {
			response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE,
					ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, response.getResponseHeader(), messages));
		}
		
		//set the response to exchange object
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_PAYMENT_INFO_LIST, paymentInformationList);
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
		exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
		response.setResponseBody(null);
		exchange.getIn().setBody(response);
		
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_EXITING + METHOD_PROCESS);
	}
	
}
