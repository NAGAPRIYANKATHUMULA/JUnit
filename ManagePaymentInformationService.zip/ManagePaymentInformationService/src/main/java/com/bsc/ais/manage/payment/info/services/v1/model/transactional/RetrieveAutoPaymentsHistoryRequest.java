package com.bsc.ais.manage.payment.info.services.v1.model.transactional;

import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.ais.manage.payment.info.services.v1.model.request.RetrieveAutoPaymentsHistoryRequestBody;

/**
 * This is the Retrieve Auto Payments History Request Pojo
 * 
 * @author Cognizant Technology Solutions
 *
 */
public class RetrieveAutoPaymentsHistoryRequest {

	private RequestHeader requestHeader;

	private RetrieveAutoPaymentsHistoryRequestBody requestBody;

	/**
	 * 
	 * @return 
	 */
	public RequestHeader getRequestHeader() {
		return requestHeader;
	}

	/**
	 * requestHeader to set
	 * @param requestHeader
	 */
	public void setRequestHeader(RequestHeader requestHeader) {
		this.requestHeader = requestHeader;
	}

	/**
	 * @return the requestBody
	 */
	public RetrieveAutoPaymentsHistoryRequestBody getRequestBody() {
		return requestBody;
	}

	/**
	 * @param requestBody the requestBody to set
	 */
	public void setRequestBody(RetrieveAutoPaymentsHistoryRequestBody requestBody) {
		this.requestBody = requestBody;
	}


}
