package com.bsc.ais.manage.payment.info.services.v1.constants;

import java.util.ArrayList;
import java.util.List;

/**
 * <HTML> This class contains the Constants required for the Fep Integration Service </HTML>.
 * 
 * @author Cognizant Technology Solutions
 * @version 1.0
 *
 */

public class ManagePaymentInfoServiceConstants {

	public static final String EXC_PROP_IS_VALIDATION_SUCCESS = "isValidationSuccess";
	public static final String STRING_FALSE = "false";
	public static final String STRING_TRUE = "true";
	public static final String STRING_NO = "N";
	public static final String STRING_YES = "Y";
	public static final String STRING_ZERO = "0";
	public static final String TRANSACTION_ID = "transactionId";
	public static final String PORTAL_EVENT_DATE_FORMAT = "yyyy-MM-dd";
	public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss:SSS";
	public static final String AUDIT_EVENT_LIST = "auditEventList";
	public static final String GET_SCHEDULE_SERVICE = "getScheduleService";
	public static final String RETRIEVE_RECEIPTS_FOR_SUBGROUP_SERVICE = "RetrieveReceiptsForSubGroupService";
	public static final String RETRIEVE_INVOICES_FOR_SUBGROUP_SERVICE = "RetrieveInvoicesForSubGroupV2Service";
	public static final String RETRIEVE_BANK_ACC_INFO_SERVICE = "retrieveBankInfoService";
	public static final String MANAGE_PAYMENT_INFO_SERVICE = "ManagePaymentInformationService";
	public static final String AUTHORIZATION= "authorization";
	public static final String XCLIENTID = "x-ibm-client-id";
	public static final String XBSCCLIENTID = "x-bsc-client-id";
	public static final String XCLIENTSECRET = "x-ibm-client-secret";
	public static final String XBSCCLIENTSECRET = "x-bsc-client-secret";
	public static final String XBSCAPIAUTH = "x-bsc-api-auth";
	public static final String PORTAL_AUDIT_LOGGING_SERVICE = "portalAuditEventLoggingService";
	
	public static final String GET_SCHEDULE_EVENT_FAILURE_CODE = "200";
	public static final String GET_SCHEDULE_EVENT_SUCCESS_CODE = "201";
	
	public static final String RETRIEVE_AUTOPAYMENTS_EVENT_FAILURE_CODE = "202";
	public static final String RETRIEVE_AUTOPAYMENTS_EVENT_SUCCESS_CODE = "203";
	
	public static final String RETRIEVE_AUTOPAYMENTS_HISTORY_EVENT_FAILURE_CODE = "204";
	public static final String RETRIEVE_AUTOPAYMENTS_HISTORY_EVENT_SUCCESS_CODE = "205";
	
	public static final String SUCCESS_STATUS_CODE = "0";
	public static final String FAILURE_STATUS_CODE = "1";
	public static final String WARNING_STATUS_CODE ="2";
	
	public static final String CONSUMER_ID = "aip";
	public static final String CONSUMER_BUSINESS_UNIT = "services";
	public static final String CONSUMER_BUSINESS_TRANSACTION_TYPE = "Census";
	public static final String CONSUMER_TYPE = "internal";
	public static final String CONSUMER_VERSION = "v1";
	public static final String JWT = "JWT";

	public static final String EXC_PROP_REQUEST = "request";
	public static final String EXC_PROP_REQ_BODY = "requestBody";
    public static final String EXC_PROP_REQ_HEADER ="requestHeader";
	public static final String EXC_PROP_RESPONSE = "response";
	public static final String EXC_PROP_RESP_HEADER = "responseHeader";
	public static final String EXC_PROP_RESP_BODY = "responseBody";
	
	public static final String EXIT = "EXIT";
	public static final String ENTERING = "Entering {}";
	public static final String EXITING = "Exiting {}";
	public static final String METHOD_EXITING = "Exiting method ";
	public static final String METHOD_ENTERING = "Entering method ";
	public static final String AUDIT = "AUDIT";
	public static final String ENTRY = "ENTRY";
	public static final String CRITICAL = "CRITICAL";
	
	public static final String EXC_PROP_IP_ADDRESS = "ipAddress";
	public static final String EXC_PROP_SESSION_ID = "sessionId";
	public static final String SERVICE_NAME = "serviceName";
	public static final String EXC_PROP_GRGR_ID_LIST = "grgrIdList";
	public static final String EXC_PROP_SGSG_ID_LIST = "sgsgIdList";
	public static final String EXC_PROP_GROUP_MAP = "groupMap";
	public static final String GROUP_ID = "grpId";
	public static final String SUB_GROUP_ID = "subgrpId";
	public static final String SGID_LIST = "sgList";
	public static final String DIST_GRP_ID = "lgrgrid";
	public static final String SGSG_ID = "lsgsgid";
	
	public static final String ACTIVE_SGSG_LIST = "activeSgSGList";
	public static final String EXC_PROP_SUB_GROUP_IDENTIFIER_LIST = "subGroupIdentifierList";
	public static final String EXC_PROP_PAYMENT_INFO_LIST = "paymentInfoList";
	public static final String DYNAMIC_CONDITIONS="--DYNAMIC CONDITIONS--";
	
	public static final String RETRIEVE_AUTOPAYMENTS_GROUPS_SERVICE = "retrieveAutoPaymentsForGroupsService";
	public static final String RETRIEVE_AUTOPAYMENTS_HISTORY_SERVICE = "RetrieveAutoPaymentsHistoryService";
	public static final String EXC_PROP_USER_IDENTIFIER = "userIdentifier";
	public static final String EXC_PROP_GROUP_IDENTIFIER = "groupIdentifier";
	public static final String EXC_PROP_SCHEDULE_NOTIFY_IND ="scheduleNotifyInd";
	public static final String IS_GET_SCHEDULE_SUCCESS="isGetScheduleServiceSuccess";
	public static final String IS_RETRIEVE_RECEIPTS_SUCCESS="isRetrieveReceiptsServiceSuccess";
	public static final String IS_RETRIEVE_INVOICES_SUCCESS="isRetrieveInvoicesServiceSuccess";
	public static final String IS_USERINFO_PRESENT="isUserInfoPresent";
	public static final String PAYMENT_RESPONSE_MAP = "paymentResponseMap";
	public static final String RETRIEVE_RECEIPTS_LIST = "retrieveReceiptsList";
	public static final String REQUEST_TYPE_SG = "SG";
	public static final String CONSUMER_IVR = "IVR";
	public static final String COMPLETED = "Completed";
	public static final String INDEX_ZERO = "0";
	public static final String INDEX_ONE = "1";
	public static final String EXC_PROP_USER_NAME = "userName";
	public static final String EXC_PROP_FROM_DATE = "fromDate";
	public static final String EXC_PROP_TO_DATE = "toDate";
	public static final String EXC_PROP_ACTION = "actionName";
	public static final String EXC_PROP_START_INDEX = "startIndex";
	public static final String EXC_PROP_END_INDEX = "endIndex";
	public static final String IS_HISTORYINFO_PRESENT="isHistoryInfoPresent";
	public static final String EXC_PROP_TOTAL_HISTORY_COUNT = "totalHistoryCount";
	public static final String AUTO_PAYMENTS_HISTORY_INFO_LIST="autoPaymentHistoryInformationList";
	public static final String IS_RETRIEVE_BANK_ACCOUNT_INFO_SUCCESS="isRetrieveBankAccountInfoSuccess";
	public static final String PAYMENT_HISTORY_RESPONSE_MAP = "paymentHistoryResponseMap";
	
	public static final List<String> ACTION_NAME_LIST = new ArrayList<String>();

	static {
		ACTION_NAME_LIST.add("Create");
		ACTION_NAME_LIST.add("Cancel");
		ACTION_NAME_LIST.add("ALL");
	}
	
	public static final String DATE_FORMAT_VALIDATION="dd/MM/yyyy";
	
	public static final String EXC_PROP_GROUP_NAME = "groupName";
	public static final String EXC_PROP_GROUP_SUBGROUP_IDENTIFIER = "groupSubgroupIdentifier";
	public static final String EXC_PROP_SUBGROUP_IDENTIFIER_LIST = "subGroupIdList";
	public static final String EXC_PROP_USERINFO_MAP = "userInfoMap";
	
	public static final String MSG_DESC_MAND_USERIDENTIFIER = "Mandatory Field - userIdentifier is missing in the request";
	public static final String MSG_DESC_MAND_GRP_IDENTIFIER = "Mandatory Field - groupIdentifier is missing in the request";
	public static final String MSG_DESC_MAND_GRP_IDENTIFIER_INVALID = "Mandatory Field - groupIdentifier is invalid in the request";
	public static final String MSG_DESC_MAND_MULTIPLE_GROUP_IDENTIFIER = "Invalid - Multiple groupIdentifier is passed in the request";
	
	public static final String MSG_CODE_USER_DATA_NOT_FOUND = "601";
	public static final String MSG_DESC_USER_DATA_FOUND = "Not a valid user";
	public static final String MSG_USER_DATA_NOT_FOUND = "User Data not found";
	public static final String MSG_HISTORY_DATA_NOT_FOUND = "Auto Payment History Data not found";
	
	public static final String GET_SCHEDULE_SERVICE_ERROR = "Service may not have been able to call Get Schedule Service due to a technical failure.";
	public static final String RETRIEVE_RECEIPTS_SERVICE_ERROR = "Service may not have been able to call Retrieve Receipts for Subgroup service due to a technical failure.";
	public static final String GET_SCHEDULE_SERVICE_FAILED ="Get Schedule Service call failed";
	public static final String MSG_CODE_INVOICE_INVALID_REQUEST = "643";
	public static final String RETRIEVE_RECEIPTS_SERVICE_FAILED ="Retrieve Receipts for Subgroup service call failed";
	public static final String RETRIEVE_INVOICES_SERVICE_FAILED ="Retrieve Invoices for Subgroup service call failed";
	public static final String RETRIEVE_INVOICES_SERVICE_ERROR = "Service may not have been able to call Retrieve Invoices for Subgroup service due to a technical failure.";
	public static final String RETRIEVE_BANK_ACCOUNT_SERVICE_FAILED ="Retrieve Bank Account Info service call failed";
	public static final String RETRIEVE_BANK_ACCOUNT_SERVICE_ERROR = "Service may not have been able to call Retrieve Bank Account Info service due to a technical failure.";
	
	public static final String MSG_DESC_MAND_GROUP_SUB_GROUP_IDENTIFIER = "Mandatory Field - groupSubgroupIdentifier is missing in the request";
	public static final String MSG_DESC_MAND_GROUP_SUB_GROUP_INVALID = "groupSubgroupIdentifier is invalid in the request";
	public static final String MSG_DESC_MAND_USER_IDENTIFIER = "userIdentifier is Mandatory";
	public static final String MSG_DESC_INVALID_START_END_INDEX = "Start and End Index cannot be zero. Pass valid start and end index";
	public static final String MSG_DESC_MAND_FROM_TO_DATE = "fromDate and toDate is mandatory if fields userName,action,groupIdentifier is passed in the request";
	public static final String MSG_DESC_ACTON_INVALID = "action is invalid in the request. Allowed values as Create,Cancel,ALL";
	public static final String MSG_DESC_START_INDEX_INVALID = "startIndex is invalid in the request";
	public static final String MSG_DESC_END_INDEX_INVALID = "endIndex is invalid in the request";
	public static final String MSG_DESC_FROM_DATE_INVALID = "fromDate is invalid in the request. Valid date format is dd/mm/yyyy";
	public static final String MSG_DESC_TO_DATE_INVALID = "toDate is invalid in the request. Valid date format is dd/mm/yyyy";
	
	public static final String FAILURE = "FAILURE";
	public static final String SUCCESS = "SUCCESS";
	public static final String WARNING = "WARNING";
	
	public static final String INVALID_PAYLOAD_ERR_CD = "-1000";
	public static final String MSG_DESC_INVALID_PAYLOAD = "Invalid Payload";

	public static final String MSG_CODE_FORBIDDEN = "403";
	public static final String MSG_FORBIDDEN = "FORBIDDEN";
	public static final String MSG_DESC_FORBIDDEN_HEADER = "Request Header is missing in the request";
	public static final String MSG_DESC_TOKEN = "Mandatory Field token is missing in the request";
	public static final String TOKEN_TYPE = "ID_TOKEN";
	public static final String MSG_DESC_TOKEN_TYPE = "Mandatory Field token type  is missing in the request";
	public static final String MSG_DESC_FORBIDDEN_CREDENTIALS= "One or more following mandatory field is missing in the request header's credentials. Pass token, type";
	public static final String MSG_DESC_FORBIDDEN_CONSUMER = "One or more following mandatory field is missing in the request header's consumer. Pass name, id, type, businessUnit, hostName";
	public static final String MSG_DESC_FORBIDDEN_TRANSACTION_ID = "Please provide transactionId";
	public static final String MSG_DESC_MAND_BUSINESS_REQ_BODY = "Request Body is missing in the request";
	public static final String ERROR_DESCRIPTION_REQ = "Invalid request message structure";
	
	public static final String SUBGROUPS_PAYMENT_SET_SERVICE = "subgroupsPymentSetService";
	public static final String SUBGROUPS_PAYMENT_CANCEL_SERVICE = "subgroupsPymentCancelService";
	public static final String SUBGROUPS_BANK_ACCOUNT_INFO_SET_SERVICE = "subgroupsBankAccInfoSetService";
	public static final String SUBGROUPS_BANK_ACCOUNT_INFO_CANCEL_SERVICE = "subgroupsBankAccInfoCancelService";
	public static final String MANAGE_BANK_ACC_SET_SERVICE = "manageBankAccSetService";
	public static final String SUBGROUPS_PAYMENT_SET_CANCEL_SERVICE_REQUEST_PROCESSOR = "subgroupsSetCancelPaymentRequestProcessor";
	public static final String SUBGROUPS_PAYMENT_SET_CANCEL_SERVICE_RESPONSE_PROCESSOR = "subgroupsSetCancelPaymentResponseProcessor";
	public static final String BANK_ACCOUNT_INFO_SET_CANCEL_SERVICE_REQUEST_PROCESSOR = "setCancelBankAccInfoRequestProcessor";
	public static final String BANK_ACCOUNT_INFO_SET_CANCEL_SERVICE_RESPONSE_PROCESSOR = "setCancelBankAccInfoResponseProcessor";
	public static final String BANK_ACCOUNT_INFO_SET_CANCEL_DATA_PROCESSOR = "setCancelBankAccInfoDataProcessor";
	public static final String SUBGROUPS_PAYMENT_SET_CANCEL_SERVICE_PROCESSOR = "subgroupsSetCancelPaymentServiceProcessor";
	public static final String MSG_DESC_MAND_GROUPID = "Missing/ Incorrect Group ID";
	public static final String MSG_DESC_MAND_SUBGROUPID = "Missing/ Incorrect Sub Group ID";
	public static final String MSG_DESC_MAND_BANKACC_TYPE = "bankAccountType is mandatory";
	public static final String MSG_DESC_MAND_RESTRCT_STATUS = "restrictedStatus is mandatory";
	public static final String MSG_DESC_MAND_ACC_NUMBER = "accountNumber is mandatory";
	public static final String MSG_DESC_MAND_ACC_HOLDER_NAME = "accountHolderName is mandatory";
	public static final String MSG_DESC_MAND_ACC_NICK_NAME = "accountNickName is mandatory";
	public static final String MSG_DESC_MAND_ROUTING_NO = "routingNumber is mandatory";
	public static final String MSG_DESC_MAND_GROUP_IDENTIFIER = "groupIdentifier is mandatory";
	public static final String MSG_DESC_BANKACC_TYPE_INVALID = "bankAccountType is invalid in the request";
	public static final String MSG_DESC_RESTRCT_STATUS_INVALID = "restrictedStatus is invalid in the request";
	public static final String MSG_DESC_GROUP_IDENTIFIER_INVALID = "groupIdentifier is invalid in the request";
	public static final String NO_PAYMENT_INFO = "No payment information in request data";
	public static final String MULTIPLE_BANK_ACC_INFO = "Multiple Bank Account Information passed";
	public static final String MSG_DESC_MAND_PAYMENT_AMT = "Missing/Incorrect paymentAmount";
	public static final String STRING_FACETS = "FACETS_CUSTOM";
	public static final String STRING_SET = "SET";
	public static final String STRING_CANCEL = "CANCEL";
	public static final String STRING_SCP = "SCP";
	public static final String SAVINGS = "SAVINGS";
	public static final String CHECKING = "CHECKING";
	
	public static final String MSG_CODE_INVALID_REQUEST = "601";
	public static final String MSG_INVALID_REQUEST = "Invalid input data";
	public static final String MSG_FEASIBILITY_ERROR = "Feasibility Error occured while calling the stored procedure";
	
	public static final String MSG_CODE_SUBGROUP_INVALID = "601";
	public static final String MSG_DESC_SUBGROUP_INVALID = "Invalid list of SubgroupIdentifier";
	public static final String MSG_CODE_NO_DATA_FOUND = "666";
	public static final String MSG_CODE_SUBGRP_NOT_MATCH = "601";
	public static final String MSG_SUBGRP_NOT_MATCH =  "Sub group Identifiers associated with different parent group are not allowed";
	public static final String MSG_DESC_SUBGRP_NOT_MATCH = "Sub group Identifiers associated with different parent group are not allowed";
	public static final String MSG_DESC_NO_DATA_FOUND = "No Data found for the given input combination";
	public static final String MSG_CODE_NO_SCHEDULE_DATA_FOUND = "602";
	public static final String MSG_DESC_NO_SCHEDULE_DATA_FOUND = "No Schedule Data found for the given input combination";
	public static final String MSG_DATA_NOT_FOUND = "Data not found";
	
	public static final String MSG_CODE_TECH_ERROR= "500";
	public static final String MSG_TECH_ERROR= "INTERNAL SERVER ERROR";
	public static final String TECHNICAL_EXCEPTION = "Technical exception";
	public static final String UNKNOWN_EXCEPTION = "Unknown Runtime exception";
	public static final String MSG_DESC_PAYMENT_SET_TECH_ERROR= "Any technical error while executing stored procedure";
	
	public static final String INSERT = "INSERT ";
	public static final String EQUAL = " = ";
	public static final String INTO = "INTO ";
	public static final String IN = " IN ";
	public static final String TABLE = "TABLE ";
	public static final String VALUES = " VALUES ";
	public static final String SYSDATE = "SYSDATE";
	public static final String SYSTIMESTAMP = "SYSTIMESTAMP";
	public static final String WHERE = " WHERE ";
	public static final String OPEN_PARENTHESIS = "(";
	public static final String CLOSE_PARENTHESIS = ") ";
	public static final String COLUMN_SEPARATOR = ",";
	public static final String EMPTY_STR = "";
	public static final String NULL = "NULL";
	public static final String FC_CMC_BLEP_ELEC_PYMT = "FC_CMC_BLEP_ELEC_PYMT";
	public static final String TIME_VAL = "TO_TIMESTAMP('01-JAN-1753 12.00.00.000000000 AM', 'DD-MON-YYYY HH.MI.SS.FF AM')";
	public static final String PROPAGATION_REQUIRES_NEW = "PROPAGATION_REQUIRES_NEW";
	public static final String FACETS_EXCEPTION = "facetsException";

	public static final String SUBGROUPS_AUTO_PAYMENT_SERVICE_REQUEST_PROCESSOR = "subgroupsAutoPaymentRequestProcessor";
	public static final String SUBGROUPS_AUTO_PAYMENT_SERVICE_RESPONSE_PROCESSOR = "subgroupsAutoPaymentResponseProcessor";	
	public static final String AUTOPAYMENT_SEND_EMAIL_SERVICE_PROCESSOR = "autoPaymentSendEmailServiceProcessor";
	public static final String INSERT_PAYMENT_HISTORY_LOG_PROCESSOR = "insertPamentHistoryLogProcessor";
	

	public static final String EMAIL_SENDING_STATUS_SERVICE_ERROR = "Service may not have been able to send email due to a technical failure";
	public static final String CREATE_AUTOPAYMENT_EMAIL_SUBJECT = "Blue Shield of California Auto Payment scheduled successfully";
	public static final String CANCEL_AUTOPAYMENT_EMAIL_SUBJECT = "Your Auto Payment to Blue Shield of California Has Been Cancelled";
	public static final String CREATE_AUTOPAYMENT_SERVICENAME = "scheduleAutopayment";
	public static final String CANCEL_AUTOPAYMENT_SERVICENAME = "cancelAutopayment";
	public static final String IS_SCHEDULE_SERVICE_SUCCESS = "isScheduleServiceSuccess";
	public static final String EXC_PAYMENT_NOTIFICATION_MSG = "notificationMsg";
	public static final String SCS_MSG_DESC_MAND_PYMT_NOTIFICATION_MSG = "paymentNotificationMsg is mandatory";
	public static final String AUTO_PAYMENT_SERVICE_NAME = "paymentServiceName";
	
	public static final String SUBGROUPS_PAYMENT_SCHEDULE_SERVICE_REQUEST_PROCESSOR = "subgroupsPaymentScheduleRequestProcessor";
	public static final String SUBGROUPS_PAYMENT_SCHEDULE__SERVICE_RESPONSE_PROCESSOR = "subgroupsPaymentScheduleResponseProcessor";
	public static final String SUBGROUPS_PAYMENT_SCHEDULE_SERVICE_PROCESSOR = "subgroupsPaymentScheduleServiceProcessor";
	public static final String SCS_REQUEST_TYPE = "SCS";
	public static final String SCS_BATCH_REQUEST_TYPE = "SCS_B";
	public static final String SET_ACTIVITY_TYPE = "SET";
	public static final String IVR = "IVR";
	public static final String CANCEL_ACTIVITY_TYPE = "CANCEL";
	public static final String BATCH_ACTIVITY_TYPE = "BATCH";
	
	public static final String SET_PYMNT_SCHED_SERVICE = "SET_PYMNT_SCHED_SERVICE";
	public static final String CANCEL_PYMNT_SCHED_SERVICE = "CANCEL_PYMNT_SCHED_SERVICE";
	public static final String BATCH_PYMNT_SCHED_SERVICE = "BATCH_PYMNT_SCHED_SERVICE";
	public static final String SCS_MSG_DESC_MAND_BANKACC_TYPE = "bankAccountType is mandatory and it should have value as either SAVINGS or CHECKING";
	public static final String SCS_MSG_DESC_MAND_PAYMENT_FLAG = "paymentFlag is mandatory and it should have value as either Y or N";	
	public static final String SCS_MSG_DESC_INVALID_AUTO_PAYMENT_EFF_DATE = "autoPaymentEffectiveDate is invalid. Format should be MM/DD/YYYY";
	public static final String SCB_LAST_RUN_DATE_MISSING = "lastRunDate is missing or invalid. Format should be yyyy-MM-dd HH:mm:ss:SSS";
	public static final String SCB_BATCH_ACTIVITY_MISSING = "batchActivity is missing or invalid";
	public static final String SCS_MSG_DESC_MAND_RESTRICTED_STATUS = "restrictedStatus is mandatory and it should have value as either Y or N";
	public static final String SCS_PAYMENT_INFORMATION_MSG = "Please pass atleast one valid set of payment information";
	public static final String MISSING_PAYMENT_INFOMRATION_MSG = "Please pass atleast one valid set of payment information";
	public static final String SCS_BANK_AC_TYPE_SAVINGS = "SAVINGS";
	public static final String SCS_BANK_AC_TYPE_CHECKING = "CHECKING";
	public static final String SCS_MSG_DESC_MAND_ACCOUNT_NICK_NAME = "accountNickname is mandatory";
	
	public static final String MANAGE_BANK_ACC_SERVICE_REQUEST_PROCESSOR = "manageBankAccountsRequestProcessor";
	public static final String MANAGE_BANK_ACC_SERVICE_RESPONSE_PROCESSOR = "manageBankAccountsResponseProcessor";
	public static final String MANAGE_BANK_ACC_SEND_MAIL_PROCESSSOR = "manageBankAccountSendMailProcessor";
	public static final String MANAGE_BANK_ACC_CANCEL_DATA_PROCESSOR = "manageBankAccCancelDataProcessor";
	public static final String MAND_AUTO_CNCEL = "isAutoPaymntCnclCnfrm is mandatory or invalid";

	public static final String SET_BANK_ACC_EVENT_FAILURE_CODE = "200";
	public static final String SET_BANK_ACC_EVENT_SUCCESS_CODE = "201";
	public static final String EXC_USER_IDENTIIFER = "userId";
	public static final String EXC_GROUP_IDENTIIFER = "groupId";
	public static final String EXC_AUTO_PYMT_CNCL_CONFRM = "excAutoCancel";
	public static final String MANAGE_BANK_ACC_CANCEL_SERVICE = "manageBankAccCancelService";
	public static final String NO_EMAIL_INFO = "No email information obj in request";
	public static final String MSG_DESC_MAND_NAME = "name is mandatory";
	public static final String MSG_DESC_MAND_EMAIL_ADDRESS = "email address is mandatory";
	public static final String SEND_EMAIL_SERVICE = "SendEmailService";
	
	public static final String MSG_CODE_EMAIL_SENDING_FAILURE = "608";
	public static final String MSG_DESC_EMAIL_SENDING_FAILURE = "Email Sending Failed";
	public static final String FETCH_EMAIL_INFO_QUERY = "sql:classpath:sql/FetchEmailInfo.sql?dataSource=wpratgr";
	public static final String BANK_ACC_SET_EMAIL_SUBJECT = "Bank Account Created for Blue Shield of California Payments";
	public static final String BANK_ACC_CANCEL_EMAIL_SUBJECT = "Bank Account for Blue Shield of California Payments Deleted";
	public static final String HTML = "Html";
	public static final String TEXT = "Text";
	public static final String IS_SCHEDULE_AVAIL = "scheduleAvail";
	
	//payment history table
	public static final String PAYMENT_ID = "ESS_ADMN.SEQ_PMT_LOG_ID.NEXTVAL";
	public static final String PAYMENT_HISTORY_LOG = "PAYMENT_HISTORY_LOG";
	public static final String MSG_CODE_ACCESS_INVALID = "604";
	public static final String MSG_DESC_SUBGROUP_ACCESS_INVALID = "You do not have the appropriate billing access for all the subgroups associated with this bank account.Please check with your primary contact to get access.";
	
	public static final String MANAGE_ONE_TIME_PYMT_SET = "manageOneTimePymtSet";
	public static final String MANAGE_ONE_TIME_PYMT_CANCEL = "manageOneTimePymtCancel";
	public static final String EXC_SUB_GRP_ID = "excSubGroup";
	public static final String SINGLE_SUB_GRP = "Multiple groupSubgroupIdentifiers information passed";
	public static final String MSG_DEC_PYMT_AMT = "paymentAmount is mandatory";
	public static final String ONE_TIME_PYMT_REQUEST_PROCESSOR = "manageOneTimePymtRequestProcessor";
	public static final String ONE_TIME_PYMT_RESPONSE_PROCESSOR = "manageOneTimePymtResponseProcessor";
	public static final String ONE_TIME_PYMT_MAIL_PROCESSOR = "manageOneTimePymtSendMailProcessor";
	public static final String ONE_TIME_PYMT_CANCEL_SERVICE_PROCESSOR= "manageOnetimePaytCancelServiceProcessor";
	public static final String BANK_ACC_SET_CALL_SUCCESS= "setBankAccCallSuccess";
	public static final String CANCEL_BANK_ACC = "cancelBankAccCall";
	public static final String SET_BANK_ACC_RESPONSE_SUCCESS = "setBankSuccessResp";
	public static final String EMAIL_INFO_EXISTS = "emailInfoExists";
	public static final String ONE_TIME_PYMT_SET_SUB = "Blue Shield of California Payment Confirmation";
	public static final String ONE_TIME_PYMT_CANCEL_EMAIL_SUBJECT = "Your Blue Shield of California Payment Was Cancelled";
	public static final String ONE_TIME_PAYMENT_GET_SERVICE = "OnetimePaymentGetService";
	
	public static final String TM = "TM";
	public static final String Wed = "Wed";
	public static final String Thu = "Thu";
	public static final String Fri = "Fri";
	public static final String SAT= "SAT";
	public static final String MSG_CODE_PYMT_SET_UP_ERR = "601";
	public static final String MSG_CODE_PYMT_SET_UP_WARN = "602"; 
	public static final String MSG_DESC_PYMT_SET_UP_WARN = "The Group is terminated, Please pay your total Amount Due within three business days of cancellation to reinstate your subgroup";
	public static final String MSG_DESC_PYMT_SET_UP_ERR = "The Group is terminated and 3 days grace period is crossed, so payment cannot be set up for sub grp id";
	public static final String MSG_PYMT_SET_UP_ERR = "Grp terminated error";
	public static final String EXC_INVOICE_CALL = "invoiceCall";
	public static final String GET_ONE_TIME_PYMT_SERVICE_PROCESSOR = "getOneTimePymtServiceProcessor";
	public static final String GET_ONE_TIME_PYMT_DATA_PROCESSOR = "getOneTimePymtDataProcessor";
	
	//security validation
	public static final String EMPLOYER_BUSSINESS_UNIT = "Employer";
	public static final String EXC_ID_TOKEN ="excIdToken";
	public static final String EXC_REFRESH_TOKEN ="excRefreshToken";

    public static final String SECURITY_GROUP_VALIDATION = "isCallSecurityGroupValidation";
	public static final String ID_TOKEN = "id_token";
	public static final String MSG_ID_TOKEN_ERROR = "credentials type does not matches to 'id_token' to perform Security Validation.";
	public static final String MSG_INVALID_TOKEN_ERROR = "One or more token/s is invalid to perform Security Validation.";
	public static final String MSG_TECHNICAL_ERROR_SECURITY = "Technical Error ocuured while calling ManageOpenIdConnect Service.";
	public static final String MSG_GROUPS_ERROR_SECURITY = "Technical Error occured while calling Manage openId connect Groups Validation.";
	public static final String GROUP_IDENTIFIER_SET = "GroupIdentifierList";
	public static final String SUB_GROUP_IDENTIFIER_SET = "SubGroupIdentifierList";
	public static final String WARNING_SECURITY_ERROR_CODE = "699";
	public static final String WARNING_INVALID_TOKEN_ERROR_CODE = "698";
	public static final String MSG_SECURITY_VALID = "Security Validation Failed";
	public static final String MSG_DESC_GRP_SUBGRP_ERROR = "Security Validation Failed: UserIdentifier is not associated with groups";
	public static final String NOT_SECURE_SUB_GROUPS_ERROR = "Some SubGroups are not Secure.";
	public static final String OPENID_CONNECT_GROUP_RESPONSE = "OpenIdConnectGroupResponse";
	public static final String GROUPS = "groups";
	public static final String SUB_GROUPS = "subgroups";
	/** The Constant IS_VALIDATION_SUCCESS. */
	public static final String IS_VALID_REQUEST = "isValidRequest";
}

