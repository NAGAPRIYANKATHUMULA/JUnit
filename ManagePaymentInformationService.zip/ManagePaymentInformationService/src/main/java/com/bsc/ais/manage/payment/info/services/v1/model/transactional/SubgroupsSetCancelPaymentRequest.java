package com.bsc.ais.manage.payment.info.services.v1.model.transactional;

import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.ais.manage.payment.info.services.v1.model.request.SubgroupsSetCancelPaymentRequestBody;

/**
 * This is the Patient Accumulator Service Request Pojo
 * 
 * @author Cognizant Technology Solutions
 *
 */
public class SubgroupsSetCancelPaymentRequest {

	private RequestHeader requestHeader;

	private SubgroupsSetCancelPaymentRequestBody requestBody;

	/**
	 * 
	 * @return 
	 */
	public RequestHeader getRequestHeader() {
		return requestHeader;
	}

	/**
	 * requestHeader to set
	 * @param requestHeader
	 */
	public void setRequestHeader(RequestHeader requestHeader) {
		this.requestHeader = requestHeader;
	}

	/**
	 * @return the requestBody
	 */
	public SubgroupsSetCancelPaymentRequestBody getRequestBody() {
		return requestBody;
	}

	/**
	 * @param requestBody the requestBody to set
	 */
	public void setRequestBody(SubgroupsSetCancelPaymentRequestBody requestBody) {
		this.requestBody = requestBody;
	}
	
}
