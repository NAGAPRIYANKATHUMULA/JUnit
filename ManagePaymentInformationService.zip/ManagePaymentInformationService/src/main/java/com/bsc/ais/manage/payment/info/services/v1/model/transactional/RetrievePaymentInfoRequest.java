package com.bsc.ais.manage.payment.info.services.v1.model.transactional;

import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.ais.manage.payment.info.services.v1.model.request.RetrievePaymentInfoRequestBody;

/**
 * This is the Patient Accumulator Service Request Pojo
 * 
 * @author Cognizant Technology Solutions
 *
 */
public class RetrievePaymentInfoRequest {

	private RequestHeader requestHeader;

	private RetrievePaymentInfoRequestBody requestBody;

	/**
	 * 
	 * @return 
	 */
	public RequestHeader getRequestHeader() {
		return requestHeader;
	}

	/**
	 * requestHeader to set
	 * @param requestHeader
	 */
	public void setRequestHeader(RequestHeader requestHeader) {
		this.requestHeader = requestHeader;
	}

	/**
	 * @return the requestBody
	 */
	public RetrievePaymentInfoRequestBody getRequestBody() {
		return requestBody;
	}

	/**
	 * @param requestBody the requestBody to set
	 */
	public void setRequestBody(RetrievePaymentInfoRequestBody requestBody) {
		this.requestBody = requestBody;
	}

	

}
