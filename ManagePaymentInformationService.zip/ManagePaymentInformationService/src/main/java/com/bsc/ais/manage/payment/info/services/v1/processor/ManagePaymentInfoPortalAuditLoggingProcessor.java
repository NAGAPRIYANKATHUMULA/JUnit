/*
 * ManagePaymentInfoPortalAuditLoggingProcessor.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvents;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.PortalEventsAuditRequestBody;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.PortalEventsAuditServiceRequest;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Cognizant Technology Solutions
 *
 */

@Component("managePaymentInfoPortalAuditLoggingProcessor")
public class ManagePaymentInfoPortalAuditLoggingProcessor implements Processor {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LogManager.getLogger(ManagePaymentInfoPortalAuditLoggingProcessor.class);

	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";

	@Value("${manage.payment.info.auditlogging.portalevent.service.url}")
	private String portalAuditEventUri;

	@Value("${manage.payment.info.auditlogging.portalevent.service.jwt.token}")
	private String portalAuditEventToken;
	
	@Value("${manage.payment.info.composite.custom.header.x-ibm-client-id}")
	private String xClientId;
	
	@Value("${manage.payment.info.composite.custom.header.x-ibm-client-secret}")
	private String xClientSecret;

	private static RestTemplate restTemplate = new RestTemplate();

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void process(Exchange exchange) throws Exception {
		
		// Obtain transaction id for logging purpose.
		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		
		LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_ENTERING + METHOD_PROCESS);
		
		// Obtain an instance of audit list from exchange object.
		List<AuditEvent> auditEventList = (List<AuditEvent>) exchange.getProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST);
		
		try {
			//obtain HttpHeaders info
			HttpHeaders httpHeaders = ManagePaymentInfoServiceUtil.obtainHttpHeadersInfo(exchange,xClientId,xClientSecret);
			
			//create instance of ObjectMapper
			ObjectMapper requestMapper = new ObjectMapper();
			
			//create instance of RequestHeader
			RequestHeader requestHeader = new RequestHeader();
			
			HttpEntity<String> requestEntity;
			
			//set the request header info
			requestHeader = ManagePaymentInfoServiceUtil.processRequestHeader(requestHeader, portalAuditEventToken);
			
			PortalEventsAuditServiceRequest auditEventReq = setAuditEventRequest(requestHeader, exchange,auditEventList);
			
			requestEntity = new HttpEntity<String>(requestMapper.writeValueAsString(auditEventReq), httpHeaders);
			LOGGER.debug(transactionId + " - "+ "Audit Logging Request: "+requestEntity);
			ResponseEntity<String> auditEventServiceResp;
			
			// Call audit service .
			auditEventServiceResp = restTemplate.exchange(portalAuditEventUri, HttpMethod.POST, requestEntity,
					String.class);

			if (auditEventServiceResp != null) {
				
				ManagePaymentInfoServiceUtil.processSyncResponse(auditEventServiceResp, ManagePaymentInfoServiceConstants.PORTAL_AUDIT_LOGGING_SERVICE);
				LOGGER.info(transactionId + " - Consumed Portal Audit Logging Service Successfully");
			}
		} catch (Exception ex) {
			LOGGER.error(METHOD_PROCESS + ManagePaymentInfoServiceConstants.MSG_TECH_ERROR + transactionId + " - ", ex);
		}
		LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_EXITING, METHOD_PROCESS);

	}

	
	/** 
	 * This method is to populate the request for Audit Event Logging Service
	 * @param serviceRequestHeader
	 * @param exchange
	 * @param auditEventList
	 * @return
	 */
	private static PortalEventsAuditServiceRequest setAuditEventRequest(RequestHeader serviceRequestHeader,
			Exchange exchange, List<AuditEvent> auditEventList) {
		
		//create instance of Portal Events Audit Service Request
		PortalEventsAuditServiceRequest request = new PortalEventsAuditServiceRequest();
		
		//create instance of Portal Events Audit Service Request Body
		PortalEventsAuditRequestBody requestBody = new PortalEventsAuditRequestBody();
		
		request.setRequestBody(requestBody);
		
		request.setRequestHeader(serviceRequestHeader);
		
		AuditEvents auditEvents = new AuditEvents();
		
		requestBody.setAuditEvents(auditEvents);
		
		auditEvents.setAuditEvent(auditEventList);
		
		return request;
	}

}
