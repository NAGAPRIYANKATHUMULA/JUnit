package com.bsc.ais.manage.payment.info.services.v1.model.request.receipts;

import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupIdentifiers;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RetrieveReceiptsForSubGroupRequestBody {

	private String userIdentifier;
	private String requestType;
	private String requestedStartDate;
	private String requestedEndDate;
	private String receiptPeriod;
	private String startIndex;
	private String endIndex;
	private String[] requestStatus;
	
	private GroupIdentifiers groupIdentifiers;
	
	

	public String getUserIdentifier() {
		return userIdentifier;
	}

	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}

	public GroupIdentifiers getGroupIdentifiers() {
		return groupIdentifiers;
	}

	public void setGroupIdentifiers(GroupIdentifiers groupIdentifiers) {
		this.groupIdentifiers = groupIdentifiers;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getRequestedStartDate() {
		return requestedStartDate;
	}

	public void setRequestedStartDate(String requestedStartDate) {
		this.requestedStartDate = requestedStartDate;
	}

	public String getRequestedEndDate() {
		return requestedEndDate;
	}

	public void setRequestedEndDate(String requestedEndDate) {
		this.requestedEndDate = requestedEndDate;
	}

	public String getReceiptPeriod() {
		return receiptPeriod;
	}

	public void setReceiptPeriod(String receiptPeriod) {
		this.receiptPeriod = receiptPeriod;
	}

	public String getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(String startIndex) {
		this.startIndex = startIndex;
	}

	public String getEndIndex() {
		return endIndex;
	}

	public void setEndIndex(String endIndex) {
		this.endIndex = endIndex;
	}

	public String[] getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String[] requestStatus) {
		this.requestStatus = requestStatus;
	}
	
}
