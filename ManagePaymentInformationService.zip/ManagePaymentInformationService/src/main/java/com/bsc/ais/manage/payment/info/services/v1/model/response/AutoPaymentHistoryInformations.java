/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.model.response;

import java.util.List;

/**
 * @author Cognizant Technology Solutions
 *
 */
public class AutoPaymentHistoryInformations {

	private List<AutoPaymentHistoryInformation> autoPaymentHistoryInformation;

	/**
	 * @return the autoPaymentHistoryInformation
	 */
	public List<AutoPaymentHistoryInformation> getAutoPaymentHistoryInformation() {
		return autoPaymentHistoryInformation;
	}

	/**
	 * @param autoPaymentHistoryInformation the autoPaymentHistoryInformation to set
	 */
	public void setAutoPaymentHistoryInformation(List<AutoPaymentHistoryInformation> autoPaymentHistoryInformation) {
		this.autoPaymentHistoryInformation = autoPaymentHistoryInformation;
	}
	

}
