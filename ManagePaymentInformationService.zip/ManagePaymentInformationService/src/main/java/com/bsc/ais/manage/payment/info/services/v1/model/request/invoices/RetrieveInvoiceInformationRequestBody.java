/*
 * EmployersFetchInvoicesRequestBody.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.model.request.invoices;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * This class contains request body used in Manage Bills and Invoices Service
 * @author Cognizant Technology Solutions
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RetrieveInvoiceInformationRequestBody {

	private String userIdentifier;
	private String requestType;
	private String invoiceIdentifier;
	private String invoicePeriod;
	private String requestedStartDate;
	private String requestedEndDate;
	private String startIndex;
	private String endIndex;
	private String status;
	private SubgroupIdentifiers subgroupIdentifiers;
	private String isInvoiceFilterRequired;
	
	/**
	 * @return the userIdentifier
	 */
	public String getUserIdentifier() {
		return userIdentifier;
	}
	/**
	 * @param userIdentifier the userIdentifier to set
	 */
	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}
	/**
	 * @return the requestType
	 */
	public String getRequestType() {
		return requestType;
	}
	/**
	 * @param requestType the requestType to set
	 */
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	/**
	 * @return the invoiceIdentifier
	 */
	public String getInvoiceIdentifier() {
		return invoiceIdentifier;
	}
	/**
	 * @param invoiceIdentifier the invoiceIdentifier to set
	 */
	public void setInvoiceIdentifier(String invoiceIdentifier) {
		this.invoiceIdentifier = invoiceIdentifier;
	}
	/**
	 * @return the invoicePeriod
	 */
	public String getInvoicePeriod() {
		return invoicePeriod;
	}
	/**
	 * @param invoicePeriod the invoicePeriod to set
	 */
	public void setInvoicePeriod(String invoicePeriod) {
		this.invoicePeriod = invoicePeriod;
	}
	/**
	 * @return the requestedStartDate
	 */
	public String getRequestedStartDate() {
		return requestedStartDate;
	}
	/**
	 * @param requestedStartDate the requestedStartDate to set
	 */
	public void setRequestedStartDate(String requestedStartDate) {
		this.requestedStartDate = requestedStartDate;
	}
	/**
	 * @return the requestedEndDate
	 */
	public String getRequestedEndDate() {
		return requestedEndDate;
	}
	/**
	 * @param requestedEndDate the requestedEndDate to set
	 */
	public void setRequestedEndDate(String requestedEndDate) {
		this.requestedEndDate = requestedEndDate;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the subgroupIdentifiers
	 */
	public SubgroupIdentifiers getSubgroupIdentifiers() {
		return subgroupIdentifiers;
	}
	/**
	 * @param subgroupIdentifiers the subgroupIdentifiers to set
	 */
	public void setSubgroupIdentifiers(SubgroupIdentifiers subgroupIdentifiers) {
		this.subgroupIdentifiers = subgroupIdentifiers;
	}
	/**
	 * @return the startIndex
	 */
	public String getStartIndex() {
		return startIndex;
	}
	/**
	 * @param startIndex the startIndex to set
	 */
	public void setStartIndex(String startIndex) {
		this.startIndex = startIndex;
	}
	/**
	 * @return the endIndex
	 */
	public String getEndIndex() {
		return endIndex;
	}
	/**
	 * @param endIndex the endIndex to set
	 */
	public void setEndIndex(String endIndex) {
		this.endIndex = endIndex;
	}
	/**
	 * @return the isInvoiceFilterRequired
	 */
	public String getIsInvoiceFilterRequired() {
		return isInvoiceFilterRequired;
	}
	/**
	 * @param isInvoiceFilterRequired the isInvoiceFilterRequired to set
	 */
	public void setIsInvoiceFilterRequired(String isInvoiceFilterRequired) {
		this.isInvoiceFilterRequired = isInvoiceFilterRequired;
	}
	
}