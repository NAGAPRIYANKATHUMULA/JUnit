package com.bsc.ais.manage.payment.info.services.v1.model.response.receipts;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import com.bsc.aip.core.model.common.composite.ResponseHeader;

/** 
 * @author Cognizant
**/
@XmlAccessorType(XmlAccessType.FIELD)
public class SubgroupReceiptsResponse {
	private ResponseHeader responseHeader = new ResponseHeader();
	private SubgroupReceiptsResponseBody responseBody ; 
	
	public ResponseHeader getResponseHeader() {
		return responseHeader;
	}

	public void setResponseHeader(ResponseHeader responseHeader) {
		this.responseHeader = responseHeader;
	}

	/**
	 * @return the responseBody
	 */
	public SubgroupReceiptsResponseBody getResponseBody() {
		return responseBody;
	}

	/**
	 * @param responseBody the responseBody to set
	 */
	public void setResponseBody(SubgroupReceiptsResponseBody responseBody) {
		this.responseBody = responseBody;
	}

	

}
