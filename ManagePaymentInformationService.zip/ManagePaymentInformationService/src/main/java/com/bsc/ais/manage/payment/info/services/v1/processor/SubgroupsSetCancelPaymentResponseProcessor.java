/*
 * SubgroupsSetCancelPaymentResponseProcessor.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.List;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.bsc.aip.core.camel.template.BscCamelTemplate;
import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;

/**
 * @author Cognizant
 *
 */
@Component()
public class SubgroupsSetCancelPaymentResponseProcessor implements Processor{
	
	/** The Constant LOGGER. */
	private static final Logger LOGGER = LogManager.getLogger(SubgroupsSetCancelPaymentResponseProcessor.class);
	
	@Resource
	private EventLogging eventLogging;
	
	@Resource(name = "bscCamelTemplate")
	private BscCamelTemplate bscCamelTemplate;
	
	/**
	 * Holds the method name.
	 */
	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";

	@SuppressWarnings("unchecked")
	@Override
	public void process(Exchange exchange) throws Exception {
		
		// Obtain transaction id for logging purpose.
        final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		
		LOGGER.debug(transactionId + " - " +  ManagePaymentInfoServiceConstants.METHOD_ENTERING +  METHOD_PROCESS);
		// Obtain an instance of request from exchange object.
		SubgroupsSetCancelPaymentRequest request = (SubgroupsSetCancelPaymentRequest) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST);
		
		// Obtain an instance of response from exchange object.
		SubgroupsSetCancelPaymentResponse response = (SubgroupsSetCancelPaymentResponse) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
		
		// Obtain an instance of audit list from exchange object.
		List<AuditEvent> auditEventList = (List<AuditEvent>) exchange.getProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST);
		
		//set the final response
		exchange.getIn().setBody(response);
		
		if(null != auditEventList && auditEventList.isEmpty() && null != response && null != response.getResponseHeader() && null != response.getResponseHeader().getTransactionNotification() 
				&& null != response.getResponseHeader().getTransactionNotification().getStatusCode() && response.getResponseHeader().getTransactionNotification().getStatusCode().equalsIgnoreCase(ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE)){
			//audit logging
			ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.GET_SCHEDULE_EVENT_SUCCESS_CODE);
		}
		exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
		
		//consume the audit logging service for WPR Auditing
		if (request.getRequestHeader() != null && null != request.getRequestHeader().getConsumer() && !auditEventList.isEmpty()) {
			 bscCamelTemplate.getProducerTemplate().asyncSend("direct:managePaymentInfoPortalAuditLoggingProcessorCall", exchange);
		}
		
		//consume the event logging service
		if(null != request && null != request.getRequestHeader() && null != response && null != response.getResponseHeader())
		{
			eventLogging.logEvent(request.getRequestHeader(), response.getResponseHeader(), ManagePaymentInfoServiceConstants.AUDIT, ManagePaymentInfoServiceConstants.EXIT, null, null, null,
				null, (String) exchange.getProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME));
		}
		
	    LOGGER.debug(transactionId + " - " + ManagePaymentInfoServiceConstants.METHOD_EXITING + METHOD_PROCESS);
		
		
	}

}
