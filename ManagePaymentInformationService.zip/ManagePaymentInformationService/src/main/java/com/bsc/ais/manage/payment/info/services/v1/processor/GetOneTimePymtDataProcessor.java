/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceDBConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceDbUtil;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;

/**
 * @author 690294
 *
 */
@Component("getOneTimePymtDataProcessor")
public class GetOneTimePymtDataProcessor implements Processor{


	/** The Constant LOGGER. */
	private static final Logger LOGGER = LogManager.getLogger(GetOneTimePymtDataProcessor.class);

	/** The event logging. */
	@Resource(name = "eventLogging")
	private EventLogging eventLogging;
	
	/**
	 * Holds the method name.
	 */
	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";
	
	@Resource
	private ManagePaymentInfoServiceDbUtil managePaymentInfoServiceDbUtil;
	
	private Date cancellationDate;

	/*
	 * (non-Javadoc)
	 * 
	 * This method is used to populate the  parameter name and its value to the response object.
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	@SuppressWarnings("unchecked")
	public void process(Exchange exchange) throws Exception {
		
		// Obtain transaction id for logging purpose.
		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_ENTERING + METHOD_PROCESS);
		
		// Obtain the instance of service request
		SubgroupsSetCancelPaymentRequest request = (SubgroupsSetCancelPaymentRequest) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST);
		// Obtain an instance of response from exchange object.
		SubgroupsSetCancelPaymentResponse response = (SubgroupsSetCancelPaymentResponse) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
		
		// Obtain an instance of audit list from exchange object.
		List<AuditEvent> auditEventList = (List<AuditEvent>) exchange.getProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST);
		
		// Create an instance of ArrayList to hold response messages.
		List<Message> messages = new ArrayList<Message>();
		
		try {

			String groupIdentifier = ((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_SUB_GRP_ID)).substring(0, 8);

	
		//Execute facets to get group status and cancellation date
		List<Map<String, Object>> groupInfoRows = managePaymentInfoServiceDbUtil.obtainGrpSubGrpInfo(groupIdentifier);

		if(null != groupInfoRows && !groupInfoRows.isEmpty()){
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_INVOICE_CALL, ManagePaymentInfoServiceConstants.STRING_TRUE);
			LOGGER.debug(transactionId + " - "+ "group info present in WPR Database.");
			if(null != groupInfoRows.get(0).get(ManagePaymentInfoServiceDBConstants.GRGR_STS) && 
					StringUtils.equalsIgnoreCase(ManagePaymentInfoServiceConstants.TM, (String)groupInfoRows.get(0).get(ManagePaymentInfoServiceDBConstants.GRGR_STS))){
				cancellationDate = (Date) groupInfoRows.get(0).get(ManagePaymentInfoServiceDBConstants.GRGR_TERM_DT);
				Date sysdate = new Date();
				String cancellationDay = new SimpleDateFormat("E").format(cancellationDate);
				if(StringUtils.equalsIgnoreCase(ManagePaymentInfoServiceConstants.Wed, cancellationDay) ||
						StringUtils.equalsIgnoreCase(ManagePaymentInfoServiceConstants.Thu, cancellationDay) ||
						StringUtils.equalsIgnoreCase(ManagePaymentInfoServiceConstants.Fri, cancellationDay)){
					cancellationDate = ManagePaymentInfoServiceUtil.datesAddCalculation(cancellationDate, 5);
				} else if(StringUtils.equalsIgnoreCase(ManagePaymentInfoServiceConstants.SAT, cancellationDay)){
					cancellationDate = ManagePaymentInfoServiceUtil.datesAddCalculation(cancellationDate, 4);
				} else {
					cancellationDate = ManagePaymentInfoServiceUtil.datesAddCalculation(cancellationDate, 3);
				}
				
				if(ManagePaymentInfoServiceUtil.setDateTimestamp(sysdate).after(cancellationDate) || (ManagePaymentInfoServiceUtil.setDateTimestamp(sysdate).equals(cancellationDate)&&
						sysdate.after(ManagePaymentInfoServiceUtil.setDateWithTimestamp(cancellationDate)))){
					ManagePaymentInfoServiceUtil.addMessage(messages,
							ManagePaymentInfoServiceConstants.MSG_CODE_PYMT_SET_UP_ERR,
							ManagePaymentInfoServiceConstants.MSG_PYMT_SET_UP_ERR,
							ManagePaymentInfoServiceConstants.MSG_DESC_PYMT_SET_UP_ERR);
					exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_INVOICE_CALL, ManagePaymentInfoServiceConstants.STRING_FALSE);
				} else{
					ManagePaymentInfoServiceUtil.addMessage(messages,
							ManagePaymentInfoServiceConstants.MSG_CODE_PYMT_SET_UP_WARN,
							ManagePaymentInfoServiceConstants.MSG_DESC_PYMT_SET_UP_WARN,
							ManagePaymentInfoServiceConstants.MSG_DESC_PYMT_SET_UP_WARN);
					exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_INVOICE_CALL, ManagePaymentInfoServiceConstants.STRING_TRUE);
				}
			}
			
		}else{
				LOGGER.debug(transactionId + " - "+ "schedule Notify Indicator is not available in WPR Database.");
				ManagePaymentInfoServiceUtil.addMessage(messages,
						ManagePaymentInfoServiceConstants.MSG_CODE_NO_DATA_FOUND,
						ManagePaymentInfoServiceConstants.MSG_DATA_NOT_FOUND,
						ManagePaymentInfoServiceConstants.MSG_DATA_NOT_FOUND);
				//audit logging
				ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.SET_BANK_ACC_EVENT_FAILURE_CODE);
			}
		
		
		if (!messages.isEmpty()) {
			response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.WARNING,
					ManagePaymentInfoServiceConstants.WARNING_STATUS_CODE, response.getResponseHeader(), messages));
			messages.clear();
		}
		
		
		}catch (Exception ex) {
			LOGGER.error(transactionId + " - "+ METHOD_PROCESS , ex);
			ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
					ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);
			
			//audit logging
			ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.SET_BANK_ACC_EVENT_FAILURE_CODE);
		}
		
		if (!messages.isEmpty()) {
			response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE,
					ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, response.getResponseHeader(), messages));
		}
		
		//set the response to exchange object
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
		exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
		response.setResponseBody(null);
		exchange.getIn().setBody(response);
		
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_EXITING + METHOD_PROCESS);
	}
	


}
