/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.model.response;

import java.util.List;

/**
 * @author Cognizant Technology Solutions
 *
 */
public class PaymentInformations {

	private List<PaymentInformation> paymentInformation;

	public List<PaymentInformation> getPaymentInformation() {
		return paymentInformation;
	}

	public void setPaymentInformation(List<PaymentInformation> paymentInformation) {
		this.paymentInformation = paymentInformation;
	}
	
}
