/*
 * GroupIdentifier.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */

package com.bsc.ais.manage.payment.info.services.v1.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * The Class GroupIdentifier.
 *
 * @author Cognizant Technology Solutions
 * @version 1.0
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GroupIdentifier {

	/** The group name. */
	private String groupName;

	/** The group identifier. */
	private String groupIdentifier;

	/** The group subgroups. */
	private GroupSubgroups groupSubgroups;

	/**
	 * Gets the group name.
	 *
	 * @return the group name
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * Sets the group name.
	 *
	 * @param groupName the new group name
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/**
	 * Gets the group identifier.
	 *
	 * @return the group identifier
	 */
	public String getGroupIdentifier() {
		return groupIdentifier;
	}

	/**
	 * Sets the group identifier.
	 *
	 * @param groupIdentifier the new group identifier
	 */
	public void setGroupIdentifier(String groupIdentifier) {
		this.groupIdentifier = groupIdentifier;
	}

	/**
	 * Gets the group subgroups.
	 *
	 * @return the group subgroups
	 */
	public GroupSubgroups getGroupSubgroups() {
		return groupSubgroups;
	}

	/**
	 * Sets the group subgroups.
	 *
	 * @param groupSubgroups the new group subgroups
	 */
	public void setGroupSubgroups(GroupSubgroups groupSubgroups) {
		this.groupSubgroups = groupSubgroups;
	}

}
