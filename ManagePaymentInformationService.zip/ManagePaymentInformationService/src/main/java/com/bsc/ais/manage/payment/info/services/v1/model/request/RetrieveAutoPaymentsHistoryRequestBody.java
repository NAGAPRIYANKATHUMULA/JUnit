/* RetrieveAutoPaymentsHistoryRequestBody.java
 *
 * <BSC_COPYRIGHT_NOTICE>
 * This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited.
 * All rights reserved
 * Copyright (c) 2016
 * </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * <HTML> This is the POJO object that holds the attributes for the UserInfo
 * data</HTML>.
 *
 * @author Cognizant Technology Solutions
 * @version 1.0
 * 
 * 
 */
@JsonIgnoreProperties (ignoreUnknown = true)
public class RetrieveAutoPaymentsHistoryRequestBody {

	/** The User id. */
	private String userIdentifier;
	private String userName;
	private String fromDate;
	private String toDate;
	private String action;
	private String startIndex;
	private String endIndex;

	private GroupIdentifiers groupIdentifiers;

	/**
	 * @return the userIdentifier
	 */
	public String getUserIdentifier() {
		return userIdentifier;
	}

	/**
	 * @param userIdentifier the userIdentifier to set
	 */
	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}

	
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the fromDate
	 */
	public String getFromDate() {
		return fromDate;
	}

	/**
	 * @param fromDate the fromDate to set
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * @return the toDate
	 */
	public String getToDate() {
		return toDate;
	}

	/**
	 * @param toDate the toDate to set
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}

	/**
	 * @return the startIndex
	 */
	public String getStartIndex() {
		return startIndex;
	}

	/**
	 * @param startIndex the startIndex to set
	 */
	public void setStartIndex(String startIndex) {
		this.startIndex = startIndex;
	}

	/**
	 * @return the endIndex
	 */
	public String getEndIndex() {
		return endIndex;
	}

	/**
	 * @param endIndex the endIndex to set
	 */
	public void setEndIndex(String endIndex) {
		this.endIndex = endIndex;
	}

	/**
	 * @return the groupIdentifiers
	 */
	public GroupIdentifiers getGroupIdentifiers() {
		return groupIdentifiers;
	}

	/**
	 * @param groupIdentifiers the groupIdentifiers to set
	 */
	public void setGroupIdentifiers(GroupIdentifiers groupIdentifiers) {
		this.groupIdentifiers = groupIdentifiers;
	}
	
	
}
