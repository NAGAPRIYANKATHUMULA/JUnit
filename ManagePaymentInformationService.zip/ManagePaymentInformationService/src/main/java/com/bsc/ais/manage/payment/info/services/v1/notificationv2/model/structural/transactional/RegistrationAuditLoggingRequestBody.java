package com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RegistrationAuditLoggingRequestBody {
	
	private RegistrationAttempts registrationAttempts;

	/**
	 * @return the registrationAttempts
	 */
	public RegistrationAttempts getRegistrationAttempts() {
		return registrationAttempts;
	}

	/**
	 * @param registrationAttempts the registrationAttempts to set
	 */
	public void setRegistrationAttempts(RegistrationAttempts registrationAttempts) {
		this.registrationAttempts = registrationAttempts;
	}
	

}
