/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional;

/**
 * @author Cognizant
 *
 */
public class RegistrationAttempt {
	
	private String groupSubgroupIdentifier;
	private String  emailAddress;
	private String  firstName;
	private String  lastName;
	private String  failedReasonDescription;
	private String  memberSourceSystemCode;
	private String  insertUserIdentifier;
	private String  registrationAttempts;
	private String  isBenefitFocus;
	private String  isActivationEmailSent;
	private String  groupName;
	private String  eventTypeCode;
	
	
	/**
	 * @return the registrationAttempts
	 */
	public String getRegistrationAttempts() {
		return registrationAttempts;
	}
	/**
	 * @param registrationAttempts the registrationAttempts to set
	 */
	public void setRegistrationAttempts(String registrationAttempts) {
		this.registrationAttempts = registrationAttempts;
	}
	/**
	 * @return the eventTypeCode
	 */
	public String getEventTypeCode() {
		return eventTypeCode;
	}
	/**
	 * @param eventTypeCode the eventTypeCode to set
	 */
	public void setEventTypeCode(String eventTypeCode) {
		this.eventTypeCode = eventTypeCode;
	}
	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}
	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the failedReasonDescription
	 */
	public String getFailedReasonDescription() {
		return failedReasonDescription;
	}
	/**
	 * @param failedReasonDescription the failedReasonDescription to set
	 */
	public void setFailedReasonDescription(String failedReasonDescription) {
		this.failedReasonDescription = failedReasonDescription;
	}
	/**
	 * @return the memberSourceSystemCode
	 */
	public String getMemberSourceSystemCode() {
		return memberSourceSystemCode;
	}
	/**
	 * @param memberSourceSystemCode the memberSourceSystemCode to set
	 */
	public void setMemberSourceSystemCode(String memberSourceSystemCode) {
		this.memberSourceSystemCode = memberSourceSystemCode;
	}
	/**
	 * @return the insertUserIdentifier
	 */
	public String getInsertUserIdentifier() {
		return insertUserIdentifier;
	}
	/**
	 * @param insertUserIdentifier the insertUserIdentifier to set
	 */
	public void setInsertUserIdentifier(String insertUserIdentifier) {
		this.insertUserIdentifier = insertUserIdentifier;
	}
	/**
	 * @return the isBenefitFocus
	 */
	public String getIsBenefitFocus() {
		return isBenefitFocus;
	}
	/**
	 * @param isBenefitFocus the isBenefitFocus to set
	 */
	public void setIsBenefitFocus(String isBenefitFocus) {
		this.isBenefitFocus = isBenefitFocus;
	}
	/**
	 * @return the isActivationEmailSent
	 */
	public String getIsActivationEmailSent() {
		return isActivationEmailSent;
	}
	/**
	 * @param isActivationEmailSent the isActivationEmailSent to set
	 */
	public void setIsActivationEmailSent(String isActivationEmailSent) {
		this.isActivationEmailSent = isActivationEmailSent;
	}
	/**
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}
	/**
	 * @param groupName the groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	/**
	 * @return the groupSubgroupIdentifier
	 */
	public String getGroupSubgroupIdentifier() {
		return groupSubgroupIdentifier;
	}
	/**
	 * @param groupSubgroupIdentifier the groupSubgroupIdentifier to set
	 */
	public void setGroupSubgroupIdentifier(String groupSubgroupIdentifier) {
		this.groupSubgroupIdentifier = groupSubgroupIdentifier;
	}
	
	


}
