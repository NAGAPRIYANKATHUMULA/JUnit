/**
 * 
 */
package com.bsc.ais.manage.payment.info.services.v1.model.response;

import java.util.List;

/**
 * @author Cognizant Technology Solutions
 *
 */
public class AutoPaymentInformations {

	private List<AutoPaymentInformation> autoPaymentInformation;

	/**
	 * @return the autoPaymentInformation
	 */
	public List<AutoPaymentInformation> getAutoPaymentInformation() {
		return autoPaymentInformation;
	}

	/**
	 * @param autoPaymentInformation the autoPaymentInformation to set
	 */
	public void setAutoPaymentInformation(List<AutoPaymentInformation> autoPaymentInformation) {
		this.autoPaymentInformation = autoPaymentInformation;
	}

	

}
