/*
 * SendNotificationServiceRequestBody.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */

package com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * SendNotificationServiceRequestBody
 * @author Cognizant
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SendNotificationServiceRequestBody {

	private EmailInput emailInput;

	/**
	 * @return the emailInput
	 */
	public EmailInput getEmailInput() {
		return emailInput;
	}

	/**
	 * @param emailInput the emailInput to set
	 */
	public void setEmailInput(EmailInput emailInput) {
		this.emailInput = emailInput;
	}
	
	
}
