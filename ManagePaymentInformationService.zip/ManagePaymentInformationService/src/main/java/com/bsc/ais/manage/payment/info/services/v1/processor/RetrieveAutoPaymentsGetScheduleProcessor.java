/*
 * RetrieveAutoPaymentsGetScheduleProcessor.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceDBConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.response.AutoPaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceDbUtil;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;

/**
 * <HTML> This class contains the process method for the retrieving the schedule information for the list of subGroupIdentifiers passed </HTML>
 *
 * @author Cognizant Technology Solutions.
 * @version 1.0
 * 
 */
@Component
public class RetrieveAutoPaymentsGetScheduleProcessor implements Processor {

	private static final Logger LOGGER = LogManager.getLogger(RetrieveAutoPaymentsGetScheduleProcessor.class);

	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";

	@Resource
	private EventLogging eventLogging;
	
	@Resource
	private ManagePaymentInfoServiceDbUtil managePaymentInfoServiceDbUtil;

	/*
	 * (non-Javadoc)
	 * 
	 * This class is used to retrieve the schedule information
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	@SuppressWarnings({ "unchecked" })
	public void process(Exchange exchange) throws Exception {
		
		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_ENTERING, METHOD_PROCESS);
		
		// Obtain an instance of audit list from exchange object.
		List<AuditEvent> auditEventList = (List<AuditEvent>) exchange.getProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST);
		
			exchange.setProperty(ManagePaymentInfoServiceConstants.IS_GET_SCHEDULE_SUCCESS, ManagePaymentInfoServiceConstants.STRING_FALSE);
			
			// Obtain an instance of service response from exchange object.
			RetrieveAutoPaymentsResponse response = (RetrieveAutoPaymentsResponse) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
			
			// Obtain an instance of userInfo map from exchange object.
			Map<String,String> userInfoMap = (Map<String, String>) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USERINFO_MAP);
			
			//create new instance of message
			List<Message> messages = new ArrayList<Message>();
			
			// Obtain an instance of groupInfo map from exchange object.
			Map<String, List<String>> groupInfoMap = (Map<String, List<String>>) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_GROUP_MAP);
			
			try {
				
			  if(null != groupInfoMap && null != userInfoMap){
					
				//get the count of valid SubGroupIdentifier present in FACETS database
				int count = managePaymentInfoServiceDbUtil.validateSubGroupIdentifierCount(groupInfoMap);
				
				if(count > 0){
					//get the payment information
					List<Map<String, Object>> paymentRows = managePaymentInfoServiceDbUtil.paymentInfoForGetSchedule(groupInfoMap);
					
					if(null != paymentRows && !paymentRows.isEmpty()){
						//iterate and populate the payment Information List
						Map<String,AutoPaymentInformation> paymentResponseMap = new HashMap<String,AutoPaymentInformation>();
						for(Map<String, Object> row:paymentRows){
							
							LOGGER.debug(transactionId + " - "+ "schedule data present..");
							//create a instance of PaymentInformation object and populate the PaymentInformation with values
							AutoPaymentInformation paymentInformation = new AutoPaymentInformation();
							paymentInformation.setAccountNickName((String)row.get(ManagePaymentInfoServiceDBConstants.ACC_NICK_NAME));
							paymentInformation.setAccountNumber((String)row.get(ManagePaymentInfoServiceDBConstants.ACC_NUMBER));
							paymentInformation.setPaymentFlag((String)row.get(ManagePaymentInfoServiceDBConstants.PAYMENT_FLAG));
							paymentInformation.setSubgroupIdentifier((String)row.get(ManagePaymentInfoServiceDBConstants.SUB_GROUP_IDEN));
							paymentInformation.setSubgroupName((String)row.get(ManagePaymentInfoServiceDBConstants.SUB_GROUP_NAME));
							String maintPermissionFlag = userInfoMap.get(paymentInformation.getSubgroupIdentifier());
							if(null != maintPermissionFlag && maintPermissionFlag.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_YES)){
								paymentInformation.setIsMaintPermission(ManagePaymentInfoServiceConstants.STRING_TRUE);
							}else if(null != maintPermissionFlag && maintPermissionFlag.equalsIgnoreCase(ManagePaymentInfoServiceConstants.STRING_NO)){
								paymentInformation.setIsMaintPermission(ManagePaymentInfoServiceConstants.STRING_FALSE);
							}
							paymentResponseMap.put(paymentInformation.getSubgroupIdentifier(), paymentInformation);
						}
						exchange.setProperty(ManagePaymentInfoServiceConstants.PAYMENT_RESPONSE_MAP,paymentResponseMap);
						exchange.setProperty(ManagePaymentInfoServiceConstants.IS_GET_SCHEDULE_SUCCESS, ManagePaymentInfoServiceConstants.STRING_TRUE);
					}else{ //no data returned from database
						ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_NO_SCHEDULE_DATA_FOUND,
								ManagePaymentInfoServiceConstants.MSG_DATA_NOT_FOUND,
								ManagePaymentInfoServiceConstants.MSG_DESC_NO_SCHEDULE_DATA_FOUND);
						
						LOGGER.debug(transactionId + " - "+ "No matching schedule data present for the given list of subGroupIdentifiers");
					}
					
				}else{ //if valid subGroupIdentifier count is not > 0
					ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_SUBGROUP_INVALID,
							ManagePaymentInfoServiceConstants.MSG_DESC_SUBGROUP_INVALID,
							ManagePaymentInfoServiceConstants.MSG_DESC_SUBGROUP_INVALID);
					
					LOGGER.debug(transactionId + " - "+ "Invalid list of subGroupIdentifiers");
					
				}
				
			  }	else{
					ManagePaymentInfoServiceUtil.addMessage(messages,
							ManagePaymentInfoServiceConstants.MSG_CODE_USER_DATA_NOT_FOUND,
							ManagePaymentInfoServiceConstants.MSG_USER_DATA_NOT_FOUND,
							ManagePaymentInfoServiceConstants.MSG_DESC_USER_DATA_FOUND);
					//audit logging
					ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.RETRIEVE_AUTOPAYMENTS_EVENT_FAILURE_CODE);
				}
			  
			  if (!messages.isEmpty()) {
					response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.WARNING,
							ManagePaymentInfoServiceConstants.WARNING_STATUS_CODE, response.getResponseHeader(), messages));
					messages.clear();
				}
			}catch (Exception ex) {
				LOGGER.error(transactionId + " - "+ METHOD_PROCESS , ex);
				ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
						ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
						ManagePaymentInfoServiceConstants.MSG_TECH_ERROR);
				
				//audit logging
				ManagePaymentInfoServiceUtil.setAuditLogging(exchange, auditEventList,ManagePaymentInfoServiceConstants.GET_SCHEDULE_EVENT_FAILURE_CODE);
			}
			
			if (!messages.isEmpty()) {
				response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE,
						ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, response.getResponseHeader(), messages));
			}
			
			//set the instance of response to exchange object
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			response.setResponseBody(null);
			exchange.getIn().setBody(response);
		
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_EXITING, METHOD_PROCESS);
	}

}