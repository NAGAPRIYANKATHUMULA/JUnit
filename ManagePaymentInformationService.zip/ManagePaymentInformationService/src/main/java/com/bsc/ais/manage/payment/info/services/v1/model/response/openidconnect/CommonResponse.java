package com.bsc.ais.manage.payment.info.services.v1.model.response.openidconnect;

import com.bsc.aip.core.model.common.composite.ResponseHeader;

/**
 * CommonResponse POJO for ManageOpenIdConnect API
 *
 * @author Vipul Gupta
 * @version 1.0
 * @since Mar 30, 2019
 */
public class CommonResponse {

	private ResponseHeader responseHeader;
	private Object responseBody;

	public Object getResponseBody() {
		return responseBody;
	}

	public void setResponseBody(Object responseBody) {
		this.responseBody = responseBody;
	}

	public ResponseHeader getResponseHeader() {
		return responseHeader;
	}

	public void setResponseHeader(ResponseHeader responseHeader) {
		this.responseHeader = responseHeader;
	}
}
