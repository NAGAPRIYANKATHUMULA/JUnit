/*
 * EmailBody.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */

package com.bsc.ais.manage.payment.info.services.v1.notificationv2.model.structural.transactional;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * EmailBody
 * @author Cognizant
 *
 */
@JsonInclude(Include.NON_NULL)
public class EmailBody {

	private String firstName;
	private String lastName;
	private String accountNumber;
	private String username;
	private String emailSubscriptionsMsg;
	private String name;
	private String groupId;
	private String subgroupId;
	private String paymentNotificationMsg;
	private String appLoginUrl;
	
	
	
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	/**
	 * @return the emailSubscriptionsMsg
	 */
	public String getEmailSubscriptionsMsg() {
		return emailSubscriptionsMsg;
	}
	/**
	 * @param emailSubscriptionsMsg the emailSubscriptionsMsg to set
	 */
	public void setEmailSubscriptionsMsg(String emailSubscriptionsMsg) {
		this.emailSubscriptionsMsg = emailSubscriptionsMsg;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the groupId
	 */
	public String getGroupId() {
		return groupId;
	}
	/**
	 * @return the subgroupId
	 */
	public String getSubgroupId() {
		return subgroupId;
	}
	/**
	 * @return the paymentNotificationMsg
	 */
	public String getPaymentNotificationMsg() {
		return paymentNotificationMsg;
	}
	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	/**
	 * @param subgroupId the subgroupId to set
	 */
	public void setSubgroupId(String subgroupId) {
		this.subgroupId = subgroupId;
	}
	/**
	 * @param paymentNotificationMsg the paymentNotificationMsg to set
	 */
	public void setPaymentNotificationMsg(String paymentNotificationMsg) {
		this.paymentNotificationMsg = paymentNotificationMsg;
	}
	/**
	 * @return the appLoginUrl
	 */
	public String getAppLoginUrl() {
		return appLoginUrl;
	}
	/**
	 * @param appLoginUrl the appLoginUrl to set
	 */
	public void setAppLoginUrl(String appLoginUrl) {
		this.appLoginUrl = appLoginUrl;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
}
