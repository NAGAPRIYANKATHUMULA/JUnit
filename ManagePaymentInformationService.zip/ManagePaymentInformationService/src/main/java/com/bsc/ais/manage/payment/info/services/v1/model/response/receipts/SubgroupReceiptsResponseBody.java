package com.bsc.ais.manage.payment.info.services.v1.model.response.receipts;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class SubgroupReceiptsResponseBody {
	
	private String totalCount;  
	private List<SubgroupReceipt> subgroupReceipts;

	
	/**
	 * @return the totalCount
	 */
	public String getTotalCount() {
		return totalCount;
	}

	/**
	 * @param totalCount the totalCount to set
	 */
	public void setTotalCount(String totalCount) {
		this.totalCount = totalCount;
	}

	/**
	 * @return the subgroupReceipts
	 */
	public List<SubgroupReceipt> getSubgroupReceipts() {
		return subgroupReceipts;
	}

	/**
	 * @param subgroupReceipts the subgroupReceipts to set
	 */
	public void setSubgroupReceipts(List<SubgroupReceipt> subgroupReceipts) {
		this.subgroupReceipts = subgroupReceipts;
	}
	
	

}
