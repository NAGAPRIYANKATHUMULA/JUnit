/* UserInfo.java
 *
 * <BSC_COPYRIGHT_NOTICE>
 * This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited.
 * All rights reserved
 * Copyright (c) 2016
 * </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * <HTML> This is the POJO object that holds the attributes for the UserInfo
 * data</HTML>.
 *
 * @author Cognizant Technology Solutions
 * @version 1.0
 * 
 * 
 */
@JsonIgnoreProperties (ignoreUnknown = true)
public class RetrieveAutoPaymentsRequestBody {

	/** The User id. */
	private String userIdentifier;

	private GroupIdentifiers groupIdentifiers;

	/**
	 * @return the userIdentifier
	 */
	public String getUserIdentifier() {
		return userIdentifier;
	}

	/**
	 * @param userIdentifier the userIdentifier to set
	 */
	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}

	/**
	 * @return the groupIdentifiers
	 */
	public GroupIdentifiers getGroupIdentifiers() {
		return groupIdentifiers;
	}

	/**
	 * @param groupIdentifiers the groupIdentifiers to set
	 */
	public void setGroupIdentifiers(GroupIdentifiers groupIdentifiers) {
		this.groupIdentifiers = groupIdentifiers;
	}
	
	
}
