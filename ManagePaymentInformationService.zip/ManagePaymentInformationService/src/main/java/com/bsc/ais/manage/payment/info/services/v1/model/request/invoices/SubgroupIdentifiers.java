/**
 * SubgroupIdentifiers.java
 */
package com.bsc.ais.manage.payment.info.services.v1.model.request.invoices;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Cognizant Technology Solutions
 *
 */
@JsonIgnoreProperties (ignoreUnknown = true)
public class SubgroupIdentifiers {

	private List<SubgroupIdentifier> subgroupIdentifier;

	/**
	 * @return the subGroupIdentifier
	 */
	public List<SubgroupIdentifier> getSubgroupIdentifier() {
		return subgroupIdentifier;
	}

	/**
	 * @param subGroupIdentifier the subGroupIdentifier to set
	 */
	public void setSubgroupIdentifier(List<SubgroupIdentifier> subgroupIdentifier) {
		this.subgroupIdentifier = subgroupIdentifier;
	}

	
	
}
