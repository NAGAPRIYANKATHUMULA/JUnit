package com.bsc.ais.manage.payment.info.services.v1.processor;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;

import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;


public class RetrieveAutoPaymentsServiceAggregationStrategy implements AggregationStrategy {

	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
		// TODO Auto-generated method stub
		
		if(oldExchange == null){
			oldExchange = newExchange;
		}else{
		
			String retrieveReceiptsSuccess = (String)newExchange.getProperty(ManagePaymentInfoServiceConstants.IS_RETRIEVE_RECEIPTS_SUCCESS);
			if(retrieveReceiptsSuccess != null){
				oldExchange.setProperty(ManagePaymentInfoServiceConstants.IS_RETRIEVE_RECEIPTS_SUCCESS,retrieveReceiptsSuccess);
			}
			
			String retrieveInvoicesSuccess = (String)newExchange.getProperty(ManagePaymentInfoServiceConstants.IS_RETRIEVE_INVOICES_SUCCESS);
			if(retrieveInvoicesSuccess != null){
				oldExchange.setProperty(ManagePaymentInfoServiceConstants.IS_RETRIEVE_INVOICES_SUCCESS,retrieveInvoicesSuccess);
			}
			
		}
		
		return oldExchange;
	}

}
