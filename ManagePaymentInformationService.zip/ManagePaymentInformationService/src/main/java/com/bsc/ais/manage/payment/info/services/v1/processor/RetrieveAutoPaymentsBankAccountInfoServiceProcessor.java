/*
 * RetrieveAutoPaymentsBankAccountInfoServiceProcessor.java
 *
 * <BSC_COPYRIGHT_NOTICE> This file contains proprietary information of Blue Shield of California.
 * Copying or reproduction without prior written approval is prohibited. All rights reserved
 * Copyright (c) 2017 </BSC_COPYRIGHT_NOTICE>
 */
package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Message;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupIdentifier;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupIdentifiers;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupSubgroup;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupSubgroups;
import com.bsc.ais.manage.payment.info.services.v1.model.request.RetrievePaymentInfoRequestBody;
import com.bsc.ais.manage.payment.info.services.v1.model.response.AutoPaymentHistoryInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsHistoryRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrieveAutoPaymentsHistoryResponse;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * <HTML> This class contains the process method for the retrieving bank account info
 * using RetrieveBankAccountInfo service </HTML>
 *
 * @author Cognizant Technology Solutions.
 * @version 1.0
 * 
 */
@Component
public class RetrieveAutoPaymentsBankAccountInfoServiceProcessor implements Processor {

	private static final Logger LOGGER = LogManager.getLogger(RetrieveAutoPaymentsBankAccountInfoServiceProcessor.class);

	private static final String METHOD_PROCESS = LOGGER.getName() + ".process()";

	private RestTemplate restTemplate = new RestTemplate();

	@Value("${retrieve.bankaccountinfo.service.url}")
	private String retrieveBankAccountInfoServiceUrl;
	
	@Value("${manage.payment.info.composite.custom.header.x-ibm-client-id}")
	private String xClientId;
	
	@Value("${manage.payment.info.composite.custom.header.x-ibm-client-secret}")
	private String xClientSecret;
	
	@Value("${api.services.security.passthrough}")
	private String idToken;
	
	@Resource
	private EventLogging eventLogging;

	/*
	 * (non-Javadoc)
	 * 
	 * This class is used for retrieving invoices info using RetrieveBankAccount Info Service
	 * 
	 * @see org.apache.camel.Processor#process(org.apache.camel.Exchange)
	 */
	@SuppressWarnings({ "unchecked" })
	public void process(Exchange exchange) throws Exception {
		
		final String transactionId = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.TRANSACTION_ID);
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_ENTERING, METHOD_PROCESS);
		
			exchange.setProperty(ManagePaymentInfoServiceConstants.IS_RETRIEVE_BANK_ACCOUNT_INFO_SUCCESS, ManagePaymentInfoServiceConstants.STRING_FALSE);
		
			// Obtain an instance of service request from exchange object.
			RetrieveAutoPaymentsHistoryRequest request = (RetrieveAutoPaymentsHistoryRequest) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST);
			// Obtain an instance of service response from exchange object.
			RetrieveAutoPaymentsHistoryResponse response = (RetrieveAutoPaymentsHistoryResponse) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
			// Obtain the list of subGroupIdentifier from exchange object.
			List<String> subGroupIdentifierList =(List<String>) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUBGROUP_IDENTIFIER_LIST);
			// Obtain the userIdentifier value from exchange object.
			String userIdentifier = (String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_USER_IDENTIFIER);
			// Obtain the instance of autoPaymentHistoryInformation List from exchange object.
			List<AutoPaymentHistoryInformation> autoPaymentHistoryInformationList = (List<AutoPaymentHistoryInformation>) exchange.getProperty(ManagePaymentInfoServiceConstants.AUTO_PAYMENTS_HISTORY_INFO_LIST);
			List<Message> messages = new ArrayList<Message>();
			
			try {
				//obtain HttpHeaders info
				HttpHeaders httpHeaders = ManagePaymentInfoServiceUtil.obtainHttpHeadersInfo(exchange,xClientId,xClientSecret);
				
				ObjectMapper requestMapper = new ObjectMapper();
				RequestHeader requestHeader = new RequestHeader();
				HttpEntity<String> requestEntity;
				ResponseEntity<String> bankAccInfoServiceResponse = null;
				
				//Build Retrieve Bank Account Info Service Request
				RetrievePaymentInfoRequest retrieveBankAccountInfoRequest = new RetrievePaymentInfoRequest();
				requestHeader = request.getRequestHeader();
				if(null != requestHeader.getCredentials()){
					requestHeader.getCredentials().setToken(idToken);
					requestHeader.getCredentials().setType(ManagePaymentInfoServiceConstants.ID_TOKEN);
				}
		
				retrieveBankAccountInfoRequest.setRequestHeader(requestHeader);
				retrieveBankAccountInfoRequest.setRequestBody(new RetrievePaymentInfoRequestBody());
				
				GroupIdentifiers groupIdentifiers = new GroupIdentifiers();
				List<GroupIdentifier> groupIdentifierList = new ArrayList<GroupIdentifier>();
				GroupIdentifier groupIdentifier = new GroupIdentifier();
				GroupSubgroups groupSubgroups = new GroupSubgroups();
				List<GroupSubgroup> groupSubgroupList = new ArrayList<GroupSubgroup>();
				
				for(String subGroupId: subGroupIdentifierList){
					GroupSubgroup groupSubgroup = new GroupSubgroup();
					groupSubgroup.setGroupSubgroupIdentifier(subGroupId);
					groupSubgroupList.add(groupSubgroup);
				}
				groupSubgroups.setGroupSubgroup(groupSubgroupList);
				groupIdentifier.setGroupSubgroups(groupSubgroups);
				groupIdentifierList.add(groupIdentifier);
				groupIdentifiers.setGroupIdentifier(groupIdentifierList);
				
				retrieveBankAccountInfoRequest.getRequestBody().setUserIdentifier(userIdentifier);
				retrieveBankAccountInfoRequest.getRequestBody().setGroupIdentifiers(groupIdentifiers);
				
				requestEntity = new HttpEntity<String>(requestMapper.writeValueAsString(retrieveBankAccountInfoRequest), httpHeaders);
				LOGGER.debug(transactionId + " - "+ "Retrieve Bank Account Information Service Request: "+requestEntity);
				//call the RetrieveBankAccount Info Service and get the response
				bankAccInfoServiceResponse = restTemplate.exchange(retrieveBankAccountInfoServiceUrl, HttpMethod.POST, requestEntity, String.class);
		
				if (bankAccInfoServiceResponse != null) {
					ObjectMapper responseMapper = new ObjectMapper();
					String bankAccInfoServiceResponseString = ManagePaymentInfoServiceUtil.processSyncResponse(bankAccInfoServiceResponse, ManagePaymentInfoServiceConstants.RETRIEVE_INVOICES_FOR_SUBGROUP_SERVICE);
					if (!StringUtils.isBlank(bankAccInfoServiceResponseString)) {
						RetrievePaymentInfoResponse bankAccInfoResponse = responseMapper.readValue(bankAccInfoServiceResponseString, RetrievePaymentInfoResponse.class);
						//validate if service returns SUCCESS or not
						if (StringUtils.equalsIgnoreCase(
								bankAccInfoResponse.getResponseHeader().getTransactionNotification().getStatusCode(), ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE)) {
							exchange.setProperty(ManagePaymentInfoServiceConstants.IS_RETRIEVE_BANK_ACCOUNT_INFO_SUCCESS,
									ManagePaymentInfoServiceConstants.STRING_TRUE);
							//iterate and get the list of bank account information
							if(null != bankAccInfoResponse.getResponseBody() && null != bankAccInfoResponse.getResponseBody().getPaymentInformations() 
									&& null != bankAccInfoResponse.getResponseBody().getPaymentInformations().getPaymentInformation() 
									&& !bankAccInfoResponse.getResponseBody().getPaymentInformations().getPaymentInformation().isEmpty()){
								List<PaymentInformation> paymentInformationList = bankAccInfoResponse.getResponseBody().getPaymentInformations().getPaymentInformation();
								
								if(null != autoPaymentHistoryInformationList && !autoPaymentHistoryInformationList.isEmpty() && null != paymentInformationList && !paymentInformationList.isEmpty()){
								for(PaymentInformation bankAccInformation: paymentInformationList){
									for(AutoPaymentHistoryInformation paymentHistoryInformation:autoPaymentHistoryInformationList){
									if(null != paymentHistoryInformation){
									if(bankAccInformation.getAccountNickName().equalsIgnoreCase(paymentHistoryInformation.getAccountNickName())){
										String routingNumber = bankAccInformation.getRoutingNumber();
										String accountNumber = bankAccInformation.getAccountNumber();
										
										if(null != routingNumber){
											paymentHistoryInformation.setRoutingNumber(routingNumber);
										}
										
										if(null != accountNumber){
											paymentHistoryInformation.setAccountNumber(accountNumber);
										}
										
										}	
									  }
								    }
								  }
								}
							}
						}else if(StringUtils.equalsIgnoreCase(
								bankAccInfoResponse.getResponseHeader().getTransactionNotification().getRemarks().getMessages().get(0).getCode(), ManagePaymentInfoServiceConstants.MSG_CODE_NO_DATA_FOUND)) {
							
							exchange.setProperty(ManagePaymentInfoServiceConstants.IS_RETRIEVE_BANK_ACCOUNT_INFO_SUCCESS,
									ManagePaymentInfoServiceConstants.STRING_TRUE);
							if(null != autoPaymentHistoryInformationList && !autoPaymentHistoryInformationList.isEmpty()){
							for(AutoPaymentHistoryInformation paymentHistoryInformation:autoPaymentHistoryInformationList){
								if(null != paymentHistoryInformation){
									paymentHistoryInformation.setRoutingNumber(ManagePaymentInfoServiceConstants.EMPTY_STR);
									paymentHistoryInformation.setAccountNumber(ManagePaymentInfoServiceConstants.EMPTY_STR);
								}
							  }
							}
						} else  {
							
							ManagePaymentInfoServiceUtil.addMessage(messages, bankAccInfoResponse.getResponseHeader().getTransactionNotification().getRemarks().getMessages().get(0).getCode(),
									ManagePaymentInfoServiceConstants.RETRIEVE_BANK_ACCOUNT_SERVICE_FAILED,
									bankAccInfoResponse.getResponseHeader().getTransactionNotification().getRemarks().getMessages().get(0).getDescription());	
							LOGGER.error(transactionId + " - "+ METHOD_PROCESS + ManagePaymentInfoServiceConstants.FAILURE );
							
							if (!messages.isEmpty()) {
								response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.WARNING,
										ManagePaymentInfoServiceConstants.WARNING_STATUS_CODE, response.getResponseHeader(), messages));
								messages.clear();
							}
						}
					}
				} else {
					messages.clear();
					ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
							ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
							ManagePaymentInfoServiceConstants.RETRIEVE_BANK_ACCOUNT_SERVICE_ERROR);
					LOGGER.error(transactionId + " - "+ METHOD_PROCESS + ManagePaymentInfoServiceConstants.FAILURE );
				}
			} catch (Exception ex) {
				
				messages.clear();
				ManagePaymentInfoServiceUtil.addMessage(messages, ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
						ManagePaymentInfoServiceConstants.MSG_TECH_ERROR,
						ManagePaymentInfoServiceConstants.RETRIEVE_BANK_ACCOUNT_SERVICE_ERROR);
				LOGGER.error(transactionId + " - "+ METHOD_PROCESS + ManagePaymentInfoServiceConstants.RETRIEVE_BANK_ACCOUNT_SERVICE_ERROR, ex);
			}
			
			if (!messages.isEmpty()) {
				response.setResponseHeader(ManagePaymentInfoServiceUtil.buildResponse(ManagePaymentInfoServiceConstants.FAILURE,
						ManagePaymentInfoServiceConstants.FAILURE_STATUS_CODE, response.getResponseHeader(), messages));
			}
			
			if(ManagePaymentInfoServiceConstants.STRING_FALSE.equalsIgnoreCase((String)exchange.getProperty(ManagePaymentInfoServiceConstants.IS_RETRIEVE_BANK_ACCOUNT_INFO_SUCCESS))){
				exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_TOTAL_HISTORY_COUNT,ManagePaymentInfoServiceConstants.STRING_ZERO);
			}
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			response.setResponseBody(null);
			exchange.getIn().setBody(response);
		
		LOGGER.debug(transactionId + " - "+ ManagePaymentInfoServiceConstants.METHOD_EXITING, METHOD_PROCESS);
	}

}