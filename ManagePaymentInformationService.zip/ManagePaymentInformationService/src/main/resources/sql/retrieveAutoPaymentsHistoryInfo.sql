SELECT
                USR_NM,
                ACT_NM,
                PMT_ACT_DT,
                BNK_RTE_NBR,
                BNK_ACCT_NBR,
                GRP_SUB_GRP_NBR,
                BNK_ACCT_NCKNM
       FROM (
       SELECT
                USR_NM,
                ACT_NM,
                PMT_ACT_DT,
                BNK_RTE_NBR,
                BNK_ACCT_NBR,
                GRP_SUB_GRP_NBR,
                BNK_ACCT_NCKNM,
                ROW_NUMBER () OVER (ORDER BY PMT_ACT_DT) SNO
      FROM (
       select   distinct
                USR_NM,
                ACT_NM,
                PMT_ACT_DT,
                BNK_RTE_NBR,
                BNK_ACCT_NBR,
                GRP_SUB_GRP_NBR,
                BNK_ACCT_NCKNM
        from
                ESS_ADMN.PAYMENT_HISTORY_LOG HIST,
                EMPLOYER_ADMIN_USER          ADMN
        where
                HIST.USR_ID = ADMN.USR_ID
        And     ADMN.USR_NM = DECODE(:userName, 'ALL',ADMN.USR_NM,:userName)
        and     SUBSTR(GRP_SUB_GRP_NBR,1, 8) = :groupIdentifier
        and     HIST.ACT_NM = DECODE(:actionName, 'ALL',HIST.ACT_NM ,:actionName)
        and     trunc(PMT_ACT_DT) between to_date(:fromDate, 'MM/DD/YYYY') and to_date(:toDate, 'MM/DD/YYYY')
        )
        ) LST WHERE LST.SNO between :startIndex and (:startIndex + :endIndex) - 1
        order by PMT_ACT_DT desc