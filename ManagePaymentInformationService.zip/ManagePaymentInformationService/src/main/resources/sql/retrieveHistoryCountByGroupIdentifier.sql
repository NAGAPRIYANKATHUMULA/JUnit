select 
count(*) as totalRecHistCount 
FROM ESS_ADMN.PAYMENT_HISTORY_LOG HIST
where 
SUBSTR(GRP_SUB_GRP_NBR,1, 8) = :groupIdentifier