INSERT INTO PAYMENT_HISTORY_LOG
        (
        PMT_LOG_ID      ,
        USR_ID          ,
        ACT_NM          ,
        PMT_ACT_DT      ,
        BNK_RTE_NBR     ,
        BNK_ACCT_NBR    ,
        GRP_SUB_GRP_NBR ,
        BNK_ACCT_NCKNM  ,
        INSRT_USR_ID    ,
        INSRT_DT        ,
        UPDT_USR_ID     ,
        UPDT_DT        
        )
        VALUES
        (
        ESS_ADMN.SEQ_PMT_LOG_ID.NEXTVAL,
        :userId         ,
        :accountName    ,
        sysdate          ,
        null     ,
        :accountNumber    ,
        :subgroupId ,
        :accountNickName  ,
        :userId  ,
        sysdate  ,
       :userId   ,
        sysdate  
        )