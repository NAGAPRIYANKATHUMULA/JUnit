select count(*) as totalRecHistCount FROM (
        select  distinct
                USR_NM,
                ACT_NM,
                PMT_ACT_DT,
                BNK_RTE_NBR,
                BNK_ACCT_NBR,
                GRP_SUB_GRP_NBR,
                BNK_ACCT_NCKNM
        from
                ESS_ADMN.PAYMENT_HISTORY_LOG HIST,
                EMPLOYER_ADMIN_USER          ADMN
        where
                HIST.USR_ID = ADMN.USR_ID
        And     ADMN.USR_NM = DECODE(:userName, 'ALL',ADMN.USR_NM,:userName)
        and     SUBSTR(GRP_SUB_GRP_NBR,1, 8) = :groupIdentifier
        and     HIST.ACT_NM = DECODE(:actionName, 'ALL',HIST.ACT_NM ,:actionName)
        and     trunc(PMT_ACT_DT) between to_date(:fromDate, 'MM/DD/YYYY') and to_date(:toDate, 'MM/DD/YYYY')
        )