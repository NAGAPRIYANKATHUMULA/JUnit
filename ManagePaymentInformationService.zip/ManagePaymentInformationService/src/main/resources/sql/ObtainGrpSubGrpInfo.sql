SELECT DISTINCT T1.GRGR_ID AS GRGR_ID
                                , T1.GRGR_NAME AS GRGR_NAME
                                -- Begin v1.5
                               , cast(T1.GRGR_TERM_DT as date)  AS GRGR_TERM_DT
                               ,T1.GRGR_STS      AS GRGR_STS
                                , T1.LOBD_ID AS GROUP_LOBIND, 
                                T1.GRGR_RNST_DT AS GRGR_RNST_DT
                           , ROWNUM AS GRGR_COUNT                         
                   FROM (SELECT DISTINCT GRGR.GRGR_ID AS GRGR_ID
                                           , GRGR.GRGR_NAME AS GRGR_NAME
                                           -- Begin v1.5
                                           , GRGR.GRGR_TERM_DT AS GRGR_TERM_DT
                                           , GRGR.GRGR_STS AS GRGR_STS
                                           -- End v1.5
                                          -- Begin v1.4
                                           , (CASE                                         
                                                 WHEN ((DMCNT.CNT > 0) AND  (DOCNT.CNT > 0)) THEN 'DU'
                                                 WHEN (DMCNT.CNT > 0)  THEN 'DM'
                                                 WHEN (DOCNT.CNT > 0) THEN 'DO'                              
                                                 WHEN (LPDCNT.CNT > 0) THEN 'NA'                       
                                                 ELSE NULL
                                     END) AS LOBD_ID  , GRGR.GRGR_RNST_DT AS GRGR_RNST_DT
                                                                                                                                                                   --End v1.6
                              FROM FACETS.CMC_GRGR_GROUP GRGR 
                             -- Begin v1.4                             
                              LEFT JOIN (SELECT GRGR.GRGR_ID
                                                , COUNT(LOBD.LOBD_ID) CNT        
                                           FROM FACETS.CMC_GRGR_GROUP GRGR                       
                                           LEFT JOIN FACETS.CMC_CSPI_CS_PLAN CSPI 
                                             ON CSPI.GRGR_CK = GRGR.GRGR_CK
                                           LEFT JOIN FACETS.CMC_PDPD_PRODUCT PDPD
                                             ON PDPD.PDPD_ID = CSPI.PDPD_ID
                                           LEFT  JOIN FACETS.CMC_LOBD_LINE_BUS LOBD
                                             ON LOBD.LOBD_ID = PDPD.LOBD_ID
                                          WHERE GRGR.GRGR_ID = :groupId
                                            AND SUBSTR(PDPD.PDPD_ID,1,1) NOT IN ('L')                      
                                            AND LOBD.LOBD_ID = '0001'
                                           AND CSPI.CSPI_EFF_DT <= SYSTIMESTAMP
                                           AND CSPI.CSPI_TERM_DT >= SYSTIMESTAMP
                                          GROUP BY GRGR.GRGR_ID) DMCNT
                                 ON DMCNT.GRGR_ID = GRGR.GRGR_ID   
                               LEFT JOIN (SELECT GRGR.GRGR_ID
                                                 , COUNT(LOBD.LOBD_ID) CNT       
                                            FROM FACETS.CMC_GRGR_GROUP GRGR                       
                                            LEFT JOIN FACETS.CMC_CSPI_CS_PLAN CSPI 
                                              ON CSPI.GRGR_CK = GRGR.GRGR_CK
                                            LEFT JOIN FACETS.CMC_PDPD_PRODUCT PDPD
                                              ON PDPD.PDPD_ID = CSPI.PDPD_ID
                                            LEFT JOIN FACETS.CMC_LOBD_LINE_BUS LOBD
                                              ON LOBD.LOBD_ID = PDPD.LOBD_ID
                                           WHERE GRGR.GRGR_ID = :groupId
                                             AND SUBSTR(PDPD.PDPD_ID,1,1) NOT IN ('L')                          
                                             AND LOBD.LOBD_ID IN('0002','0003','0004')  
                                             AND CSPI.CSPI_EFF_DT <= SYSTIMESTAMP
                                            AND CSPI.CSPI_TERM_DT >= SYSTIMESTAMP
                                           GROUP BY GRGR.GRGR_ID) DOCNT
                                 ON DOCNT.GRGR_ID = GRGR.GRGR_ID                                      
                                LEFT JOIN (SELECT GRGR.GRGR_ID
                                                  , COUNT(SUBSTR(PDPD.PDPD_ID,1,1)) CNT        
                                             FROM FACETS.CMC_GRGR_GROUP GRGR                       
                                             LEFT JOIN FACETS.CMC_CSPI_CS_PLAN CSPI 
                                               ON CSPI.GRGR_CK = GRGR.GRGR_CK
                                             LEFT JOIN FACETS.CMC_PDPD_PRODUCT PDPD
                                               ON PDPD.PDPD_ID = CSPI.PDPD_ID
                                             LEFT  JOIN FACETS.CMC_LOBD_LINE_BUS LOBD
                                               ON LOBD.LOBD_ID = PDPD.LOBD_ID
                                            WHERE GRGR.GRGR_ID = :groupId                    
                                              AND SUBSTR(PDPD.PDPD_ID,1,1) IN ('L')   
                                              AND CSPI.CSPI_EFF_DT <= SYSTIMESTAMP
                                              AND CSPI.CSPI_TERM_DT >= SYSTIMESTAMP
                                            GROUP BY GRGR.GRGR_ID) LPDCNT
                                   ON LPDCNT.GRGR_ID = GRGR.GRGR_ID 
                                WHERE GRGR.GRGR_ID = :groupId) T1   
                               -- End v1.4
                                ORDER BY ROWNUM DESC
