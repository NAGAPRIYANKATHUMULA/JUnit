SELECT CASE WHEN SCHED_NOTFY_IND = 'Y'
              THEN 'true'
              ELSE 'false'
        END as SCHLD_NOTIFY_IND 
  FROM EMPLOYER_ADMIN_USER
  WHERE USR_ID = :userIdentifier
 