/**
 * 
 */
package com.bsc.ais;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.apache.camel.test.spring.CamelSpringRunner;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;

import com.bsc.aip.core.camel.template.BscCamelTemplate;
import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Consumer;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.aip.core.model.common.composite.ResponseHeader;
import com.bsc.aip.core.model.common.composite.TransactionNotification;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.RetrievePaymentInfoRequestBody;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoResponse;
import com.bsc.ais.manage.payment.info.services.v1.processor.GetScheduleDataProcessor;
import com.bsc.ais.manage.payment.info.services.v1.processor.RetrievePaymentInfoResponseProcessor;

/**
 * @author Cognizant
 *
 */
@RunWith(CamelSpringRunner.class)
@ContextConfiguration(locations = { "classpath:springtest-config/springtest-context.xml" })
public class RetrievePaymentInfoResponseProcessorTest extends CamelTestSupport {

	@InjectMocks
	private RetrievePaymentInfoResponseProcessor processor = new RetrievePaymentInfoResponseProcessor();

	@Mock
	private BscCamelTemplate bscCamelTemplate = new BscCamelTemplate();
	
	@Mock
	private EventLogging eventLogging;

	@Override
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		super.setUp();

	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:in").process(processor).to("mock:out");
			}
		};
	}

	@Test
	public void testProcessSuccess() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		try {

			DefaultExchange exc = populateExchanges();
			template.send("direct:in", exc);
		} catch (Exception e) {
			e.printStackTrace();
		}

		List<Exchange> exchangeList = mockOutEndPt.getReceivedExchanges();

		assertEquals("exception flow", true, exchangeList.isEmpty());

	}

	@Test
	public void testProcessSuccessRet() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		try {

			DefaultExchange exc = populateExchanges();
			exc.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
					ManagePaymentInfoServiceConstants.RETRIEVE_BANK_ACC_INFO_SERVICE);
			template.send("direct:in", exc);
		} catch (Exception e) {
			e.printStackTrace();
		}

		List<Exchange> exchangeList = mockOutEndPt.getReceivedExchanges();
		RetrievePaymentInfoResponse response = (RetrievePaymentInfoResponse) exchangeList.get(0)
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);

		assertEquals("exception flow", ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE,
				response.getResponseHeader().getTransactionNotification().getStatusCode());

	}

	private DefaultExchange populateExchanges() {

		RequestHeader header = new RequestHeader();
		Consumer consumer = new Consumer();
		consumer.setBusinessTransactionType("emp");
		consumer.setId("id");
		header.setTransactionId("TR1234567890");
		header.setConsumer(consumer);
		RetrievePaymentInfoRequestBody body = new RetrievePaymentInfoRequestBody();
		RetrievePaymentInfoRequest request = new RetrievePaymentInfoRequest();
		request.setRequestBody(body);
		request.setRequestHeader(header);

		List<PaymentInformation> paymentInformationList = new ArrayList<PaymentInformation>();
		PaymentInformation paymentInformation = new PaymentInformation();
		paymentInformation.setSubgroupIdentifier("W00010001000");
		paymentInformationList.add(paymentInformation);

		List<AuditEvent> auditEventList = new ArrayList<AuditEvent>();
		List<String> subGroupIdentifierList = new ArrayList<String>();
		subGroupIdentifierList.add("w00010001000");
		RetrievePaymentInfoResponse response = new RetrievePaymentInfoResponse();
		response.setResponseHeader(new ResponseHeader());
		response.getResponseHeader().setTransactionNotification(new TransactionNotification());
		response.getResponseHeader().getTransactionNotification()
				.setStatusCode(ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE);
		DefaultExchange exchange = null;
		try {
			exchange = new DefaultExchange(createCamelContext());
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST,
					subGroupIdentifierList);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_PAYMENT_INFO_LIST, paymentInformationList);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
					ManagePaymentInfoServiceConstants.GET_SCHEDULE_SERVICE);
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return exchange;
	}

	private RetrievePaymentInfoResponse checkProcessResponse(MockEndpoint mockOutEndPt) {
		List<Exchange> exchangeList = mockOutEndPt.getReceivedExchanges();
		RetrievePaymentInfoResponse response = (RetrievePaymentInfoResponse) exchangeList.get(0)
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
		return response;
	}

}
