/**
 * 
 */
package com.bsc.ais;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.apache.camel.test.spring.CamelSpringRunner;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;

import com.bsc.aip.core.model.common.composite.ResponseHeader;
import com.bsc.aip.core.model.common.composite.TransactionNotification;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceDBConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoResponse;
import com.bsc.ais.manage.payment.info.services.v1.processor.GetScheduleDataProcessor;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceDbUtil;

/**
 * @author Cognizant
 *
 */
@RunWith(CamelSpringRunner.class)
@ContextConfiguration(locations = { "classpath:springtest-config/springtest-context.xml" })
public class GetScheduleDataProcessorTest  extends CamelTestSupport {
	


	@InjectMocks
	private GetScheduleDataProcessor processor = new GetScheduleDataProcessor();

	@Mock
	private ManagePaymentInfoServiceDbUtil dbUtil = new ManagePaymentInfoServiceDbUtil();

	@Override
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		super.setUp();

	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:in").process(processor).to("mock:out");
			}
		};
	}


	@Test
	public void testSubGrpIdInvalid() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		try {
			DefaultExchange exc = populateExchanges();
			Mockito.when(dbUtil.validateSubGroupIdentifierCount(null)).thenReturn(0);

			template.send("direct:in", exc);
		} catch (Exception e) {
			e.printStackTrace();
		}

		RetrievePaymentInfoResponse response = checkProcessResponse(mockOutEndPt);

		assertEquals("exception flow",
				ManagePaymentInfoServiceConstants.MSG_CODE_SUBGROUP_INVALID,
				response.getResponseHeader().getTransactionNotification().getRemarks().getMessages().get(0).getCode());

	}
	
	@Test
	public void testNoDataFound() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		try {
			DefaultExchange exc = populateExchanges();
			Mockito.when(dbUtil.validateSubGroupIdentifierCount(null)).thenReturn(1);
			Mockito.when(dbUtil.paymentInfoForGetSchedule(null)).thenReturn(null);
			template.send("direct:in", exc);
		} catch (Exception e) {
			e.printStackTrace();
		}

		RetrievePaymentInfoResponse response = checkProcessResponse(mockOutEndPt);

		assertEquals("exception flow",
				ManagePaymentInfoServiceConstants.MSG_CODE_NO_DATA_FOUND,
				response.getResponseHeader().getTransactionNotification().getRemarks().getMessages().get(0).getCode());

	}
	
	@Test
	public void testProcessSuccess() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		try {
			DefaultExchange exc = populateExchanges();
			Mockito.when(dbUtil.validateSubGroupIdentifierCount(null)).thenReturn(1);
			List<Map<String, Object>> paymentRows = new ArrayList<Map<String, Object>>();
			Map<String, Object> paymentRow = new HashMap<String, Object>();		
			paymentRow.put(ManagePaymentInfoServiceDBConstants.ACC_NICK_NAME, "name");
			paymentRow.put(ManagePaymentInfoServiceDBConstants.ACC_NUMBER, "12345");
			paymentRow.put(ManagePaymentInfoServiceDBConstants.ROUTING_NUMBER, "12345");
			paymentRow.put(ManagePaymentInfoServiceDBConstants.ACC_TYPE, "savings");
			paymentRow.put(ManagePaymentInfoServiceDBConstants.PAYMENT_FLAG, "y");
			paymentRow.put(ManagePaymentInfoServiceDBConstants.SUB_GROUP_IDEN, "w00010001000");
			
			paymentRows.add(paymentRow);
			Mockito.when(dbUtil.paymentInfoForGetSchedule(null)).thenReturn(paymentRows);
			template.send("direct:in", exc);
		} catch (Exception e) {
			e.printStackTrace();
		}

		RetrievePaymentInfoResponse response = checkProcessResponse(mockOutEndPt);

		assertEquals("exception flow",
				ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE,
				response.getResponseHeader().getTransactionNotification().getStatusCode());

	}
	

	@Test
	public void testProcessException() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		try {
			DefaultExchange exc = populateExchanges();
			Mockito.when(dbUtil.validateSubGroupIdentifierCount(null)).thenReturn(1);
			List<Map<String, Object>> paymentRows = new ArrayList<Map<String, Object>>();
			Map<String, Object> paymentRow = new HashMap<String, Object>();
			paymentRow.put(ManagePaymentInfoServiceDBConstants.ACC_NICK_NAME, 12);
			paymentRows.add(paymentRow);
			Mockito.when(dbUtil.paymentInfoForGetSchedule(null)).thenReturn(paymentRows);
			template.send("direct:in", exc);
		} catch (Exception e) {
			e.printStackTrace();
		}

		RetrievePaymentInfoResponse response = checkProcessResponse(mockOutEndPt);

		assertEquals("exception flow",
				ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
				response.getResponseHeader().getTransactionNotification().getRemarks().getMessages().get(0).getCode());

	}

	private DefaultExchange populateExchanges() {

		List<AuditEvent> auditEventList = new ArrayList<AuditEvent>();
		List<String> subGroupIdentifierList = new ArrayList<String>();
		subGroupIdentifierList.add("w00010001000");
		RetrievePaymentInfoResponse response = new RetrievePaymentInfoResponse();
		response.setResponseHeader(new ResponseHeader());
		response.getResponseHeader().setTransactionNotification(new TransactionNotification());
		response.getResponseHeader().getTransactionNotification()
				.setStatusCode(ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE);
		DefaultExchange exchange = null;
		try {
			exchange = new DefaultExchange(createCamelContext());

			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_SUB_GROUP_IDENTIFIER_LIST,
					subGroupIdentifierList);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
					ManagePaymentInfoServiceConstants.GET_SCHEDULE_SERVICE);
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST,
					auditEventList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return exchange;
	}

	private RetrievePaymentInfoResponse checkProcessResponse(MockEndpoint mockOutEndPt) {
		List<Exchange> exchangeList = mockOutEndPt.getReceivedExchanges();
		RetrievePaymentInfoResponse response = (RetrievePaymentInfoResponse) exchangeList.get(0)
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
		return response;
	}



}
