/**
 * 
 */
package com.bsc.ais;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;

import com.bsc.aip.core.camel.template.BscCamelTemplate;
import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Consumer;
import com.bsc.aip.core.model.common.atomic.Credentials;
import com.bsc.aip.core.model.common.composite.RequestHeader;

import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupIdentifier;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupIdentifiers;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupSubgroup;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupSubgroups;
import com.bsc.ais.manage.payment.info.services.v1.model.request.RetrievePaymentInfoRequestBody;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.RetrievePaymentInfoResponse;
import com.bsc.ais.manage.payment.info.services.v1.processor.RetrievePaymentInfoRequestProcessor;

/**
 * @author Cognizant
 *
 */
@RunWith(MockitoJUnitRunner.class)
@ContextConfiguration(locations = { "classpath:springtest-config/springtest-context.xml" })
public class RetrievePaymentInfoRequestProcessorTest  extends CamelTestSupport {
	


	@InjectMocks
	private RetrievePaymentInfoRequestProcessor processor = new RetrievePaymentInfoRequestProcessor();

	@Mock
	private EventLogging eventLogging;

	@Mock
	private BscCamelTemplate bscCamelTemplate;

	@Override
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		super.setUp();

	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:in").process(processor).to("mock:out");
			}
		};
	}

	
	@SuppressWarnings("unchecked")
	@Test
	public void testProcessException() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RetrievePaymentInfoRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();

		RetrievePaymentInfoRequest request = new RetrievePaymentInfoRequest();
		request.setRequestBody(body);

		try {
			DefaultExchange exchange = new DefaultExchange(createCamelContext());
			DefaultMessage message = new DefaultMessage(createCamelContext());
			message.setBody(request);
			exchange.setIn(message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);
			exchange.getIn().setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, 1234);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
					ManagePaymentInfoServiceConstants.GET_SCHEDULE_SERVICE);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<Exchange> exchangeList = mockOutEndPt.getReceivedExchanges();
		RetrievePaymentInfoResponse response = (RetrievePaymentInfoResponse) exchangeList.get(0).getIn().getBody();

		assertEquals("Case when request header is invalid",
				ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
				response.getResponseHeader().getTransactionNotification().getRemarks().getMessages().get(0).getCode());

	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testProcessRequestHeaderNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RetrievePaymentInfoRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();

		RetrievePaymentInfoRequest request = new RetrievePaymentInfoRequest();
		request.setRequestBody(body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}
		checkProcessResponse(mockOutEndPt);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessTransactionIdNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		RetrievePaymentInfoRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.setTransactionId("");
		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessConsumerHostNameNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		RetrievePaymentInfoRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.getConsumer().setHostName("");
		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testProcessConsumerBusinessUnitNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		RetrievePaymentInfoRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.getConsumer().setBusinessUnit("");
		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessConsumerTypNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		RetrievePaymentInfoRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.getConsumer().setType("");
		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessConsumerIdNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		RetrievePaymentInfoRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.getConsumer().setId("");
		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessConsumerNameNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		RetrievePaymentInfoRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.getConsumer().setName("");
		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	


	@SuppressWarnings("unchecked")
	@Test
	public void testProcessCredentialsTokenNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		RetrievePaymentInfoRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.getConsumer().setName("EMP");
		header.getCredentials().setToken("");
		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessCredentialsTokenTypeNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		RetrievePaymentInfoRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.getConsumer().setName("EMP");
		header.getCredentials().setType("");
		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessCredentialsNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		RetrievePaymentInfoRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.getConsumer().setName("EMP");
		header.setCredentials(null);
		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessConsumerNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		RetrievePaymentInfoRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.setConsumer(null);

		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}
		checkProcessResponse(mockOutEndPt);

	}


	
	@Test
	public void testProcessGrpIdObjNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RequestHeader header = populateRequestHeader();

		RetrievePaymentInfoRequestBody body = new RetrievePaymentInfoRequestBody();

		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}
	
	@Test
	public void testProcessUserIdNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RequestHeader header = populateRequestHeader();
		header.getConsumer().setName("emp");
		RetrievePaymentInfoRequestBody body = new RetrievePaymentInfoRequestBody();

		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	@Test
	public void testProcessReqBodyNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RequestHeader header = populateRequestHeader();

		RetrievePaymentInfoRequest request = new RetrievePaymentInfoRequest();
		request.setRequestHeader(header);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}
	
	
	@Test
	public void testProcessReqBodyException() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RequestHeader header = populateRequestHeader();

		RetrievePaymentInfoRequestBody body = new RetrievePaymentInfoRequestBody();
		body.setGroupIdentifiers(new GroupIdentifiers());
		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}
	

	@Test
	public void testProcessGrpArray() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RequestHeader header = populateRequestHeader();

		RetrievePaymentInfoRequestBody body = new RetrievePaymentInfoRequestBody();
		body.setGroupIdentifiers(new GroupIdentifiers());
		List<GroupIdentifier> groupIdentifier = new ArrayList<GroupIdentifier>();
		body.getGroupIdentifiers().setGroupIdentifier(groupIdentifier);
		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	@Test
	public void testProcessSubGrpArrayNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RequestHeader header = populateRequestHeader();

		RetrievePaymentInfoRequestBody body =  populateRequestBody();

		body.getGroupIdentifiers().getGroupIdentifier().get(0).setGroupSubgroups(null);

		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}
	
	
	@Test
	public void testProcessSubGrpIdNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RequestHeader header = populateRequestHeader();

		RetrievePaymentInfoRequestBody body =  populateRequestBody();

		body.getGroupIdentifiers().getGroupIdentifier().get(0).getGroupSubgroups().getGroupSubgroup().get(0).setGroupSubgroupIdentifier("");

		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}
	
	@Test
	public void testProcessSubGrpIdInvalid() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RequestHeader header = populateRequestHeader();

		RetrievePaymentInfoRequestBody body =  populateRequestBody();

		body.getGroupIdentifiers().getGroupIdentifier().get(0).getGroupSubgroups().getGroupSubgroup().get(0).setGroupSubgroupIdentifier("W000100");

		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}
	
	@Test
	public void testProcessValidRequest() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RequestHeader header = populateRequestHeader();

		RetrievePaymentInfoRequestBody body = populateRequestBody();

		RetrievePaymentInfoRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<Exchange> exchangeList = mockOutEndPt.getReceivedExchanges();

		assertEquals("Case when request object is invalid", "true", exchangeList.get(0)
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS));

	}

	@Test
	public void testProcessValidRequestBSCTemplateCall() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RequestHeader header = populateRequestHeader();
		header.getConsumer().setName("emp");
		RetrievePaymentInfoRequestBody body = populateRequestBody();
		body.setUserIdentifier("user");
		RetrievePaymentInfoRequest request = setRequestBody(header, body);
		try {
			DefaultExchange exchange = new DefaultExchange(createCamelContext());
			DefaultMessage message = new DefaultMessage(createCamelContext());
			message.setBody(request);
			exchange.setIn((Message) message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
					ManagePaymentInfoServiceConstants.GET_SCHEDULE_SERVICE);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<Exchange> exchangeList = mockOutEndPt.getReceivedExchanges();
		assertEquals("Case when request object is invalid", true, exchangeList.isEmpty());

	}

	private RetrievePaymentInfoRequest setRequestBody(RequestHeader header, RetrievePaymentInfoRequestBody body) {
		RetrievePaymentInfoRequest request = new RetrievePaymentInfoRequest();
		request.setRequestHeader(header);
		request.setRequestBody(body);
		return request;
	}

	private void createExchangeObject(RetrievePaymentInfoRequest request) throws Exception {
		DefaultExchange exchange = new DefaultExchange(createCamelContext());
		DefaultMessage message = new DefaultMessage(createCamelContext());
		message.setBody(request);
		exchange.setIn((Message) message);
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);
		exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
				ManagePaymentInfoServiceConstants.GET_SCHEDULE_SERVICE);
		template.send("direct:in", exchange);
	}

	private void checkProcessResponse(MockEndpoint mockOutEndPt) {
		List<Exchange> exchangeList = mockOutEndPt.getReceivedExchanges();
		

		assertEquals("Case when request object is invalid", "false", exchangeList.get(0)
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS));
	}

	private RetrievePaymentInfoRequestBody populateRequestBody() {
		RetrievePaymentInfoRequestBody body = new RetrievePaymentInfoRequestBody();


		GroupIdentifiers groupIdentifiers = new GroupIdentifiers();
		List<GroupIdentifier> groupIdentifierList = new ArrayList<GroupIdentifier>();
		GroupIdentifier grp = new GroupIdentifier();
		grp.setGroupIdentifier("W0001000");
		grp.setGroupName("group name");

		GroupSubgroups groupSubgroups = new GroupSubgroups();
		List<GroupSubgroup> groupSubgroupList = new ArrayList<GroupSubgroup>();
		GroupSubgroup grpSubGrp = new GroupSubgroup();
		grpSubGrp.setGroupSubgroupIdentifier("W00010001000");
		groupSubgroupList.add(grpSubGrp);
		groupSubgroups.setGroupSubgroup(groupSubgroupList);

		grp.setGroupSubgroups(groupSubgroups);
		groupIdentifierList.add(grp);

		groupIdentifiers.setGroupIdentifier(groupIdentifierList);
		body.setGroupIdentifiers(groupIdentifiers);
		return body;
	}

	private RequestHeader populateRequestHeader() {
		RequestHeader header = new RequestHeader();
		Consumer consumer = new Consumer();
		consumer.setBusinessTransactionType("");
		consumer.setBusinessUnit("test");
		consumer.setClientVersion("");
		consumer.setContextId("test");
		consumer.setHostName("hostname");
		consumer.setId("id");
		consumer.setName("IVR");
		consumer.setRequestDateTime("test");
		consumer.setType("test");
		Credentials credentials = new Credentials();
		credentials.setUserName("test");
		credentials.setPassword("test");
		credentials.setToken("token");
		credentials.setType("typ");

		header.setTransactionId("TR1234567890");
		header.setConsumer(consumer);
		header.setCredentials(credentials);
		return header;
	}



}
