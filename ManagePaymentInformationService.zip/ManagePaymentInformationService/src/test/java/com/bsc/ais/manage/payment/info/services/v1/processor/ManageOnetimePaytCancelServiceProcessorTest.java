package com.bsc.ais.manage.payment.info.services.v1.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.bsc.aip.core.model.common.atomic.Consumer;
import com.bsc.aip.core.model.common.atomic.Credentials;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.aip.core.model.common.composite.ResponseHeader;
import com.bsc.aip.core.model.common.composite.TransactionNotification;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceDBConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.EmailInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupIdentifier;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupIdentifiers;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupSubgroup;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupSubgroups;
import com.bsc.ais.manage.payment.info.services.v1.model.request.SubgroupsSetCancelPaymentRequestBody;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformations;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.util.ManagePaymentInfoServiceWPRDbUtil;

@RunWith(MockitoJUnitRunner.class)
public class ManageOnetimePaytCancelServiceProcessorTest extends CamelTestSupport {

	@Mock
	private ManagePaymentInfoServiceWPRDbUtil managePaymentInfoServiceWPRDbUtil;

	@Mock
	private RestTemplate restTemplate;
	
	@InjectMocks
	private ManageOnetimePaytCancelServiceProcessor manageOnetimePaytCancelServiceProcessor = new ManageOnetimePaytCancelServiceProcessor();

	private Exchange exchange;

	private Message message;

	@Override
	public void setUp() throws Exception {
		//manageOnetimePaytCancelServiceProcessor.setRestTemplate(restTemplate);
		//manageOnetimePaytCancelServiceProcessor.setNotificationv2Uri("http://localhost:9080");
		//manageOnetimePaytCancelServiceProcessor.setOneTimePaytEmailappLogInUrl("http://localhost:9080");
		super.setUp();
	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:in").process(manageOnetimePaytCancelServiceProcessor).to("mock:out");
			}
		};
	}

	@Test
	public void processScenario() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			request.setRequestBody(requestBody);
			request.setRequestHeader(requestHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST , request);

			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			AuditEvent event = new AuditEvent();
			auditEventList.add(event);
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER, "identifier");
			
			List<Map<String, Object>> rows = new ArrayList<>();
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("PMT_NOTFY_IND", "Y");
			map.put("EMAIL_TYP_CD", "4");
			map.put(ManagePaymentInfoServiceDBConstants.ALS_LST_NM, "firstName");
			map.put(ManagePaymentInfoServiceDBConstants.ALS_FRST_NM, "lastName");
			map.put(ManagePaymentInfoServiceDBConstants.EMAIL_ADDR_TXT, "emailAddress");
			
			
			map.put("b", "3");
			
			rows.add(map);
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.fetchEmailInfo((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER))).thenReturn(rows);
			
			HttpHeaders header = new HttpHeaders();
			header.setContentType(MediaType.APPLICATION_JSON);
	
			ResponseEntity<String> responseEntity = new ResponseEntity<String>(
					"{\"responseHeader\":{ \"transactionNotification\":{\"status\":\"\",\"statusCode\":\"0\",\"responseDateTime\":\"\",\"transactionId\":\"\",\"remarks\": {\"messages\": [{\"code\": \"\",\"description\": \"\",\"message\": \"\"}]}}},\"responseBody\": {\"emailStatus\":\"Success\"}}", header, HttpStatus.OK);
			System.out.println("responseEntity.getStatusCode()------------------------"+responseEntity.getStatusCode());
			Mockito.when(restTemplate.exchange(
					Matchers.eq("http://localhost:9080"),
					Matchers.eq(HttpMethod.POST), Matchers.<HttpEntity<String>>any(), Matchers.eq(String.class)))
					.thenReturn(responseEntity);
			

			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioZero() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			request.setRequestBody(requestBody);
			request.setRequestHeader(requestHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST , request);

			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			AuditEvent event = new AuditEvent();
			auditEventList.add(event);
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER, "identifier");
			
			List<Map<String, Object>> rows = new ArrayList<>();
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("PMT_NOTFY_IND", "Y");
			map.put("EMAIL_TYP_CD", "4");
			map.put(ManagePaymentInfoServiceDBConstants.ALS_LST_NM, "firstName");
			map.put(ManagePaymentInfoServiceDBConstants.ALS_FRST_NM, "lastName");
			map.put(ManagePaymentInfoServiceDBConstants.EMAIL_ADDR_TXT, "emailAddress");
			
			
			map.put("b", "3");
			
			rows.add(map);
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.fetchEmailInfo((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER))).thenReturn(rows);
			
			HttpHeaders header = new HttpHeaders();
			header.setContentType(MediaType.APPLICATION_JSON);
	
			ResponseEntity<String> responseEntity = new ResponseEntity<String>(
					"{\"responseHeader\":{ \"transactionNotification\":{\"status\":\"\",\"statusCode\":\"1\",\"responseDateTime\":\"\",\"transactionId\":\"\",\"remarks\": {\"messages\": [{\"code\": \"\",\"description\": \"\",\"message\": \"\"}]}}},\"responseBody\": {\"emailStatus\":\"Success\"}}", header, HttpStatus.OK);
			System.out.println("responseEntity.getStatusCode()------------------------"+responseEntity.getStatusCode());
			Mockito.when(restTemplate.exchange(
					Matchers.eq("http://localhost:9080"),
					Matchers.eq(HttpMethod.POST), Matchers.<HttpEntity<String>>any(), Matchers.eq(String.class)))
					.thenReturn(responseEntity);
			

			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioOne() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			request.setRequestBody(requestBody);
			request.setRequestHeader(requestHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST , request);

			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			AuditEvent event = new AuditEvent();
			auditEventList.add(event);
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER, "identifier");
			
			List<Map<String, Object>> rows = new ArrayList<>();
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("PMT_NOTFY_IND", "Y");
			map.put("EMAIL_TYP_CD", "4");
			map.put(ManagePaymentInfoServiceDBConstants.ALS_LST_NM, "firstName");
			map.put(ManagePaymentInfoServiceDBConstants.ALS_FRST_NM, "lastName");
			map.put(ManagePaymentInfoServiceDBConstants.EMAIL_ADDR_TXT, "emailAddress");
			
			
			map.put("b", "3");
			
			rows.add(map);
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.fetchEmailInfo((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER))).thenReturn(rows);
			
			HttpHeaders header = new HttpHeaders();
			header.setContentType(MediaType.APPLICATION_JSON);
	
			ResponseEntity<String> responseEntity = new ResponseEntity<String>(
					"{\"requestHeader\":{\"consumer\":{\"name\":\"ManagePaymentInformationService\",\"id\":\"aip\",\"businessUnit\":\"services\",\"type\":\"internal\",\"clientVersion\":\"v1\",\"requestDateTime\":\"null\",\"hostName\":\"PCIN479279\",\"businessTransactionType\":\"Census\",\"contextId\":\"null\",\"secondContextId\":\"null\",\"thirdContextId\":\"null\"},\"credentials\":{\"userName\":\"null\",\"password\":\"null\",\"token\":\"null\",\"type\":\"JWT\"},\"transactionId\":\"35a320a4-d4cf-4919-adce-3fe3f8096bb6\"},\"requestBody\":{\"emailInput\":{\"toAddress\":[\"emailAddress\"],\"subject\":\"Your Blue Shield of California Payment Was Cancelled\",\"templateIndicator\":\"empOneTimePaymentCancelledHTML\",\"emailBody\":{\"firstName\":\"lastName firstName\",\"groupId\":\"groupSub\",\"subgroupId\":\"grou\",\"appLoginUrl\":\"http://localhost:9080\"}}}}}", header, HttpStatus.OK);
			System.out.println("responseEntity.getStatusCode()------------------------"+responseEntity.getStatusCode());
			Mockito.when(restTemplate.exchange(
					Matchers.eq("http://localhost:9080"),
					Matchers.eq(HttpMethod.POST), Matchers.<HttpEntity<String>>any(), Matchers.eq(String.class)))
					.thenReturn(responseEntity);
			

			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioTwo() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			request.setRequestBody(requestBody);
			request.setRequestHeader(requestHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST , request);

			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			AuditEvent event = new AuditEvent();
			auditEventList.add(event);
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER, "identifier");
			
			List<Map<String, Object>> rows = new ArrayList<>();
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.fetchEmailInfo((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER))).thenReturn(rows);
		
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void processScenarioCatch() {
		try {
			exchange = new DefaultExchange(createCamelContext());
			message = new DefaultMessage(createCamelContext());
			
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			RequestHeader requestHeader = fetchRequesteHeaderWithCredentialsAndConsumer();
			SubgroupsSetCancelPaymentRequestBody requestBody = fetchRequestBody();
			request.setRequestBody(requestBody);
			request.setRequestHeader(requestHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST , request);

			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			ResponseHeader responseHeader = fetchResponseHeader();
			response.setResponseHeader(responseHeader);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
			
			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>(); 
			AuditEvent event = new AuditEvent();
			auditEventList.add(event);
			exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER, "identifier");
			
			List<Map<String, Object>> rows = new ArrayList<>();
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("PMT_NOTFY_IND", "Y");
			map.put("EMAIL_TYP_CD", 4);
			map.put(ManagePaymentInfoServiceDBConstants.ALS_LST_NM, "firstName");
			map.put(ManagePaymentInfoServiceDBConstants.ALS_FRST_NM, "lastName");
			map.put(ManagePaymentInfoServiceDBConstants.EMAIL_ADDR_TXT, "emailAddress");
			
			
			map.put("b", "3");
			
			rows.add(map);
			
			Mockito.when(managePaymentInfoServiceWPRDbUtil.fetchEmailInfo((String) exchange.getProperty(ManagePaymentInfoServiceConstants.EXC_USER_IDENTIIFER))).thenReturn(rows);
			

			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private ResponseHeader fetchResponseHeader() {
		ResponseHeader responseHeader = new ResponseHeader();
		TransactionNotification transactionNotification = new TransactionNotification();
		transactionNotification.setStatusCode("0");
		responseHeader.setTransactionNotification(transactionNotification);
		return responseHeader;
	}

	private RequestHeader fetchRequesteHeaderWithCredentialsAndConsumer() {
		RequestHeader header = new RequestHeader();
		Consumer consumer = new Consumer();
		consumer.setBusinessTransactionType("test");
		consumer.setBusinessUnit("test");
		consumer.setClientVersion("test");
		consumer.setContextId("test");
		consumer.setHostName("test");
		consumer.setId("test");
		consumer.setName("IV");
		consumer.setRequestDateTime("test");
		consumer.setType("test");
		Credentials credentials = new Credentials();
		credentials.setUserName("test");
		credentials.setPassword("test");
		credentials.setToken("test");
		credentials.setType("test");

		header.setTransactionId("TR1234567890");
		header.setConsumer(consumer);
		header.setCredentials(credentials);
		return header;
	}
	
	private SubgroupsSetCancelPaymentRequestBody fetchRequestBody() {
		SubgroupsSetCancelPaymentRequestBody body = new SubgroupsSetCancelPaymentRequestBody();
		EmailInformation emailInformation = new EmailInformation();
		emailInformation.setGroupIdentifier("groupIde");
		emailInformation.setName("name");
		emailInformation.setEmailAddress("emailAddress");
		PaymentInformations paymentInformations = new PaymentInformations();
		List<PaymentInformation> paymentInformationList = new ArrayList<>();
		PaymentInformation paymentInformation = new PaymentInformation();
		paymentInformation.setAccountNickName("accountNickName");
		paymentInformation.setAccountNumber("accountNumber");
		paymentInformation.setGroupIdentifier("groupIde");
		paymentInformation.setAccountHolderName("accountHolderName");
		paymentInformation.setBankAccountType("bankAccountType");
		paymentInformation.setRoutingNumber("routingNumber");
		paymentInformationList.add(paymentInformation);
		paymentInformations.setPaymentInformation(paymentInformationList);
		body.setPaymentInformations(paymentInformations);
		body.setEmailInformation(emailInformation);
		body.setUserIdentifier("W123456");
		body.setIsAutoPaymntCnclCnfrm("true1");
		GroupIdentifiers groupIdentifiers = new GroupIdentifiers();
		List<GroupIdentifier> groupIdentifierList = new ArrayList<>();
		
		GroupIdentifier groupIdentifier = new GroupIdentifier();
		
		GroupSubgroups groupSubgroups = new GroupSubgroups();
		List<GroupSubgroup> groupSubgroupList = new ArrayList<>();
		GroupSubgroup groupSubgroup = new GroupSubgroup();
		groupSubgroup.setGroupSubgroupIdentifier("groupSubgrou");
		groupSubgroupList.add(groupSubgroup);
		groupSubgroups.setGroupSubgroup(groupSubgroupList);
		groupIdentifier.setGroupSubgroups(groupSubgroups);
		
		groupIdentifierList.add(groupIdentifier);
		
		groupIdentifiers.setGroupIdentifier(groupIdentifierList);
		body.setGroupIdentifiers(groupIdentifiers);
		return body;

	}
	
}
