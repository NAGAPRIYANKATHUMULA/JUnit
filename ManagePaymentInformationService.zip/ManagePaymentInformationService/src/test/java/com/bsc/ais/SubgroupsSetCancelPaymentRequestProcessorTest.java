/**
 * 
 */
package com.bsc.ais;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;

import com.bsc.aip.core.camel.template.BscCamelTemplate;
import com.bsc.aip.core.framewrok.logging.EventLogging;
import com.bsc.aip.core.model.common.atomic.Consumer;
import com.bsc.aip.core.model.common.atomic.Credentials;
import com.bsc.aip.core.model.common.composite.RequestHeader;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupIdentifier;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupIdentifiers;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupSubgroup;
import com.bsc.ais.manage.payment.info.services.v1.model.request.GroupSubgroups;
import com.bsc.ais.manage.payment.info.services.v1.model.request.SubgroupsSetCancelPaymentRequestBody;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformation;
import com.bsc.ais.manage.payment.info.services.v1.model.response.PaymentInformations;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.processor.SubgroupsSetCancelPaymentRequestProcessor;

/**
 * @author Cognizant 
 *
 */
@RunWith(MockitoJUnitRunner.class)
@ContextConfiguration(locations = { "classpath:springtest-config/springtest-context.xml" })
public class SubgroupsSetCancelPaymentRequestProcessorTest   extends CamelTestSupport {
	

	


	@InjectMocks
	private SubgroupsSetCancelPaymentRequestProcessor processor = new SubgroupsSetCancelPaymentRequestProcessor();

	@Mock
	private EventLogging eventLogging;

	@Mock
	private BscCamelTemplate bscCamelTemplate;

	@Override
	public void setUp() throws Exception { 
		MockitoAnnotations.initMocks(this);
		super.setUp();

	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				from("direct:in").process(processor).to("mock:out");
			}
		};
	}

	
	@SuppressWarnings("unchecked")
	@Test
	public void testProcessException() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		SubgroupsSetCancelPaymentRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();

		SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
		request.setRequestBody(body);

		try {
			DefaultExchange exchange = new DefaultExchange(createCamelContext());
			DefaultMessage message = new DefaultMessage(createCamelContext());
			message.setBody(request);
			exchange.setIn(message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);
			exchange.getIn().setHeader(ManagePaymentInfoServiceConstants.TRANSACTION_ID, 1234);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
					ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SET_SERVICE);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<Exchange> exchangeList = mockOutEndPt.getReceivedExchanges();
		SubgroupsSetCancelPaymentResponse response = (SubgroupsSetCancelPaymentResponse) exchangeList.get(0).getIn().getBody();

		assertEquals("Case when request header is invalid",
				ManagePaymentInfoServiceConstants.MSG_CODE_TECH_ERROR,
				response.getResponseHeader().getTransactionNotification().getRemarks().getMessages().get(0).getCode());

	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testProcessRequestHeaderNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		SubgroupsSetCancelPaymentRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();

		SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
		request.setRequestBody(body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}
		checkProcessResponse(mockOutEndPt);
 
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessTransactionIdNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		SubgroupsSetCancelPaymentRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.setTransactionId("");
		SubgroupsSetCancelPaymentRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessConsumerHostNameNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		SubgroupsSetCancelPaymentRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.getConsumer().setHostName("");
		SubgroupsSetCancelPaymentRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testProcessConsumerBusinessUnitNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		SubgroupsSetCancelPaymentRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.getConsumer().setBusinessUnit("");
		SubgroupsSetCancelPaymentRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessConsumerTypNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		SubgroupsSetCancelPaymentRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.getConsumer().setType("");
		SubgroupsSetCancelPaymentRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessConsumerIdNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		SubgroupsSetCancelPaymentRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.getConsumer().setId("");
		SubgroupsSetCancelPaymentRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessConsumerNameNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		SubgroupsSetCancelPaymentRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.getConsumer().setName("");
		SubgroupsSetCancelPaymentRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	


	@SuppressWarnings("unchecked")
	@Test
	public void testProcessCredentialsTokenNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		SubgroupsSetCancelPaymentRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.getConsumer().setName("EMP");
		header.getCredentials().setToken("");
		SubgroupsSetCancelPaymentRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessCredentialsTokenTypeNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		SubgroupsSetCancelPaymentRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.getConsumer().setName("EMP");
		header.getCredentials().setType("");
		SubgroupsSetCancelPaymentRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessCredentialsNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		SubgroupsSetCancelPaymentRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.getConsumer().setName("EMP");
		header.setCredentials(null);
		SubgroupsSetCancelPaymentRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessConsumerNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
		SubgroupsSetCancelPaymentRequestBody body = populateRequestBody();
		RequestHeader header = populateRequestHeader();
		header.setConsumer(null);

		SubgroupsSetCancelPaymentRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}
		checkProcessResponse(mockOutEndPt);

	}

	
	@Test
	public void testProcessUserIdNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RequestHeader header = populateRequestHeader();
		header.getConsumer().setName("emp");
		SubgroupsSetCancelPaymentRequestBody body = new SubgroupsSetCancelPaymentRequestBody();

		SubgroupsSetCancelPaymentRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}
	
	@Test
	public void testPymtNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RequestHeader header = populateRequestHeader();
	
		SubgroupsSetCancelPaymentRequestBody body = populateRequestBody();
		body.setPaymentInformations(null);

		SubgroupsSetCancelPaymentRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}

	
	@Test
	public void testPymtSubGrpIdInvalid() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RequestHeader header = populateRequestHeader();
	
		SubgroupsSetCancelPaymentRequestBody body = populateRequestBody();
		body.getPaymentInformations().getPaymentInformation().get(0).setSubgroupIdentifier("W00100");

		SubgroupsSetCancelPaymentRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}
	
	@Test
	public void testProcessReqBodyNull() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RequestHeader header = populateRequestHeader();

		SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
		request.setRequestHeader(header);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		checkProcessResponse(mockOutEndPt);

	}
	


	
	
	@Test
	public void testProcessValidRequest() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RequestHeader header = populateRequestHeader();

		SubgroupsSetCancelPaymentRequestBody body = populateRequestBody();

		SubgroupsSetCancelPaymentRequest request = setRequestBody(header, body);

		try {
			createExchangeObject(request);
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<Exchange> exchangeList = mockOutEndPt.getReceivedExchanges();

		assertEquals("Case when request object is invalid", "true", exchangeList.get(0)
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS));

	}

	@Test
	public void testProcessValidRequestBSCTemplateCall() {
		MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

		RequestHeader header = populateRequestHeader();
		header.getConsumer().setName("emp");
		SubgroupsSetCancelPaymentRequestBody body = populateRequestBody();
		body.setUserIdentifier("user");
		SubgroupsSetCancelPaymentRequest request = setRequestBody(header, body);
		try {
			DefaultExchange exchange = new DefaultExchange(createCamelContext());
			DefaultMessage message = new DefaultMessage(createCamelContext());
			message.setBody(request);
			exchange.setIn((Message) message);
			exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);
			exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
					ManagePaymentInfoServiceConstants.GET_SCHEDULE_SERVICE);
			template.send("direct:in", exchange);
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<Exchange> exchangeList = mockOutEndPt.getReceivedExchanges();
		assertEquals("Case when request object is invalid", true, exchangeList.isEmpty());

	}

	private SubgroupsSetCancelPaymentRequest setRequestBody(RequestHeader header, SubgroupsSetCancelPaymentRequestBody body) {
		SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
		request.setRequestHeader(header);
		request.setRequestBody(body);
		return request;
	}

	private void createExchangeObject(SubgroupsSetCancelPaymentRequest request) throws Exception {
		DefaultExchange exchange = new DefaultExchange(createCamelContext());
		DefaultMessage message = new DefaultMessage(createCamelContext());
		message.setBody(request);
		exchange.setIn((Message) message);
		exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);
		exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
				ManagePaymentInfoServiceConstants.SUBGROUPS_PAYMENT_SET_SERVICE);
		template.send("direct:in", exchange);
	}

	private void checkProcessResponse(MockEndpoint mockOutEndPt) {
		List<Exchange> exchangeList = mockOutEndPt.getReceivedExchanges();
		

		assertEquals("Case when request object is invalid", "false", exchangeList.get(0)
				.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_IS_VALIDATION_SUCCESS));
	}

	private SubgroupsSetCancelPaymentRequestBody populateRequestBody() {
		SubgroupsSetCancelPaymentRequestBody body = new SubgroupsSetCancelPaymentRequestBody();

		body.setUserIdentifier("user");
		PaymentInformations paymentInformations = new PaymentInformations();
		List<PaymentInformation> paymentInformation = new ArrayList<PaymentInformation>();
		PaymentInformation pymt = new PaymentInformation();
		pymt.setSubgroupIdentifier("W00010001000");
		pymt.setGroupIdentifier("W0001000");
		paymentInformation.add(pymt);
		paymentInformations.setPaymentInformation(paymentInformation);
		body.setPaymentInformations(paymentInformations);
		return body;
	}

	private RequestHeader populateRequestHeader() {
		RequestHeader header = new RequestHeader();
		Consumer consumer = new Consumer();
		consumer.setBusinessTransactionType("");
		consumer.setBusinessUnit("test");
		consumer.setClientVersion("");
		consumer.setContextId("test");
		consumer.setHostName("hostname");
		consumer.setId("id");
		consumer.setName("IVR");
		consumer.setRequestDateTime("test");
		consumer.setType("test");
		Credentials credentials = new Credentials();
		credentials.setUserName("test");
		credentials.setPassword("test");
		credentials.setToken("token");
		credentials.setType("typ");

		header.setTransactionId("TR1234567890");
		header.setConsumer(consumer);
		header.setCredentials(credentials);
		return header;
	}





}
