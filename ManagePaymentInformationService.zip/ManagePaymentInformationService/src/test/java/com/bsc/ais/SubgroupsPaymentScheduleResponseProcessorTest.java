/**
 * 
 */
	package com.bsc.ais;

	/*import java.util.ArrayList;
	import java.util.List;

	import org.apache.camel.Exchange;
	import org.apache.camel.builder.RouteBuilder;
	import org.apache.camel.component.mock.MockEndpoint;
	import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
	import org.apache.camel.test.spring.CamelSpringRunner;
	import org.junit.Test;
	import org.junit.runner.RunWith;
	import org.mockito.InjectMocks;
	import org.mockito.Mock;
	import org.mockito.MockitoAnnotations;
	import org.springframework.test.context.ContextConfiguration;

	import com.bsc.aip.core.framewrok.logging.EventLogging;
	import com.bsc.aip.core.model.common.atomic.Consumer;
	import com.bsc.aip.core.model.common.atomic.Credentials;
	import com.bsc.aip.core.model.common.atomic.Message;
	import com.bsc.aip.core.model.common.composite.Remarks;
	import com.bsc.aip.core.model.common.composite.RequestHeader;
	import com.bsc.aip.core.model.common.composite.ResponseHeader;
	import com.bsc.aip.core.model.common.composite.TransactionNotification;
import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
import com.bsc.ais.manage.payment.info.services.v1.model.response.SubgroupsSetCancelPaymentResponseBody;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.processor.SubgroupsPaymentScheduleResponseProcessor;

	@RunWith(CamelSpringRunner.class)
	@ContextConfiguration(locations = { "classpath:springtest-config/springtest-context.xml" })
	public class SubgroupsPaymentScheduleResponseProcessorTest extends CamelTestSupport{


		 @InjectMocks
		 private SubgroupsPaymentScheduleResponseProcessor processor = new SubgroupsPaymentScheduleResponseProcessor();
		 
		@Mock
	   private EventLogging eventLogging;


		@Override
		public void setUp() throws Exception {
			super.setUp();
			MockitoAnnotations.initMocks(this);	

		}



		@Override
		protected RouteBuilder createRouteBuilder() throws Exception {
			return new RouteBuilder() {
				@Override
				public void configure() throws Exception {

					
					from("direct:in").process(processor).to("mock:out");
				}
			};
		}

		@SuppressWarnings("unchecked")
		@Test
		public void testProcessSuccessResponse() {
			MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");
			List<AuditEvent> auditEventList =  new ArrayList<AuditEvent>();
			RequestHeader header = new RequestHeader();
			Consumer consumer = new Consumer();
			consumer.setBusinessTransactionType("");
			consumer.setBusinessUnit("test");
			consumer.setClientVersion("");
			consumer.setContextId("test");
			consumer.setHostName("hostname");
			consumer.setId("");
			consumer.setName("IVR");
			consumer.setRequestDateTime("test");
			consumer.setType("test");
			Credentials credentials = new Credentials();
			credentials.setUserName("test");
			credentials.setPassword("test");
			credentials.setToken("test");
			credentials.setType("test");

			header.setTransactionId("TR1234567890");
			header.setCredentials(credentials);

			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			request.setRequestHeader(header);

			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			
			response.setResponseHeader(new ResponseHeader());
			response.getResponseHeader().setTransactionNotification(new TransactionNotification());
			Remarks remarks = new Remarks();
			List<Message> messageList = new ArrayList<Message>();
			remarks.setMessages(messageList);
			response.getResponseHeader().getTransactionNotification().setStatusCode(ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE);
			response.getResponseHeader().getTransactionNotification().setRemarks(remarks);

			
			SubgroupsSetCancelPaymentResponseBody body = new SubgroupsSetCancelPaymentResponseBody();
		
//			body.setTotalRecordCount("1");

		 
			try {
				DefaultExchange exchange = new DefaultExchange(createCamelContext());
				exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);
				exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);
				exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
				//exchange.setProperty(ManagePaymentInfoServiceConstants.DATA_RESPONSE,body);
				DefaultMessage message = new DefaultMessage(createCamelContext());		
				
				message.setBody(response);
				exchange.setIn(message);

				template.send("direct:in", exchange);
			} catch (Exception e) {
				e.printStackTrace();
			}

			List<Exchange> exchangeList = mockOutEndPt.getReceivedExchanges();
			SubgroupsSetCancelPaymentResponse Procresponse = (SubgroupsSetCancelPaymentResponse) exchangeList.get(0).getIn().getBody();
		
			assertNotNull(Procresponse.getResponseBody());
		}

		




	}





*/






















































/**
	 * 
	 */


	import java.util.ArrayList;
	import java.util.List;

	import org.apache.camel.Exchange;
	import org.apache.camel.builder.RouteBuilder;
	import org.apache.camel.component.mock.MockEndpoint;
	import org.apache.camel.impl.DefaultExchange;
	import org.apache.camel.test.junit4.CamelTestSupport;
	import org.apache.camel.test.spring.CamelSpringRunner;
	import org.junit.Test;
	import org.junit.runner.RunWith;
	import org.mockito.InjectMocks;
	import org.mockito.Mock;
	import org.mockito.MockitoAnnotations;
	import org.springframework.test.context.ContextConfiguration;

	import com.bsc.aip.core.camel.template.BscCamelTemplate;
	import com.bsc.aip.core.framewrok.logging.EventLogging;
	import com.bsc.aip.core.model.common.atomic.Consumer;
	import com.bsc.aip.core.model.common.composite.RequestHeader;
	import com.bsc.aip.core.model.common.composite.ResponseHeader;
	import com.bsc.aip.core.model.common.composite.TransactionNotification;
	import com.bsc.ais.manage.payment.info.services.v1.constants.ManagePaymentInfoServiceConstants;
	import com.bsc.ais.manage.payment.info.services.v1.model.request.SubgroupsSetCancelPaymentRequestBody;
	import com.bsc.ais.manage.payment.info.services.v1.model.request.portalauditevent.AuditEvent;
	import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentRequest;
	import com.bsc.ais.manage.payment.info.services.v1.model.transactional.SubgroupsSetCancelPaymentResponse;
import com.bsc.ais.manage.payment.info.services.v1.processor.SubgroupsPaymentScheduleResponseProcessor;
/*
	*//**
	 * @author 690294
	 *
	 *//*  */
	@RunWith(CamelSpringRunner.class)
	@ContextConfiguration(locations = { "classpath:springtest-config/springtest-context.xml" })
	public class SubgroupsPaymentScheduleResponseProcessorTest  extends CamelTestSupport {


		@InjectMocks
		private SubgroupsPaymentScheduleResponseProcessor processor = new SubgroupsPaymentScheduleResponseProcessor();

		@Mock
		private BscCamelTemplate bscCamelTemplate = new BscCamelTemplate();
		
		@Mock
		private EventLogging eventLogging;

		@Override
		public void setUp() throws Exception {
			MockitoAnnotations.initMocks(this);
			super.setUp();
  
		}

		@Override
		protected RouteBuilder createRouteBuilder() throws Exception {
			return new RouteBuilder() {
				@Override
				public void configure() throws Exception {
					from("direct:in").process(processor).to("mock:out");
				}
			};
		}

		@Test
		public void testProcessSuccess() {
			MockEndpoint mockOutEndPt = getMockEndpoint("mock:out");

			try {

				DefaultExchange exc = populateExchanges();
				template.send("direct:in", exc);
			} catch (Exception e) {
				e.printStackTrace();
			}

			List<Exchange> exchangeList = mockOutEndPt.getReceivedExchanges();

			assertEquals("exception flow", true, exchangeList.isEmpty());

		}


		private DefaultExchange populateExchanges() {

			RequestHeader header = new RequestHeader();
			Consumer consumer = new Consumer();
			consumer.setBusinessTransactionType("emp");
			consumer.setId("id"); 
			header.setTransactionId("TR1234567890");
			header.setConsumer(consumer);
			SubgroupsSetCancelPaymentRequestBody body = new SubgroupsSetCancelPaymentRequestBody();
			SubgroupsSetCancelPaymentRequest request = new SubgroupsSetCancelPaymentRequest();
			request.setRequestBody(body);
			request.setRequestHeader(header);



			List<AuditEvent> auditEventList = new ArrayList<AuditEvent>();

			SubgroupsSetCancelPaymentResponse response = new SubgroupsSetCancelPaymentResponse();
			response.setResponseHeader(new ResponseHeader());
			response.getResponseHeader().setTransactionNotification(new TransactionNotification());
			response.getResponseHeader().getTransactionNotification()
					.setStatusCode(ManagePaymentInfoServiceConstants.SUCCESS_STATUS_CODE);
			DefaultExchange exchange = null;
			try {
				exchange = new DefaultExchange(createCamelContext());
				exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_REQUEST, request);
				exchange.setProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE, response);

				exchange.setProperty(ManagePaymentInfoServiceConstants.SERVICE_NAME,
						ManagePaymentInfoServiceConstants.SET_PYMNT_SCHED_SERVICE);
				exchange.setProperty(ManagePaymentInfoServiceConstants.AUDIT_EVENT_LIST, auditEventList);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return exchange;
		}

		private SubgroupsSetCancelPaymentResponse checkProcessResponse(MockEndpoint mockOutEndPt) {
			List<Exchange> exchangeList = mockOutEndPt.getReceivedExchanges();
			SubgroupsSetCancelPaymentResponse response = (SubgroupsSetCancelPaymentResponse) exchangeList.get(0)
					.getProperty(ManagePaymentInfoServiceConstants.EXC_PROP_RESPONSE);
			return response;
		}
	}


	
	
	
	
	




















//}
